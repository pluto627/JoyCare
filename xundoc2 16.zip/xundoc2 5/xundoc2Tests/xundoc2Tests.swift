//
//  xundoc2Tests.swift
//  xundoc2Tests
//
//  Created by pluto guo on 2/21/25.
//

import Testing
@testable import xundoc2

struct xundoc2Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
