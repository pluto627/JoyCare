import SwiftUI

struct MedicineDetailView: View {
    @Environment(\.dismiss) var dismiss
    @ObservedObject var reminderManager: ReminderManager
    let medicine: Reminder
    let allReminders: [Reminder]
    
    var body: some View {
        NavigationView {
            List {
                Section(header: Text(NSLocalizedString("medication_info", comment: ""))) {
                    HStack {
                        Text(NSLocalizedString("medication_name", comment: ""))
                        Spacer()
                        Text(medicine.title)
                            .foregroundColor(.gray)
                    }
                    
                    if let dosage = medicine.dosage, let unit = medicine.unit {
                        HStack {
                            Text(NSLocalizedString("dosage", comment: ""))
                            Spacer()
                            Text("\(dosage)\(unit)")
                                .foregroundColor(.gray)
                        }
                    }
                    
                    if let method = medicine.medicineMethod {
                        HStack {
                            Text(NSLocalizedString("administration_method", comment: ""))
                            Spacer()
                            Text(method)
                                .foregroundColor(.gray)
                        }
                    }
                    
                    if let mealTime = medicine.beforeOrAfterMeal {
                        HStack {
                            Text(NSLocalizedString("meal_timing", comment: ""))
                            Spacer()
                            Text(mealTime)
                                .foregroundColor(.gray)
                        }
                    }
                }
                
                Section(header: Text(NSLocalizedString("reminder_times", comment: ""))) {
                    ForEach(allReminders) { reminder in
                        HStack {
                            Text(formatTime(reminder.date))
                            Spacer()
                            if reminder.repeatPattern != nil {
                                Image(systemName: "repeat")
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                }
                
                if let notes = medicine.medicineNotes {
                    Section(header: Text(NSLocalizedString("medication_notes", comment: ""))) {
                        Text(notes)
                    }
                }
            }
            .navigationTitle(NSLocalizedString("medication_details", comment: ""))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(NSLocalizedString("edit", comment: "")) {
                        // 这里可以添加编辑功能
                    }
                }
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(NSLocalizedString("close", comment: "")) {
                        dismiss()
                    }
                }
            }
        }
    }
    
    private func formatTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        return formatter.string(from: date)
    }
}

// 预览
struct MedicineDetailView_Previews: PreviewProvider {
    static var previews: some View {
        let sampleReminder = Reminder(
            title: "叔叔",
            date: Date(),
            type: "用药提醒",
            dosage: "1.0",
            unit: "片",
            medicineMethod: "口服",
            beforeOrAfterMeal: "餐前服用"
        )
        
        MedicineDetailView(
            reminderManager: ReminderManager(),
            medicine: sampleReminder,
            allReminders: []
        )
    }
} 