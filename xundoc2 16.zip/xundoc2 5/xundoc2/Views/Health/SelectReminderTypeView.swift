import SwiftUI

struct SelectReminderTypeView: View {
    @Environment(\.dismiss) var dismiss
    @ObservedObject var reminderManager: ReminderManager
    @State private var selectedType: String?
    @State private var showAddReminderView = false
    
    let reminderTypes = [
        (NSLocalizedString("medication", comment: ""), "pill", NSLocalizedString("medication_reminder", comment: "")),
        (NSLocalizedString("exercise", comment: ""), "figure.run", NSLocalizedString("exercise_reminder", comment: "")),
        (NSLocalizedString("water", comment: ""), "drop", NSLocalizedString("water_reminder", comment: "")),
        (NSLocalizedString("sleep", comment: ""), "moon", NSLocalizedString("sleep_reminder", comment: "")),
        (NSLocalizedString("posture", comment: ""), "chair", NSLocalizedString("posture_reminder", comment: "")),
        (NSLocalizedString("eye_protection", comment: ""), "eye", NSLocalizedString("eye_protection_reminder", comment: "")),
        (NSLocalizedString("oral_hygiene", comment: ""), "mouth", NSLocalizedString("oral_hygiene_reminder", comment: "")),
        (NSLocalizedString("skin_care", comment: ""), "leaf", NSLocalizedString("skin_care_reminder", comment: "")),
        (NSLocalizedString("follow_up", comment: ""), "cross.case", NSLocalizedString("follow_up_reminder", comment: "")),
        (NSLocalizedString("custom", comment: ""), "plus", NSLocalizedString("custom_reminder", comment: ""))
    ]
    
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    // 添加一个计算属性来处理视图选择
    @ViewBuilder
    private var destinationView: some View {
        if let type = selectedType {
            if type == NSLocalizedString("medication_reminder", comment: "") {
                AddMedicineReminderView(reminderManager: reminderManager)
            } else {
                AddReminderView(reminderManager: reminderManager, initialType: type)
            }
        } else {
            EmptyView()
        }
    }
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text(NSLocalizedString("select_reminder_type", comment: ""))
                    .font(.title2)
                    .fontWeight(.bold)
                
                LazyVGrid(columns: columns, spacing: 20) {
                    ForEach(reminderTypes, id: \.0) { type in
                        ReminderTypeButton(
                            title: type.0,
                            icon: type.1,
                            isSelected: selectedType == type.2
                        ) {
                            selectedType = type.2
                            showAddReminderView = true
                        }
                    }
                }
                .padding()
                
                Spacer()
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(NSLocalizedString("cancel", comment: "")) {
                        dismiss()
                    }
                }
            }
            .fullScreenCover(isPresented: $showAddReminderView) {
                destinationView
            }
        }
    }
}

struct ReminderTypeButton: View {
    let title: String
    let icon: String
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack {
                Image(systemName: icon)
                    .font(.system(size: 24))
                    .foregroundColor(.blue)
                    .frame(width: 50, height: 50)
                    .background(Color.blue.opacity(0.1))
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                
                Text(title)
                    .font(.system(size: 12))
                    .foregroundColor(.primary)
            }
        }
        .padding(8)
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(isSelected ? Color.blue.opacity(0.1) : Color.clear)
        )
    }
}
