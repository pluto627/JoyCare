import SwiftUI
import _PhotosUI_SwiftUI
import Vision
import VisionKit

struct MedicalReportsView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var selectedType = NSLocalizedString("blood_test", comment: "")
    @State private var reportContent = ""
    @State private var showAlert = false
    @State private var selectedItem: PhotosPickerItem?
    @State private var selectedImageData: Data?
    @State private var selectedImages: [UIImage] = []
    let recordId: UUID
    @State private var isProcessingImage = false
    @State private var description = ""
    @State private var showingImagePicker = false
    
    let reportTypes = [
        NSLocalizedString("blood_test", comment: ""),
        NSLocalizedString("urine_test", comment: ""),
        NSLocalizedString("ecg", comment: ""),
        NSLocalizedString("ct_scan", comment: ""),
        NSLocalizedString("mri", comment: ""),
        NSLocalizedString("ultrasound", comment: ""),
        NSLocalizedString("other", comment: "")
    ]
    
    // 更新关键词字典
    private let reportKeywords: [String: Set<String>] = [
        NSLocalizedString("blood_test", comment: ""): ["blood test", "blood", "hemoglobin", "WBC", "RBC", "HGB"],
        NSLocalizedString("urine_test", comment: ""): ["urine test", "urine", "urinalysis"],
        NSLocalizedString("ultrasound", comment: ""): ["ultrasound", "sonogram", "echo"],
        NSLocalizedString("ct_scan", comment: ""): ["CT", "computed tomography"],
        NSLocalizedString("mri", comment: ""): ["MRI", "magnetic resonance"],
        NSLocalizedString("ecg", comment: ""): ["ECG", "EKG", "electrocardiogram"]
    ]
    
    var onSave: ((MedicalReport) -> Void)?
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text(NSLocalizedString("report_type", comment: ""))) {
                    TextField(NSLocalizedString("report_type", comment: ""), text: $selectedType)
                }
                
                Section(header: Text(NSLocalizedString("report_content", comment: ""))) {
                    TextEditor(text: $reportContent)
                }
                
                Button(NSLocalizedString("select_files", comment: "")) {
                    showingImagePicker = true
                }
            }
            .navigationTitle(NSLocalizedString("add_report", comment: ""))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(NSLocalizedString("cancel", comment: "")) {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(NSLocalizedString("save", comment: "")) {
                        saveReport()
                    }
                    .disabled(reportContent.isEmpty)
                }
            }
        }
        .sheet(isPresented: $showingImagePicker) {
            PhotosPicker(
                selection: $selectedItem,
                matching: .images
            ) {
                Text(NSLocalizedString("select_photo", comment: ""))
            }
            .onChange(of: selectedItem) { newItem in
                Task {
                    if let data = try? await newItem?.loadTransferable(type: Data.self),
                       let image = UIImage(data: data) {
                        selectedImages.append(image)
                    }
                }
            }
        }
        .alert(NSLocalizedString("save_success", comment: ""), isPresented: $showAlert) {
            Button(NSLocalizedString("ok", comment: "")) {
                dismiss()
            }
        }
    }
    
    private func saveReport() {
        let report = MedicalReport(
            id: UUID(),
            recordId: recordId,
            type: selectedType,
            date: Date(),
            images: selectedImages
        )
        
        onSave?(report)
        dismiss()
    }
    
    private func processImage(_ image: UIImage) {
        isProcessingImage = true
        
        guard let cgImage = image.cgImage else {
            isProcessingImage = false
            return
        }
        
        let requestHandler = VNImageRequestHandler(cgImage: cgImage)
        let request = VNRecognizeTextRequest { request, error in
            guard let observations = request.results as? [VNRecognizedTextObservation],
                  error == nil else {
                isProcessingImage = false
                return
            }
            
            let recognizedText = observations.compactMap { observation in
                observation.topCandidates(1).first?.string
            }.joined(separator: " ")
            
            // 根据识别出的文本判断报告类型
            for (type, keywords) in reportKeywords {
                for keyword in keywords {
                    if recognizedText.lowercased().contains(keyword.lowercased()) {
                        DispatchQueue.main.async {
                            self.selectedType = type
                            self.isProcessingImage = false
                        }
                        return
                    }
                }
            }
            
            isProcessingImage = false
        }
        
        request.recognitionLanguages = ["zh-Hans", "en"]
        
        do {
            try requestHandler.perform([request])
        } catch {
            print("文字识别失败: \(error)")
            isProcessingImage = false
        }
    }
}
#Preview {
    MedicalReportsView(recordId: UUID()) // 添加一个测试用的 UUID
}
