import SwiftUI
import PhotosUI


struct PersonalInfoView: View {
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var userDataManager: UserDataManager
    @State private var isEditing = false
    @State private var showingImagePicker = false
    @State private var selectedImages: [UIImage] = []
    @State private var tempUserData: UserData? // 临时存储编辑的数据
    
    var body: some View {
        Form {
            // 头像部分
            Section {
                HStack {
                    Spacer()
                    VStack {
                        if let avatarData = userDataManager.userData.avatarData,
                           let uiImage = UIImage(data: avatarData) {
                            Image(uiImage: uiImage)
                                .resizable()
                                .scaledToFill()
                                .frame(width: 100, height: 100)
                                .clipShape(Circle())
                        } else {
                            Image(systemName: "person.circle.fill")
                                .resizable()
                                .frame(width: 100, height: 100)
                                .foregroundColor(.gray)
                        }
                        
                        if isEditing {
                            Button(NSLocalizedString("change_avatar", comment: "")) {
                                showingImagePicker = true
                            }
                            .foregroundColor(.blue)
                            .padding(.top, 8)
                        }
                    }
                    Spacer()
                }
            }
            
            Section(header: Text(NSLocalizedString("basic_info", comment: ""))) {
                if isEditing {
                    TextField(NSLocalizedString("name", comment: ""), text: Binding(
                        get: { tempUserData?.name ?? userDataManager.userData.name },
                        set: { tempUserData?.name = $0 }
                    ))
                    TextField(NSLocalizedString("id_number", comment: ""), text: Binding(
                        get: { tempUserData?.id ?? userDataManager.userData.id },
                        set: { tempUserData?.id = $0 }
                    ))
                    Picker(NSLocalizedString("gender", comment: ""), selection: Binding(
                        get: { tempUserData?.gender ?? userDataManager.userData.gender },
                        set: { tempUserData?.gender = $0 }
                    )) {
                        Text(NSLocalizedString("male", comment: "")).tag("male")
                        Text(NSLocalizedString("female", comment: "")).tag("female")
                    }
                    DatePicker(NSLocalizedString("birth_date", comment: ""), selection: Binding(
                        get: { tempUserData?.birthDate ?? userDataManager.userData.birthDate },
                        set: { tempUserData?.birthDate = $0 }
                    ), displayedComponents: .date)
                } else {
                    InfoRow(title: NSLocalizedString("name", comment: ""), value: userDataManager.userData.name)
                    InfoRow(title: NSLocalizedString("gender", comment: ""), value: userDataManager.userData.gender == "male" ? NSLocalizedString("male", comment: "") : NSLocalizedString("female", comment: ""))
                    InfoRow(title: NSLocalizedString("birth_date", comment: ""), value: userDataManager.userData.birthDate.formatted(date: .abbreviated, time: .omitted))
                }
            }
            
            Section(header: Text(NSLocalizedString("contact_info", comment: ""))) {
                if isEditing {
                    TextField(NSLocalizedString("phone_number", comment: ""), text: Binding(
                        get: { tempUserData?.phone ?? userDataManager.userData.phone },
                        set: { tempUserData?.phone = $0 }
                    ))
                    TextField(NSLocalizedString("email_address", comment: ""), text: Binding(
                        get: { tempUserData?.email ?? userDataManager.userData.email },
                        set: { tempUserData?.email = $0 }
                    ))
                } else {
                    InfoRow(title: NSLocalizedString("phone_number", comment: ""), value: userDataManager.userData.phone)
                    InfoRow(title: NSLocalizedString("email_address", comment: ""), value: userDataManager.userData.email)
                }
            }
            
            Section(header: Text(NSLocalizedString("address_info", comment: ""))) {
                if isEditing {
                    TextField(NSLocalizedString("residential_address", comment: ""), text: Binding(
                        get: { tempUserData?.address ?? userDataManager.userData.address },
                        set: { tempUserData?.address = $0 }
                    ))
                } else {
                    InfoRow(title: NSLocalizedString("residential_address", comment: ""), value: userDataManager.userData.address)
                }
            }
        }
        .navigationTitle(NSLocalizedString("personal_info", comment: ""))
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarItems(trailing: Button(isEditing ? NSLocalizedString("save_changes", comment: "") : NSLocalizedString("start_editing", comment: "")) {
            if isEditing {
                // 保存更改
                if let tempData = tempUserData {
                    userDataManager.userData = tempData
                }
                isEditing.toggle()
                tempUserData = nil
            } else {
                // 开始编辑
                tempUserData = userDataManager.userData
                isEditing.toggle()
            }
        })
        .sheet(isPresented: $showingImagePicker) {
            ImagePicker(selectedImages: $selectedImages, sourceType: .photoLibrary)
        }
        .onChange(of: selectedImages) { newImages in
            if let image = newImages.last,
               let imageData = image.jpegData(compressionQuality: 0.8) {
                tempUserData?.avatarData = imageData
            }
        }
        .onAppear {
            // 重置临时数据
            tempUserData = nil
            isEditing = false
            selectedImages = []
        }
    }
}

struct InfoRow: View {
    let title: String
    let value: String
    
    var body: some View {
        HStack {
            Text(title)
            Spacer()
            Text(value)
                .foregroundColor(.gray)
        }
        .padding(.vertical, 4)
    }
}
#Preview {
    PersonalInfoView()
        .environmentObject(UserDataManager())
}
