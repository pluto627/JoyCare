import SwiftUI
import CoreLocation

// 修改 Hospital1 结构体
struct Hospital1: Identifiable, Codable {
    let id: UUID
    let name: String
    let address: String
    let latitude: Double
    let longitude: Double
    
    init(id: UUID = UUID(), name: String, address: String, latitude: Double, longitude: Double) {
        self.id = id
        self.name = name
        self.address = address
        self.latitude = latitude
        self.longitude = longitude
    }
}

class HospitalStore: ObservableObject {
    @Published var hospitals: [Hospital1] = []
    private let userDefaultsKey = "savedHospitals"
    
    init() {
        loadHospitals()
    }
    
    func loadHospitals() {
        if let data = UserDefaults.standard.data(forKey: userDefaultsKey) {
            if let decoded = try? JSONDecoder().decode([Hospital1].self, from: data) {
                self.hospitals = decoded
            }
        }
    }
    
    func saveHospitals() {
        if let encoded = try? JSONEncoder().encode(hospitals) {
            UserDefaults.standard.set(encoded, forKey: userDefaultsKey)
        }
    }
    
    func addHospital(name: String, address: String, latitude: Double, longitude: Double) {
        let hospital = Hospital1(
            name: name,
            address: address,
            latitude: latitude,
            longitude: longitude
        )
        hospitals.append(hospital)
        saveHospitals()
    }
    
    func deleteHospital(_ hospital: Hospital1) {
        hospitals.removeAll { $0.id == hospital.id }
        saveHospitals()
    }
}

struct HospitalsView: View {
    @Environment(\.presentationMode) var presentationMode
    @StateObject private var hospitalStore = HospitalStore()
    @State private var searchText = ""
    @State private var showingAddHospital = false
    @State private var selectedHospital: String? = nil
    
    var filteredHospitals: [Hospital1] {
        if searchText.isEmpty {
            return hospitalStore.hospitals
        } else {
            return hospitalStore.hospitals.filter { $0.name.contains(searchText) }
        }
    }
    
    var body: some View {
        NavigationView {
            VStack {
                SearchBar(text: $searchText)
                    .padding()
                
                if hospitalStore.hospitals.isEmpty {
                    VStack(spacing: 20) {
                        Spacer()
                        Text(NSLocalizedString("no_hospitals", comment: ""))
                            .font(.headline)
                            .foregroundColor(.gray)
                        Image(systemName: "plus.circle.fill")
                            .resizable()
                            .frame(width: 60, height: 60)
                            .foregroundColor(Color(hex: "9253f3"))
                            .onTapGesture {
                                showingAddHospital = true
                            }
                        Spacer()
                    }
                } else {
                    List {
                        ForEach(filteredHospitals) { hospital in
                            VStack(alignment: .leading, spacing: 8) {
                                Text(hospital.name)
                                    .font(.headline)
                                
                                Text(hospital.address)
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                            }
                            .padding(.vertical, 8)
                        }
                        .onDelete { indexSet in
                            for index in indexSet {
                                hospitalStore.deleteHospital(filteredHospitals[index])
                            }
                        }
                    }
                }
            }
            .navigationTitle(NSLocalizedString("common_hospitals", comment: ""))
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarItems(trailing:
                Button(action: {
                    showingAddHospital = true
                }) {
                    Image(systemName: "plus")
                        .foregroundColor(Color(hex: "9253f3"))
                }
            )
            .sheet(isPresented: $showingAddHospital) {
                AddHospitalView { name, address in
                    // 获取地址的坐标
                    let geocoder = CLGeocoder()
                    geocoder.geocodeAddressString(address) { placemarks, error in
                        if let location = placemarks?.first?.location {
                            hospitalStore.addHospital(
                                name: name,
                                address: address,
                                latitude: location.coordinate.latitude,
                                longitude: location.coordinate.longitude
                            )
                        } else {
                            // 如果无法获取坐标，使用默认值
                            hospitalStore.addHospital(
                                name: name,
                                address: address,
                                latitude: 0,
                                longitude: 0
                            )
                        }
                    }
                }
            }
        }
    }
    
    private func formatAddress(from placemark: CLPlacemark) -> String {
        var addressComponents: [String] = []
        
        if let city = placemark.locality {
            addressComponents.append(city)
        }
        if let subLocality = placemark.subLocality {
            addressComponents.append(subLocality)
        }
        if let thoroughfare = placemark.thoroughfare {
            addressComponents.append(thoroughfare)
        }
        if let subThoroughfare = placemark.subThoroughfare {
            addressComponents.append(subThoroughfare)
        }
        
        return addressComponents.joined(separator: "")
    }
}

struct SearchBar: View {
    @Binding var text: String
    
    var body: some View {
        HStack {
            Image(systemName: "magnifyingglass")
                .foregroundColor(.gray)
            
            TextField(NSLocalizedString("search_hospital", comment: ""), text: $text)
                .textFieldStyle(PlainTextFieldStyle())
            
            if !text.isEmpty {
                Button(action: {
                    text = ""
                }) {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundColor(.gray)
                }
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(Color(.systemGray6))
        .cornerRadius(10)
    }
}

#Preview {
    HospitalsView()
}
