import Foundation

struct DoctorOrder: Codable, Identifiable {
    let id: UUID
    let recordId: UUID
    let content: String
    let date: Date
    let imageData: Data?
    let diagnosis: String?
    let recommendations: String?
    let symptoms: String?
    
    init(id: UUID = UUID(), 
         recordId: UUID, 
         content: String, 
         date: Date = Date(),
         imageData: Data? = nil,
         diagnosis: String? = nil,
         recommendations: String? = nil,
         symptoms: String? = nil) {
        self.id = id
        self.recordId = recordId
        self.content = content
        self.date = date
        self.imageData = imageData
        self.diagnosis = diagnosis
        self.recommendations = recommendations
        self.symptoms = symptoms
    }
    
    enum CodingKeys: String, CodingKey {
        case id
        case recordId
        case content
        case date
        case imageData
        case diagnosis
        case recommendations
        case symptoms
    }
}

