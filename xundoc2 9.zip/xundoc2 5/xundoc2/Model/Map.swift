import SwiftUI
import MapKit
import CoreLocation

// 医院模型
struct Hospital: Identifiable {
    let id = UUID()
    let name: String
    let location: CLLocationCoordinate2D
    let distance: Double // 以米为单位的距离
}

// SwiftUI包装视图
struct HospitalMapView: UIViewControllerRepresentable {
    var onHospitalSelected: (String, CLPlacemark) -> Void
    
    func makeUIViewController(context: Context) -> HospitalMapViewController {
        let controller = HospitalMapViewController()
        controller.onHospitalSelected = onHospitalSelected
        return controller
    }
    
    func updateUIViewController(_ uiViewController: HospitalMapViewController, context: Context) {
        uiViewController.startLocating()
    }
}

// 地图视图控制器
class HospitalMapViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate, UISearchBarDelegate {
    private var mapView: MKMapView!
    private let locationManager = CLLocationManager()
    private var userLocation: CLLocation?
    private var hospitals: [Hospital] = []
    private var searchBar: UISearchBar!
    var onHospitalSelected: ((String, CLPlacemark) -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupSearchBar()
        setupMapView()
        setupLocationManager()
    }
    
    private func setupSearchBar() {
        searchBar = UISearchBar()
        searchBar.delegate = self
        searchBar.placeholder = "搜索医院"
        searchBar.searchBarStyle = .minimal
        searchBar.translatesAutoresizingMaskIntoConstraints = false
        
        // 添加搜索栏
        view.addSubview(searchBar)
        
        NSLayoutConstraint.activate([
            searchBar.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            searchBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            searchBar.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
    }
    
    private func setupMapView() {
        mapView = MKMapView(frame: .zero)
        mapView.delegate = self
        mapView.showsUserLocation = true
        mapView.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(mapView)
        
        NSLayoutConstraint.activate([
            mapView.topAnchor.constraint(equalTo: searchBar.bottomAnchor),
            mapView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            mapView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            mapView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }
    
    private func setupLocationManager() {
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
        checkLocationAuthorization()
    }
    
    // 检查位置服务授权状态
    private func checkLocationAuthorization() {
        switch locationManager.authorizationStatus {
        case .notDetermined:
            locationManager.requestWhenInUseAuthorization()
        case .restricted, .denied:
            showLocationAlert()
        case .authorizedWhenInUse, .authorizedAlways:
            startDefaultSearch()
        @unknown default:
            break
        }
    }
    
    // 显示位置服务提示
    private func showLocationAlert() {
        let alert = UIAlertController(
            title: "位置服务未开启",
            message: "请在设置中开启位置服务，以便查找附近医院",
            preferredStyle: .alert
        )
        
        alert.addAction(UIAlertAction(title: "使用默认位置", style: .default) { [weak self] _ in
            self?.startDefaultSearch()
        })
        
        alert.addAction(UIAlertAction(title: "打开设置", style: .default) { _ in
            if let url = URL(string: UIApplication.openSettingsURLString) {
                UIApplication.shared.open(url)
            }
        })
        
        present(alert, animated: true)
    }
    
    // 使用默认位置查找医院
    private func startDefaultSearch() {
        let defaultLocation = CLLocationCoordinate2D(latitude: 31.2304, longitude: 121.4737) // 上海市中心
        let region = MKCoordinateRegion(
            center: defaultLocation,
            span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
        )
        mapView.setRegion(region, animated: true)
        searchHospitals(in: region)
    }
    
    func startLocating() {
        if locationManager.authorizationStatus == .authorizedWhenInUse ||
           locationManager.authorizationStatus == .authorizedAlways {
            locationManager.requestLocation()
        } else {
            checkLocationAuthorization()
        }
    }
    
    // MARK: - UISearchBarDelegate
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        
        guard let searchText = searchBar.text, !searchText.isEmpty else { return }
        
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = searchText + " 医院"
        request.region = mapView.region
        
        let search = MKLocalSearch(request: request)
        search.start { [weak self] (response, error) in
            guard let self = self else { return }
            
            if let error = error {
                print("搜索失败: \(error.localizedDescription)")
                return
            }
            
            self.clearAnnotations()
            
            if let response = response {
                self.addAnnotations(from: response.mapItems)
            }
        }
    }
    
    // MARK: - CLLocationManagerDelegate
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.first else { return }
        
        userLocation = location
        
        let region = MKCoordinateRegion(
            center: location.coordinate,
            span: MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02)
        )
        mapView.setRegion(region, animated: true)
        
        searchHospitals(in: region)
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("位置获取失败: \(error.localizedDescription)")
        startDefaultSearch()
    }
    
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        checkLocationAuthorization()
    }
    
    // MARK: - Map Helper Methods
    
    private func searchHospitals(in region: MKCoordinateRegion) {
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = "医院"
        request.region = region
        
        let search = MKLocalSearch(request: request)
        search.start { [weak self] (response, error) in
            guard let self = self else { return }
            
            if let error = error {
                print("搜索失败: \(error.localizedDescription)")
                return
            }
            
            self.clearAnnotations()
            
            if let response = response {
                self.addAnnotations(from: response.mapItems)
            } else {
                self.showNoHospitalsAlert()
            }
        }
    }
    
    private func clearAnnotations() {
        mapView.removeAnnotations(mapView.annotations)
        hospitals.removeAll()
    }
    
    private func addAnnotations(from mapItems: [MKMapItem]) {
        for item in mapItems {
            let annotation = MKPointAnnotation()
            annotation.title = item.name
            annotation.coordinate = item.placemark.coordinate
            
            var distance: Double = 0
            if let userLocation = self.userLocation {
                distance = userLocation.distance(from: CLLocation(
                    latitude: item.placemark.coordinate.latitude,
                    longitude: item.placemark.coordinate.longitude
                ))
            }
            
            let hospital = Hospital(
                name: item.name ?? "未知医院",
                location: item.placemark.coordinate,
                distance: distance
            )
            
            hospitals.append(hospital)
            mapView.addAnnotation(annotation)
        }
        
        hospitals.sort { $0.distance < $1.distance }
    }
    
    private func showNoHospitalsAlert() {
        let alert = UIAlertController(
            title: "未找到医院",
            message: "当前区域未找到医院信息，请尝试手动输入或更改位置",
            preferredStyle: .alert
        )
        
        alert.addAction(UIAlertAction(title: "确定", style: .default))
        
        present(alert, animated: true)
    }
    
    // MARK: - MKMapViewDelegate
    
    func mapView(_ mapView: MKMapView, didSelect annotation: MKAnnotation) {
        guard let title = annotation.title, let hospitalName = title else { return }
        
        let location = CLLocation(latitude: annotation.coordinate.latitude, longitude: annotation.coordinate.longitude)
        let geocoder = CLGeocoder()
        
        geocoder.reverseGeocodeLocation(location) { [weak self] (placemarks, error) in
            guard let self = self,
                  let placemark = placemarks?.first else {
                return
            }
            
            // 回调医院名称和位置信息
            self.onHospitalSelected?(hospitalName, placemark)
            
            // 关闭地图视图
            DispatchQueue.main.async {
                self.dismiss(animated: true)
            }
        }
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        if annotation is MKUserLocation {
            return nil
        }
        
        let identifier = "HospitalMarker"
        var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)
        
        if annotationView == nil {
            annotationView = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            annotationView?.canShowCallout = true
            
            // 添加详情按钮
            let button = UIButton(type: .detailDisclosure)
            annotationView?.rightCalloutAccessoryView = button
        } else {
            annotationView?.annotation = annotation
        }
        
        return annotationView
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        if let title = view.annotation?.title,
           let hospitalName = title,
           let coordinate = view.annotation?.coordinate {
            
            let location = CLLocation(latitude: coordinate.latitude, longitude: coordinate.longitude)
            let geocoder = CLGeocoder()
            
            geocoder.reverseGeocodeLocation(location) { [weak self] (placemarks, error) in
                guard let self = self,
                      let placemark = placemarks?.first else {
                    return
                }
                
                // 回调医院名称和位置信息
                self.onHospitalSelected?(hospitalName, placemark)
                
                // 关闭地图视图
                DispatchQueue.main.async {
                    self.dismiss(animated: true)
                }
            }
        }
    }
}
