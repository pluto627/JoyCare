import Foundation
import SwiftUI

struct Reminder: Identifiable, Codable, Equatable {
    let id: UUID
    var title: String
    var date: Date
    var isCompleted: Bool
    var description: String?
    var type: String
    var repeatPattern: String?

    init(id: UUID = UUID(),
         title: String,
         date: Date,
         isCompleted: Bool = false,
         description: String? = nil,
         type: String = "用药提醒",
         repeatPattern: String? = nil) {  // 添加 repeatPattern 参数并设置默认值为 nil
        self.id = id
        self.title = title
        self.date = date
        self.isCompleted = isCompleted
        self.description = description
        self.type = type
        self.repeatPattern = repeatPattern  // 初始化 repeatPattern
    }
    
    // 实现 Equatable 协议的 == 方法
    static func == (lhs: Reminder, rhs: Reminder) -> Bool {
        return lhs.id == rhs.id &&
               lhs.title == rhs.title &&
               lhs.date == rhs.date &&
               lhs.isCompleted == rhs.isCompleted &&
               lhs.description == rhs.description &&
               lhs.type == rhs.type &&
               lhs.repeatPattern == rhs.repeatPattern
    }
}

class ReminderManager: ObservableObject {
    @Published var reminders: [Reminder] = []
    
    init() {
        loadReminders()
    }
    
    func addReminder(_ reminder: Reminder) {
        reminders.append(reminder)
        saveReminders()
    }
    
    func completeReminder(_ id: UUID) {
        withAnimation {  // 添加动画效果
            if let index = reminders.firstIndex(where: { $0.id == id }) {
                // 如果是重复提醒，创建下一次提醒
                if let pattern = reminders[index].repeatPattern {
                    let calendar = Calendar.current
                    var nextDate: Date?
                    
                    switch pattern {
                    case "daily":
                        nextDate = calendar.date(byAdding: .day, value: 1, to: reminders[index].date)
                    case "alternate":
                        nextDate = calendar.date(byAdding: .day, value: 2, to: reminders[index].date)
                    case let custom where custom.starts(with: "custom_"):
                        if let days = Int(custom.split(separator: "_")[1]) {
                            nextDate = calendar.date(byAdding: .day, value: days, to: reminders[index].date)
                        }
                    default:
                        break
                    }
                    
                    if let nextDate = nextDate {
                        let newReminder = Reminder(
                            title: reminders[index].title,
                            date: nextDate,
                            isCompleted: false,
                            description: reminders[index].description,
                            type: reminders[index].type,
                            repeatPattern: reminders[index].repeatPattern
                        )
                        reminders.append(newReminder)
                    }
                }
                
                // 删除当前提醒
                reminders.remove(at: index)
                saveReminders()
            }
        }
    }
    
    private func loadReminders() {
        if let data = UserDefaults.standard.data(forKey: "reminders") {
            if let decoded = try? JSONDecoder().decode([Reminder].self, from: data) {
                self.reminders = decoded
            }
        }
    }
    
    private func saveReminders() {
        if let encoded = try? JSONEncoder().encode(reminders) {
            UserDefaults.standard.set(encoded, forKey: "reminders")
        }
    }
    
    // 获取指定日期的提醒
    func getReminders(for date: Date) -> [Reminder] {
        let calendar = Calendar.current
        return reminders.filter { reminder in
            // 如果已完成，不显示
            if reminder.isCompleted {
                return false
            }
            
            // 检查是否是同一天
            if calendar.isDate(reminder.date, inSameDayAs: date) {
                return true
            }
            
            // 处理重复提醒
            if let pattern = reminder.repeatPattern {
                let daysDifference = calendar.dateComponents([.day], from: reminder.date, to: date).day ?? 0
                
                switch pattern {
                case "daily":
                    return true
                case "alternate":
                    return daysDifference % 2 == 0
                case let custom where custom.starts(with: "custom_"):
                    if let days = Int(custom.split(separator: "_")[1]) {
                        return daysDifference % days == 0
                    }
                default:
                    return false
                }
            }
            
            return false
        }
    }
}
