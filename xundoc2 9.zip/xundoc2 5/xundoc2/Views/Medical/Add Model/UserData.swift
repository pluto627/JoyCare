import Foundation

struct UserData: Codable {
    var name: String
    var id: String
    var gender: String
    var birthDate: Date
    var phone: String
    var email: String
    var address: String
    var avatarData: Data?
}

class UserDataManager: ObservableObject {
    @Published var userData: UserData {
        didSet {
            saveUserData()
        }
    }
    
    init() {
        if let savedData = UserDefaults.standard.data(forKey: "userData"),
           let decodedData = try? JSONDecoder().decode(UserData.self, from: savedData) {
            self.userData = decodedData
        } else {
            self.userData = UserData(
                name: "陈美玲",
                id: "88888888",
                gender: "女",
                birthDate: Date(),
                phone: "13800138000",
                email: "chen@example.com",
                address: "上海市浦东新区张江高科技园区",
                avatarData: nil
            )
        }
    }
    
    private func saveUserData() {
        if let encoded = try? JSONEncoder().encode(userData) {
            UserDefaults.standard.set(encoded, forKey: "userData")
        }
    }
}
