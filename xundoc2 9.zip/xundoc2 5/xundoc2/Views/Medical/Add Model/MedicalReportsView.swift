import SwiftUI

struct MedicalReportsView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var reportType = "血常规"
    @State private var reportDate = Date()
    @State private var selectedImages: [UIImage] = []
    @State private var showImagePicker = false
    @State private var showAlert = false
    let recordId: UUID  // 添加病历ID参数
    
    // 添加一个回调闭包来处理保存
    var onSave: ((MedicalReport) -> Void)?
    
    let reportTypes = ["血常规", "心电图", "CT", "核磁共振", "B超", "其他"]
    
    var body: some View {
        Form {
            Section(header: Text("报告信息")) {
                Picker("报告类型", selection: $reportType) {
                    ForEach(reportTypes, id: \.self) { type in
                        Text(type).tag(type)
                    }
                }
                DatePicker("检查日期", selection: $reportDate, displayedComponents: .date)
            }
            
            Section(header: Text("报告图片")) {
                if !selectedImages.isEmpty {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 10) {
                            ForEach(selectedImages.indices, id: \.self) { index in
                                Image(uiImage: selectedImages[index])
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 200, height: 200)
                                    .clipShape(RoundedRectangle(cornerRadius: 10))
                                    .overlay(
                                        Button(action: {
                                            selectedImages.remove(at: index)
                                        }) {
                                            Image(systemName: "xmark.circle.fill")
                                                .foregroundColor(.red)
                                                .padding(8)
                                        }
                                        .offset(x: 8, y: -8),
                                        alignment: .topTrailing
                                    )
                            }
                        }
                        .padding(.vertical)
                    }
                }
                
                Button(action: {
                    showImagePicker = true
                }) {
                    HStack {
                        Image(systemName: "photo")
                        Text(selectedImages.isEmpty ? "添加报告图片" : "添加更多图片")
                    }
                }
            }
            
            Section {
                Button(action: saveReport) {
                    Text("保存报告")
                        .frame(maxWidth: .infinity)
                        .foregroundColor(.white)
                }
                .listRowBackground(Color.blue)
            }
        }
        .navigationTitle("添加检查报告")
        .sheet(isPresented: $showImagePicker) {
            ImagePicker(selectedImages: $selectedImages, sourceType: .photoLibrary)
        }
        .alert("保存成功", isPresented: $showAlert) {
            Button("确定") {
                dismiss()
            }
        }
    }
    
    private func saveReport() {
        let report = MedicalReport(
            recordId: recordId,  // 添加病历ID
            type: reportType,
            date: reportDate,
            images: selectedImages
        )
        
        onSave?(report)
        // 保存到本地存储
        var savedReports = ReportStorage.shared.loadReports()
        savedReports.append(report)
        ReportStorage.shared.saveReports(savedReports)
        
        showAlert = true
    }
}
#Preview {
    MedicalReportsView(recordId: UUID()) // 添加一个测试用的 UUID
}
