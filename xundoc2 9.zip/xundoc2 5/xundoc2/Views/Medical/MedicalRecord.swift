import SwiftUI
import UIKit

// ShareSheet 包装器
struct ShareSheet: UIViewControllerRepresentable {
    let activityItems: [Any]
    
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
    }
    
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

// 数据模型

// 修改后的主视图
struct MedicalMainView: View {
    @State private var showingMedicalRecord = false
    @State private var medicalRecords: [MedicalRecord] = []
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 16) {
                    Text("就诊记录")
                        .font(.system(size: 34))
                        .fontWeight(.bold)
                        .padding(.top, 20)
                        .padding(.horizontal)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    
                    ForEach(medicalRecords.sorted(by: { $0.date > $1.date })) { record in
                        MedicalRecordCard(record: record, medicalRecords: $medicalRecords)
                            .padding(.horizontal)
                    }
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        showingMedicalRecord = true
                    }) {
                        HStack(spacing: 6) {
                            Image(systemName: "plus")
                            Text("新增")
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 10)
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(16)
                    }
                }
            }
            .sheet(isPresented: $showingMedicalRecord) {
                AddMedicalRecordView(medicalRecords: $medicalRecords)
                    .presentationDetents([.medium])
                    .presentationDragIndicator(.visible)
            }
        }
        .onAppear {
            // 加载保存的记录
            medicalRecords = MedicalRecordStorage.shared.loadRecords()
        }
    }
}


// 记录卡片视图
struct MedicalRecordCard: View {
    let record: MedicalRecord
    @Binding var medicalRecords: [MedicalRecord]
    @State private var showingDeleteAlert = false
    @State private var showingShareSheet = false
    
    var body: some View {
        NavigationLink(destination: MedicalRecordDetailView(record: record)) {
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    Text(formatDate(record.date))
                        .foregroundColor(.gray)
                    Spacer()
                    Text(record.department)
                        .font(.subheadline)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color.blue.opacity(0.1))
                        .foregroundColor(.blue)
                        .cornerRadius(4)
                }
                
                Text(record.hospital)
                    .font(.title3)
                    .fontWeight(.medium)
                
                HStack {
                    Text("主要症状：")
                        .foregroundColor(.gray)
                    Text(record.symptoms)
                }
            }
            .padding()
            .background(Color(UIColor.systemBackground))
            .cornerRadius(12)
            .shadow(color: Color.black.opacity(0.05), radius: 8, x: 0, y: 2)
        }
        .buttonStyle(PlainButtonStyle()) // 保持卡片原来的样式，不显示为按钮样式
        .contextMenu {
            Button(action: {
                showingShareSheet = true
            }) {
                Label("分享", systemImage: "square.and.arrow.up")
            }
            
            Button(action: {
                UIPasteboard.general.string = "\(record.hospital)\n\(record.department)\n症状：\(record.symptoms)"
            }) {
                Label("复制", systemImage: "doc.on.doc")
            }
            
            Button(role: .destructive, action: {
                showingDeleteAlert = true
            }) {
                Label("删除", systemImage: "trash")
            }
        }
        .alert("确认删除", isPresented: $showingDeleteAlert) {
            Button("取消", role: .cancel) { }
            Button("删除", role: .destructive) {
                deleteRecord()
            }
        } message: {
            Text("确定要删除这条就诊记录吗？")
        }
        .sheet(isPresented: $showingShareSheet) {
            let shareText = """
            医院：\(record.hospital)
            科室：\(record.department)
            就诊时间：\(formatDate(record.date))
            症状：\(record.symptoms)
            """
            ShareSheet(activityItems: [shareText])
        }
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "M/d/yyyy"
        return formatter.string(from: date)
    }
    
    private func deleteRecord() {
        if let index = medicalRecords.firstIndex(where: { $0.id == record.id }) {
            medicalRecords.remove(at: index)
            // 保存更改
            MedicalRecordStorage.shared.saveRecords(medicalRecords)
        }
    }
}
// 这里需要添加 AddMedicalRecordView 的定义，如果你还没有实现

// Preview Provider
struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        MedicalMainView()
    }
}




public struct MedicalRecord: Identifiable, Codable {
    public let id: UUID
    public let date: Date
    public let hospital: String
    public let department: String
    public let symptoms: String
    public let hospitalAddress: String
    
    public init(id: UUID = UUID(), date: Date, hospital: String, department: String, symptoms: String, hospitalAddress: String) {
        self.id = id
        self.date = date
        self.hospital = hospital
        self.department = department
        self.symptoms = symptoms
        self.hospitalAddress = hospitalAddress
    }
} 
