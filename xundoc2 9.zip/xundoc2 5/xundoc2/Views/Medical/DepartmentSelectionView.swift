import SwiftUI

struct DepartmentSelectionView: View {
    @Environment(\.dismiss) private var dismiss
    @Binding var selectedDepartment: String
    
    private let departments = [
        "内科", "外科", "妇产科", "儿科", "眼科",
        "耳鼻喉科", "口腔科", "皮肤科", "神经内科",
        "心血管内科", "呼吸内科", "消化内科", "肾内科",
        "内分泌科", "血液科", "肿瘤科", "精神科",
        "康复科", "营养科", "急诊科"
    ]
    
    var body: some View {
        List {
            ForEach(departments, id: \.self) { department in
                Button(action: {
                    selectedDepartment = department
                    dismiss()
                }) {
                    HStack {
                        Text(department)
                            .foregroundColor(.primary)
                        Spacer()
                        if department == selectedDepartment {
                            Image(systemName: "checkmark")
                                .foregroundColor(.blue)
                        }
                    }
                }
            }
        }
        .navigationTitle("选择科室")
        .navigationBarTitleDisplayMode(.inline)
    }
}

