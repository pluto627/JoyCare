import SwiftUI

struct DepartmentsView: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var searchText = ""
    
    // 示例科室数据
    let departments = [
        DepartmentGroup(name: "内科", departments: [
            Department(name: "呼吸内科", description: "治疗呼吸系统疾病"),
            Department(name: "消化内科", description: "治疗消化系统疾病"),
            Department(name: "心血管内科", description: "治疗心脏和血管疾病"),
            Department(name: "神经内科", description: "治疗神经系统疾病")
        ]),
        DepartmentGroup(name: "外科", departments: [
            Department(name: "普外科", description: "进行常见外科手术"),
            Department(name: "骨科", description: "治疗骨骼和关节疾病"),
            Department(name: "神经外科", description: "进行脑部和脊髓手术"),
            Department(name: "心胸外科", description: "进行心脏和胸腔手术")
        ]),
        DepartmentGroup(name: "专科", departments: [
            Department(name: "眼科", description: "治疗眼部疾病"),
            Department(name: "耳鼻喉科", description: "治疗耳鼻喉疾病"),
            Department(name: "皮肤科", description: "治疗皮肤疾病"),
            Department(name: "口腔科", description: "治疗口腔疾病")
        ])
    ]
    
    var filteredDepartments: [DepartmentGroup] {
        if searchText.isEmpty {
            return departments
        } else {
            return departments.map { group in
                DepartmentGroup(
                    name: group.name,
                    departments: group.departments.filter { $0.name.contains(searchText) }
                )
            }.filter { !$0.departments.isEmpty }
        }
    }
    
    var body: some View {
        NavigationView {
            VStack {
                // 搜索栏
                SearchBark(text: $searchText)
                    .padding()
                
                List {
                    ForEach(filteredDepartments) { group in
                        Section(header: Text(group.name).font(.headline)) {
                            ForEach(group.departments) { department in
                                VStack(alignment: .leading, spacing: 6) {
                                    Text(department.name)
                                        .font(.system(size: 17))
                                    
                                    Text(department.description)
                                        .font(.subheadline)
                                        .foregroundColor(.gray)
                                }
                                .padding(.vertical, 8)
                            }
                        }
                    }
                }
            }
            .navigationTitle("科室")
            .navigationBarTitleDisplayMode(.inline)
            
        }
    }
}

// 科室组数据模型
struct DepartmentGroup: Identifiable {
    let id = UUID()
    let name: String
    let departments: [Department]
}

// 科室数据模型
struct Department: Identifiable {
    let id = UUID()
    let name: String
    let description: String
}

// 搜索栏组件（与HospitalsView中相同）
struct SearchBark: View {
    @Binding var text: String
    
    var body: some View {
        HStack {
            Image(systemName: "magnifyingglass")
                .foregroundColor(.gray)
            
            TextField("搜索科室", text: $text)
                .textFieldStyle(PlainTextFieldStyle())
            
            if !text.isEmpty {
                Button(action: {
                    text = ""
                }) {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundColor(.gray)
                }
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(Color(.systemGray6))
        .cornerRadius(10)
    }
}

#Preview {
    DepartmentsView()
}
