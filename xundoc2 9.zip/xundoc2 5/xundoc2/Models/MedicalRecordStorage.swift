import Foundation

class MedicalRecordStorage {
    static let shared = MedicalRecordStorage()
    private let defaults = UserDefaults.standard
    private let key = "savedMedicalRecords"
    
    func saveRecords(_ records: [MedicalRecord]) {
        if let encoded = try? JSONEncoder().encode(records) {
            defaults.set(encoded, forKey: key)
        }
    }
    
    func loadRecords() -> [MedicalRecord] {
        if let data = defaults.data(forKey: key),
           let decoded = try? JSONDecoder().decode([MedicalRecord].self, from: data) {
            return decoded
        }
        return []
    }
    
    func deleteRecord(_ record: MedicalRecord) {
        var records = loadRecords()
        records.removeAll { $0.id == record.id }
        saveRecords(records)
    }
} 