import SwiftUI

struct ContentView: View {
    @State private var selectedTab = 0
    @StateObject private var reminderManager = ReminderManager()
    
    private func tabFeedback() {
        let generator = UIImpactFeedbackGenerator(style: .medium)
        generator.impactOccurred()
    }
    
    var body: some View {
        TabView(selection: $selectedTab) {
            // Today page
            HomeView(reminderManager: reminderManager)
                .tabItem {
                    Image(systemName: "calendar")
                        .environment(\.symbolVariants, selectedTab == 0 ? .fill : .none)
                    Text("今日")
                }
                .tag(0)
                .onChange(of: selectedTab) { oldValue, newValue in
                    if newValue == 0 {
                        tabFeedback()
                    }
                }
            
            // Reminder page
            ReminderView(reminderManager: reminderManager)
                .tabItem {
                    Image(systemName: "bell")
                        .environment(\.symbolVariants, selectedTab == 1 ? .fill : .none)
                    Text("提醒")
                }
                .tag(1)
                .onChange(of: selectedTab) { oldValue, newValue in
                    if newValue == 1 {
                        tabFeedback()
                    }
                }
            
            // Records page
            MedicalMainView()
                .tabItem {
                    Image(systemName: "cross.case")
                        .environment(\.symbolVariants, selectedTab == 2 ? .fill : .none)
                    Text("病例记录")
                }
                .tag(2)
                .onChange(of: selectedTab) { oldValue, newValue in
                    if newValue == 2 {
                        tabFeedback()
                    }
                }
            
            // Profile page
            ProfileView()
                .tabItem {
                    Image(systemName: "person")
                        .environment(\.symbolVariants, selectedTab == 3 ? .fill : .none)
                    Text("我的")
                }
                .tag(3)
                .onChange(of: selectedTab) { oldValue, newValue in
                    if newValue == 3 {
                        tabFeedback()
                    }
                }
        }
        .tint(Color(hex: "9253f3"))  // 选中状态的颜色
        .onAppear {
            // 设置未选中状态的颜色
            let appearance = UITabBarAppearance()
            appearance.stackedLayoutAppearance.normal.iconColor = UIColor(hex: "333333")
            appearance.stackedLayoutAppearance.normal.titleTextAttributes = [.foregroundColor: UIColor(hex: "333333")]
            UITabBar.appearance().standardAppearance = appearance
            UITabBar.appearance().scrollEdgeAppearance = appearance
        }
    }
}

// 为 UIColor 添加初始化方法
extension UIColor {
    convenience init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int = UInt64()
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3: // RGB (12-bit)
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6: // RGB (24-bit)
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8: // ARGB (32-bit)
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (255, 0, 0, 0)
        }
        self.init(red: CGFloat(r) / 255, green: CGFloat(g) / 255, blue: CGFloat(b) / 255, alpha: CGFloat(a) / 255)
    }
}

#Preview {
    ContentView()
}
