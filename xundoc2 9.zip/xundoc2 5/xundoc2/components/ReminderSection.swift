import SwiftUI

struct ReminderSection: View {
    @Environment(\.colorScheme) private var colorScheme
    @ObservedObject var reminderManager: ReminderManager
    @State private var showingAddReminder = false
    
    var body: some View {
        VStack(spacing: 0) {
            // 标题栏
            HStack {
                Text("今日提醒")
                    .font(.system(size: 18, weight: .medium))
                    .foregroundColor(colorScheme == .dark ? .white : .black)
                Spacer()
                Button(action: {
                    showingAddReminder = true
                }) {
                    Image(systemName: "plus.circle.fill")
                        .font(.system(size: 20))
                        .foregroundColor(.blue)
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            
            // 提醒列表
            VStack(spacing: 12) {
                ForEach(reminderManager.getReminders(for: Date())) { reminder in
                    ReminderItemView(reminder: reminder, reminderManager: reminderManager)
                        .background(
                            RoundedRectangle(cornerRadius: 12)
                                .fill(colorScheme == .dark ? Color(.systemGray6) : .white)
                                .shadow(
                                    color: Color.black.opacity(0.05),
                                    radius: 8,
                                    x: 0,
                                    y: 2
                                )
                        )
                        .padding(.horizontal, 16)
                }
            }
            .padding(.bottom, 16)
        }
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(colorScheme == .dark ? Color(.systemGray6) : .white)
                .shadow(
                    color: Color.black.opacity(0.08),
                    radius: 15,
                    x: 0,
                    y: 5
                )
        )
        .sheet(isPresented: $showingAddReminder) {
            SelectReminderTypeView(reminderManager: reminderManager)
        }
    }
}
import SwiftUI

struct ReminderItemView: View {
    let reminder: Reminder
    @ObservedObject var reminderManager: ReminderManager
    @State private var showingEditSheet = false
    @Environment(\.colorScheme) private var colorScheme
    
    private func getTypeIcon(_ type: String) -> String {
        switch type {
        case "用药提醒":
            return "pills.fill"
        case "检测提醒":
            return "heart.text.square.fill"
        case "就医提醒":
            return "cross.case.fill"
        case "运动提醒":
            return "figure.run"
        case "坐卧提醒":
            return "bed.double.fill"
        case "饮食提醒":
            return "fork.knife"
        case "睡眠提醒":
            return "moon.zzz.fill"
        default:
            return "bell.fill"
        }
    }
    
    var body: some View {
        Button(action: {
            showingEditSheet = true
        }) {
            HStack(spacing: 16) {  // 增加间距
                // 时间显示
                VStack(spacing: 4) {
                    Image(systemName: getTypeIcon(reminder.type))
                        .foregroundColor(.purple)
                        .font(.system(size: 24))  // 增加图标大小
                    Text(formatTime(reminder.date))
                        .font(.system(size: 16, weight: .medium))
                        .foregroundColor(.purple)
                }
                .frame(width: 60)  // 增加宽度
                
                // 分隔线
                Rectangle()
                    .fill(Color(.systemGray5))
                    .frame(width: 1, height: 50)  // 增加高度
                
                // 提醒内容
                VStack(alignment: .leading, spacing: 6) {  // 增加垂直间距
                    HStack(alignment: .top, spacing: 8) {  // 调整对齐方式
                        Text(reminder.title)
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(colorScheme == .dark ? .white : .black)
                            .fixedSize(horizontal: false, vertical: true)  // 允许换行
                        
                        if let repeatPattern = reminder.repeatPattern {
                            HStack(spacing: 4) {
                                Image(systemName: "repeat")
                                    .font(.system(size: 12))
                                    .foregroundColor(.gray)
                                Text(getRepeatText(for: repeatPattern))
                                    .font(.system(size: 12))
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                    
                    if let description = reminder.description {
                        Text(description)
                            .font(.system(size: 14))
                            .foregroundColor(.gray)
                            .fixedSize(horizontal: false, vertical: true)  // 允许换行
                            .multilineTextAlignment(.leading)  // 保持左对齐
                    }
                }
                .padding(.vertical, 4)  // 添加垂直内边距
                
                Spacer(minLength: 20)  // 确保有最小间距
                
                // 完成按钮
                Button(action: {
                    reminderManager.completeReminder(reminder.id)
                }) {
                    Text("完成")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(.white)
                        .padding(.horizontal, 16)  // 增加按钮水平内边距
                        .padding(.vertical, 8)     // 增加按钮垂直内边距
                        .background(Color.purple)
                        .cornerRadius(18)          // 增加圆角
                }
            }
            .padding(.vertical, 16)    // 增加垂直内边距
            .padding(.horizontal, 20)  // 增加水平内边距
        }
        .sheet(isPresented: $showingEditSheet) {
            EditReminderView(reminder: reminder, reminderManager: reminderManager)
        }
    }
    
    private func getRepeatText(for pattern: String) -> String {
        switch pattern {
        case "daily":
            return "每天"
        case "alternate":
            return "隔天"
        case let custom where custom.starts(with: "custom_"):
            let days = custom.split(separator: "_")[1]
            return "每\(days)天"
        default:
            return ""
        }
    }
    
    private func formatTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        return formatter.string(from: date)
    }
}

struct EditReminderView: View {
    @Environment(\.dismiss) var dismiss
    @ObservedObject var reminderManager: ReminderManager
    @State private var title: String
    @State private var selectedTime: Date
    @State private var selectedType: String
    @State private var description: String
    @State private var showDeleteAlert = false
    @State private var selectedFrequency: String
    @State private var customDays: Int
    
    let reminder: Reminder
    
    init(reminder: Reminder, reminderManager: ReminderManager) {
        self.reminder = reminder
        self.reminderManager = reminderManager
        _title = State(initialValue: reminder.title)
        _selectedTime = State(initialValue: reminder.date)
        _selectedType = State(initialValue: reminder.type)
        _description = State(initialValue: reminder.description ?? "")
        
        // 初始化重复模式
        let (frequency, days) = Self.parseRepeatPattern(reminder.repeatPattern)
        _selectedFrequency = State(initialValue: frequency)
        _customDays = State(initialValue: days)
    }
    
    private static func parseRepeatPattern(_ pattern: String?) -> (String, Int) {
        guard let pattern = pattern else { return ("不重复", 1) }
        
        switch pattern {
        case "daily":
            return ("每天", 1)
        case "alternate":
            return ("隔天", 2)
        case let custom where custom.starts(with: "custom_"):
            let days = Int(custom.split(separator: "_")[1]) ?? 1
            return ("自定义", days)
        default:
            return ("不重复", 1)
        }
    }
    
    private let reminderTypes = [
        "用药提醒",
        "检测提醒",
        "就医提醒",
        "运动提醒",
        "坐卧提醒",
        "饮食提醒",
        "睡眠提醒"
    ]
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("基本信息")) {
                    TextField("提醒内容", text: $title)
                    DatePicker("提醒时间", selection: $selectedTime, displayedComponents: .hourAndMinute)
                }
                
                Section(header: Text("提醒类型")) {
                    Picker("类型", selection: $selectedType) {
                        ForEach(reminderTypes, id: \.self) { type in
                            Text(type).tag(type)
                        }
                    }
                }
                
                Section(header: Text("重复")) {
                    Picker("重复", selection: $selectedFrequency) {
                        Text("不重复").tag("不重复")
                        Text("每天").tag("每天")
                        Text("隔天").tag("隔天")
                        Text("自定义").tag("自定义")
                    }
                    
                    if selectedFrequency == "自定义" {
                        Stepper("每隔 \(customDays) 天", value: $customDays, in: 1...30)
                    }
                }
                
                Section(header: Text("备注")) {
                    TextEditor(text: $description)
                        .frame(height: 100)
                }
                
                Section {
                                    HStack {
                                        Spacer()
                                        Button(action: {
                                            showDeleteAlert = true
                                        }) {
                                            Text("删除提醒")
                                                .foregroundColor(.red)
                                        }
                                        Spacer()
                                    }
                                }
            }
            .navigationTitle("编辑提醒")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("取消") {
                        dismiss()
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("保存") {
                        saveChanges()
                    }
                    .disabled(title.isEmpty)
                }
            }
            .alert("确认删除", isPresented: $showDeleteAlert) {
                Button("取消", role: .cancel) { }
                Button("删除", role: .destructive) {
                    deleteReminder()
                }
            } message: {
                Text("确定要删除这个提醒吗？此操作无法撤销。")
            }
        }
    }
    
    private func getRepeatPattern() -> String? {
        switch selectedFrequency {
        case "每天":
            return "daily"
        case "隔天":
            return "alternate"
        case "自定义":
            return "custom_\(customDays)"
        default:
            return nil
        }
    }
    
    private func saveChanges() {
        let updatedReminder = Reminder(
            id: reminder.id,
            title: title,
            date: selectedTime,
            isCompleted: reminder.isCompleted,
            description: description.isEmpty ? nil : description,
            type: selectedType,
            repeatPattern: getRepeatPattern()
        )
        
        // 先删除旧的提醒
        reminderManager.reminders.removeAll { $0.id == reminder.id }
        // 添加更新后的提醒
        reminderManager.addReminder(updatedReminder)
        
        dismiss()
    }

    private func deleteReminder() {
        // 使用数组过滤来删除提醒
        reminderManager.reminders.removeAll { $0.id == reminder.id }
        // 添加一个空的提醒并立即删除它来触发保存
        let tempReminder = Reminder(title: "", date: Date(), type: "")
        reminderManager.addReminder(tempReminder)
        reminderManager.reminders.removeAll { $0.id == tempReminder.id }
        
        dismiss()
    }
}

#Preview {
    ReminderSection(reminderManager: ReminderManager())
        .padding()
        .background(Color(.systemGray6))
}
