import SwiftUI

struct AIHealthAssistant: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("AI 健康助手")
                .font(.title3)
                .bold()
            
            HStack {
                Text("请输入您的健康问题...")
                    .foregroundColor(.gray)
                Spacer()
                Image(systemName: "paperplane.fill")
                    .foregroundColor(.blue)
            }
            .padding()
            .background(Color.gray.opacity(0.1))
            .cornerRadius(10)
        }
    }
}


#Preview {
    AIHealthAssistant()
}
