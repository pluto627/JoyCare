import Foundation
import HealthKit

class HealthKitManager: ObservableObject {
    static let shared = HealthKitManager()
    
    private let healthStore = HKHealthStore()
    
    @Published var steps: Int = 0
    @Published var calories: Double = 0.0
    @Published var distance: Double = 0.0
    @Published var lastUpdateTime: Date = Date()
    @Published var heartRate: Double = 0.0
    @Published var systolicPressure: Double = 0.0
    @Published var diastolicPressure: Double = 0.0
    @Published var sleepHours: Double = 0.0
    
    // 需要读取的数据类型
    private let typesToRead: Set = [
        HKQuantityType.quantityType(forIdentifier: .stepCount)!,
        HKQuantityType.quantityType(forIdentifier: .distanceWalkingRunning)!,
        HKQuantityType.quantityType(forIdentifier: .activeEnergyBurned)!,
        HKQuantityType.quantityType(forIdentifier: .heartRate)!,
        HKQuantityType.quantityType(forIdentifier: .bloodPressureSystolic)!,
        HKQuantityType.quantityType(forIdentifier: .bloodPressureDiastolic)!,
        HKCategoryType.categoryType(forIdentifier: .sleepAnalysis)!
    ]
    
    private init() {
        requestAuthorization { success, error in
            if success {
                self.updateData()
            }
        }
    }
    
    func requestAuthorization(completion: @escaping (Bool, Error?) -> Void) {
        guard HKHealthStore.isHealthDataAvailable() else {
            completion(false, nil)
            return
        }
        
        healthStore.requestAuthorization(toShare: nil, read: typesToRead) { success, error in
            completion(success, error)
        }
    }
    
    func updateData() {
        fetchStepCount(for: Date()) { steps in
            DispatchQueue.main.async {
                self.steps = Int(steps)
            }
        }
        
        fetchCalories { calories in
            DispatchQueue.main.async {
                self.calories = calories
            }
        }
        
        fetchDistance { distance in
            DispatchQueue.main.async {
                self.distance = distance
            }
        }
        
        fetchHeartRate { rate in
            DispatchQueue.main.async {
                self.heartRate = rate
            }
        }
        
        fetchBloodPressure { systolic, diastolic in
            DispatchQueue.main.async {
                self.systolicPressure = systolic
                self.diastolicPressure = diastolic
            }
        }
        
        fetchSleepAnalysis { hours in
            DispatchQueue.main.async {
                self.sleepHours = hours
            }
        }
        
        self.lastUpdateTime = Date()
    }
    
    func fetchStepCount(for date: Date, completion: @escaping (Double) -> Void) {
        let steps = HKQuantityType.quantityType(forIdentifier: .stepCount)!
        let predicate = HKQuery.predicateForSamples(withStart: date.startOfDay, end: date.endOfDay)
        
        let query = HKStatisticsQuery(quantityType: steps,
                                    quantitySamplePredicate: predicate,
                                    options: .cumulativeSum) { _, result, _ in
            guard let result = result,
                  let sum = result.sumQuantity() else {
                completion(0.0)
                return
            }
            completion(sum.doubleValue(for: HKUnit.count()))
        }
        healthStore.execute(query)
    }
    
    func fetchCalories(completion: @escaping (Double) -> Void) {
        let calories = HKQuantityType.quantityType(forIdentifier: .activeEnergyBurned)!
        let predicate = HKQuery.predicateForSamples(withStart: Date().startOfDay, end: Date().endOfDay)
        
        let query = HKStatisticsQuery(quantityType: calories,
                                    quantitySamplePredicate: predicate,
                                    options: .cumulativeSum) { _, result, _ in
            guard let result = result,
                  let sum = result.sumQuantity() else {
                completion(0.0)
                return
            }
            completion(sum.doubleValue(for: HKUnit.kilocalorie()))
        }
        healthStore.execute(query)
    }
    
    func fetchDistance(completion: @escaping (Double) -> Void) {
        let distance = HKQuantityType.quantityType(forIdentifier: .distanceWalkingRunning)!
        let predicate = HKQuery.predicateForSamples(withStart: Date().startOfDay, end: Date().endOfDay)
        
        let query = HKStatisticsQuery(quantityType: distance,
                                    quantitySamplePredicate: predicate,
                                    options: .cumulativeSum) { _, result, _ in
            guard let result = result,
                  let sum = result.sumQuantity() else {
                completion(0.0)
                return
            }
            // 将米转换为千米
            let distanceInMeters = sum.doubleValue(for: HKUnit.meter())
            let distanceInKilometers = distanceInMeters / 1000.0
            completion(distanceInKilometers)
        }
        healthStore.execute(query)
    }
    
    func fetchHeartRate(completion: @escaping (Double) -> Void) {
        let heartRate = HKQuantityType.quantityType(forIdentifier: .heartRate)!
        let predicate = HKQuery.predicateForSamples(withStart: Date().addingTimeInterval(-3600), end: Date())
        
        let query = HKStatisticsQuery(quantityType: heartRate,
                                    quantitySamplePredicate: predicate,
                                    options: .discreteAverage) { _, result, _ in
            guard let result = result,
                  let average = result.averageQuantity() else {
                completion(0.0)
                return
            }
            completion(average.doubleValue(for: HKUnit.count().unitDivided(by: HKUnit.minute())))
        }
        healthStore.execute(query)
    }
    
    func fetchBloodPressure(completion: @escaping (Double, Double) -> Void) {
        let systolic = HKQuantityType.quantityType(forIdentifier: .bloodPressureSystolic)!
        let diastolic = HKQuantityType.quantityType(forIdentifier: .bloodPressureDiastolic)!
        let predicate = HKQuery.predicateForSamples(withStart: Date().addingTimeInterval(-86400), end: Date())
        
        let systolicQuery = HKStatisticsQuery(quantityType: systolic,
                                            quantitySamplePredicate: predicate,
                                            options: .discreteAverage) { _, result, _ in
            guard let result = result,
                  let average = result.averageQuantity() else {
                completion(0.0, 0.0)
                return
            }
            let systolicValue = average.doubleValue(for: HKUnit.millimeterOfMercury())
            
            let diastolicQuery = HKStatisticsQuery(quantityType: diastolic,
                                                 quantitySamplePredicate: predicate,
                                                 options: .discreteAverage) { _, result, _ in
                guard let result = result,
                      let average = result.averageQuantity() else {
                    completion(systolicValue, 0.0)
                    return
                }
                let diastolicValue = average.doubleValue(for: HKUnit.millimeterOfMercury())
                completion(systolicValue, diastolicValue)
            }
            self.healthStore.execute(diastolicQuery)
        }
        healthStore.execute(systolicQuery)
    }
    
    func fetchSleepAnalysis(completion: @escaping (Double) -> Void) {
        let sleepType = HKObjectType.categoryType(forIdentifier: .sleepAnalysis)!
        let predicate = HKQuery.predicateForSamples(withStart: Date().addingTimeInterval(-86400), end: Date())
        
        let query = HKSampleQuery(sampleType: sleepType,
                                predicate: predicate,
                                limit: HKObjectQueryNoLimit,
                                sortDescriptors: nil) { _, samples, _ in
            guard let samples = samples as? [HKCategorySample] else {
                completion(0.0)
                return
            }
            
            let totalSleepTime = samples.reduce(0.0) { total, sample in
                return total + sample.endDate.timeIntervalSince(sample.startDate)
            }
            completion(totalSleepTime / 3600) // 转换为小时
        }
        healthStore.execute(query)
    }
}

// Date 扩展
extension Date {
    var startOfDay: Date {
        return Calendar.current.startOfDay(for: self)
    }
    
    var endOfDay: Date {
        var components = DateComponents()
        components.day = 1
        components.second = -1
        return Calendar.current.date(byAdding: components, to: startOfDay)!
    }
} 
