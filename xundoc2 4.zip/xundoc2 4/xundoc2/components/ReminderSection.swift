import SwiftUI

struct ReminderSection: View {
    @Environment(\.colorScheme) private var colorScheme
    @ObservedObject var reminderManager: ReminderManager
    @State private var showingAddReminder = false
    
    var body: some View {
        VStack(spacing: 0) {
            // 标题栏
            HStack {
                Text("今日提醒")
                    .font(.system(size: 18, weight: .medium))
                    .foregroundColor(colorScheme == .dark ? .white : .black)
                Spacer()
                Button(action: {
                    showingAddReminder = true
                }) {
                    Image(systemName: "plus.circle.fill")
                        .font(.system(size: 20))
                        .foregroundColor(.blue)
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            
            // 提醒列表
            VStack(spacing: 12) {
                ForEach(reminderManager.reminders.filter { reminder in
                    !reminder.isCompleted &&
                    Calendar.current.isDate(reminder.date, inSameDayAs: Date())
                }) { reminder in
                    ReminderItemView(reminder: reminder, reminderManager: reminderManager)
                        .background(
                            RoundedRectangle(cornerRadius: 12)
                                .fill(colorScheme == .dark ? Color(.systemGray6) : .white)
                                .shadow(
                                    color: Color.black.opacity(0.05),
                                    radius: 8,
                                    x: 0,
                                    y: 2
                                )
                        )
                        .padding(.horizontal, 16)
                }
            }
            .padding(.bottom, 16)
        }
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(colorScheme == .dark ? Color(.systemGray6) : .white)
                .shadow(
                    color: Color.black.opacity(0.08),
                    radius: 15,
                    x: 0,
                    y: 5
                )
        )
        .sheet(isPresented: $showingAddReminder) {
            SelectReminderTypeView(reminderManager: reminderManager)
        }
    }
}

struct ReminderItemView: View {
    let reminder: Reminder
    @ObservedObject var reminderManager: ReminderManager
    
    private func getTypeIcon(_ type: String) -> String {
        switch type {
        case "用药提醒":
            return "pills.fill"
        case "检测提醒":
            return "heart.text.square.fill"
        case "就医提醒":
            return "cross.case.fill"
        case "运动提醒":
            return "figure.run"
        case "坐卧提醒":
            return "bed.double.fill"
        case "饮食提醒":
            return "fork.knife"
        case "睡眠提醒":
            return "moon.zzz.fill"
        default:
            return "bell.fill"
        }
    }
    
    var body: some View {
        HStack(spacing: 12) {
            // 时间显示
            VStack(spacing: 4) {
                Image(systemName: getTypeIcon(reminder.type))
                    .foregroundColor(.blue)
                Text(formatTime(reminder.date))
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(.blue)
            }
            .frame(width: 50)
            
            // 分隔线
            Rectangle()
                .fill(Color(.systemGray5))
                .frame(width: 1, height: 40)
            
            // 提醒内容
            VStack(alignment: .leading, spacing: 4) {
                Text(reminder.title)
                    .font(.system(size: 16, weight: .medium))
                if let description = reminder.description {
                    Text(description)
                        .font(.system(size: 14))
                        .foregroundColor(.gray)
                        .lineLimit(1)
                }
            }
            
            Spacer()
            
            // 完成按钮
            Button(action: {
                reminderManager.completeReminder(reminder.id)
            }) {
                Text("完成")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(.white)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(Color.blue)
                    .cornerRadius(15)
            }
        }
        .padding(.vertical, 12)
        .padding(.horizontal, 16)
    }
    
    private func formatTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        return formatter.string(from: date)
    }
}

#Preview {
    ReminderSection(reminderManager: ReminderManager())
        .padding()
        .background(Color(.systemGray6))
}
