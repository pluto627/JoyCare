import SwiftUI
import MapKit
import CoreLocation

// 医院模型
struct Hospital: Identifiable {
    let id = UUID()
    let name: String
    let location: CLLocationCoordinate2D
    let distance: Double // 以米为单位的距离
}

// 地图视图控制器
class HospitalMapViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {
    private var mapView: MKMapView!
    private let locationManager = CLLocationManager()
    private var userLocation: CLLocation?
    private var hospitals: [Hospital] = []
    var onHospitalSelected: ((String) -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 初始化地图
        mapView = MKMapView(frame: view.bounds)
        mapView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        mapView.showsUserLocation = true
        mapView.delegate = self
        view.addSubview(mapView)
        
        // 初始化位置管理器
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters // 降低精度要求
        
        // 检查位置服务授权状态
        checkLocationAuthorization()
    }
    
    // 检查位置服务授权状态
    private func checkLocationAuthorization() {
        switch locationManager.authorizationStatus {
        case .notDetermined:
            locationManager.requestWhenInUseAuthorization()
        case .restricted, .denied:
            // 显示提示，引导用户开启位置服务
            showLocationAlert()
        case .authorizedWhenInUse, .authorizedAlways:
            // 已授权，可以使用位置服务
            startDefaultSearch()
        @unknown default:
            break
        }
    }
    
    // 显示位置服务提示
    private func showLocationAlert() {
        let alert = UIAlertController(
            title: "位置服务未开启",
            message: "请在设置中开启位置服务，以便查找附近医院",
            preferredStyle: .alert
        )
        
        alert.addAction(UIAlertAction(title: "使用默认位置", style: .default) { _ in
            self.startDefaultSearch()
        })
        
        alert.addAction(UIAlertAction(title: "打开设置", style: .default) { _ in
            if let url = URL(string: UIApplication.openSettingsURLString) {
                UIApplication.shared.open(url)
            }
        })
        
        present(alert, animated: true)
    }
    
    // 使用默认位置查找医院（当无法获取用户位置时）
    private func startDefaultSearch() {
        // 使用默认位置（例如城市中心）
        let defaultLocation = CLLocationCoordinate2D(latitude: 39.9042, longitude: 116.4074) // 北京市中心
        let region = MKCoordinateRegion(
            center: defaultLocation,
            span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
        )
        mapView.setRegion(region, animated: true)
        
        // 搜索该区域内的医院
        searchHospitals(in: region)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        // 仅在获得授权时请求位置
        if locationManager.authorizationStatus == .authorizedWhenInUse ||
           locationManager.authorizationStatus == .authorizedAlways {
            locationManager.startUpdatingLocation()
        }
    }
    
    // 开始定位
    func startLocating() {
        if locationManager.authorizationStatus == .authorizedWhenInUse ||
           locationManager.authorizationStatus == .authorizedAlways {
            locationManager.requestLocation() // 使用单次定位而不是持续更新
        } else {
            checkLocationAuthorization()
        }
    }
    
    // 位置更新回调
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.first else { return }
        
        userLocation = location
        
        // 更新地图显示区域
        let region = MKCoordinateRegion(
            center: location.coordinate,
            span: MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02)
        )
        mapView.setRegion(region, animated: true)
        
        // 搜索该区域内的医院
        searchHospitals(in: region)
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("位置获取失败: \(error.localizedDescription)")
        // 使用默认搜索作为备选方案
        startDefaultSearch()
    }
    
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        checkLocationAuthorization()
    }
    
    // 搜索指定区域内的医院
    private func searchHospitals(in region: MKCoordinateRegion) {
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = "医院"
        request.region = region
        
        let search = MKLocalSearch(request: request)
        search.start { [weak self] (response, error) in
            guard let self = self else { return }
            
            if let error = error {
                print("搜索失败: \(error.localizedDescription)")
                return
            }
            
            // 清除之前的标记
            self.mapView.removeAnnotations(self.mapView.annotations)
            self.hospitals.removeAll()
            
            // 添加新的医院标记
            if let response = response {
                for item in response.mapItems {
                    let annotation = MKPointAnnotation()
                    annotation.title = item.name
                    annotation.coordinate = item.placemark.coordinate
                    
                    var distance: Double = 0
                    if let userLocation = self.userLocation {
                        distance = userLocation.distance(from: CLLocation(
                            latitude: item.placemark.coordinate.latitude,
                            longitude: item.placemark.coordinate.longitude
                        ))
                    }
                    
                    let hospital = Hospital(
                        name: item.name ?? "未知医院",
                        location: item.placemark.coordinate,
                        distance: distance
                    )
                    
                    self.hospitals.append(hospital)
                    self.mapView.addAnnotation(annotation)
                }
                
                // 按距离排序
                self.hospitals.sort { $0.distance < $1.distance }
            } else {
                // 处理没有找到医院的情况
                self.showNoHospitalsAlert()
            }
        }
    }
    
    // 显示未找到医院的提示
    private func showNoHospitalsAlert() {
        let alert = UIAlertController(
            title: "未找到医院",
            message: "当前区域未找到医院信息，请尝试手动输入或更改位置",
            preferredStyle: .alert
        )
        
        alert.addAction(UIAlertAction(title: "确定", style: .default))
        
        present(alert, animated: true)
    }
    
    // 点击标记回调
    func mapView(_ mapView: MKMapView, didSelect annotation: MKAnnotation) {
        guard let title = annotation.title, let hospitalName = title else { return }
        onHospitalSelected?(hospitalName)
        
        // 关闭地图视图
        self.dismiss(animated: true)
    }
    
    // 自定义标记视图
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        // 不为用户位置提供自定义视图
        if annotation is MKUserLocation {
            return nil
        }
        
        let identifier = "HospitalMarker"
        var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)
        
        if annotationView == nil {
            annotationView = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            annotationView?.canShowCallout = true
            
            // 添加详情按钮
            let button = UIButton(type: .detailDisclosure)
            annotationView?.rightCalloutAccessoryView = button
        } else {
            annotationView?.annotation = annotation
        }
        
        return annotationView
    }
    
    // 处理标记详情按钮点击
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        if let title = view.annotation?.title, let hospitalName = title {
            onHospitalSelected?(hospitalName)
            self.dismiss(animated: true)
        }
    }
}

// SwiftUI包装视图
struct HospitalMapView: UIViewControllerRepresentable {
    var onHospitalSelected: (String) -> Void
    
    func makeUIViewController(context: Context) -> HospitalMapViewController {
        let controller = HospitalMapViewController()
        controller.onHospitalSelected = onHospitalSelected
        return controller
    }
    
    func updateUIViewController(_ uiViewController: HospitalMapViewController, context: Context) {
        uiViewController.startLocating()
    }
}
