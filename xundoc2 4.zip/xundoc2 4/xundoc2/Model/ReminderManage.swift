import Foundation

struct Reminder: Identifiable, Codable {
    let id: UUID
    var title: String
    var date: Date
    var isCompleted: Bool
    var description: String?
    var type: String  // 添加类型属性
    
    init(id: UUID = UUID(),
         title: String,
         date: Date,
         isCompleted: Bool = false,
         description: String? = nil,
         type: String = "用药提醒") {
        self.id = id
        self.title = title
        self.date = date
        self.isCompleted = isCompleted
        self.description = description
        self.type = type
    }
}

class ReminderManager: ObservableObject {
    @Published var reminders: [Reminder] = []
    @Published var todayCount: Int = 0
    
    init() {
        loadReminders()
        NotificationManager.shared.requestAuthorization()
    }
    
    func addReminder(_ reminder: Reminder) {
        reminders.append(reminder)
        updateTodayCount()
        saveReminders()
        NotificationManager.shared.scheduleReminderNotification(for: reminder)
    }
    
    func completeReminder(_ id: UUID) {
        if let index = reminders.firstIndex(where: { reminder in reminder.id == id }) {
            reminders[index].isCompleted = true
            updateTodayCount()
            saveReminders()
            NotificationManager.shared.cancelNotification(for: id)
        }
    }
    
    private func updateTodayCount() {
        let today = Calendar.current.startOfDay(for: Date())
        todayCount = reminders.filter { reminder in
            !reminder.isCompleted &&
            Calendar.current.isDate(reminder.date, inSameDayAs: today)
        }.count
    }
    
    private func saveReminders() {
        if let encoded = try? JSONEncoder().encode(reminders) {
            UserDefaults.standard.set(encoded, forKey: "savedReminders")
        }
    }
    
    private func loadReminders() {
        if let savedReminders = UserDefaults.standard.data(forKey: "savedReminders"),
           let decoded = try? JSONDecoder().decode([Reminder].self, from: savedReminders) {
            reminders = decoded
            updateTodayCount()
        }
    }
}
