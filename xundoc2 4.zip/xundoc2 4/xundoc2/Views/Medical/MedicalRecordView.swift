import SwiftUI
import MapKit
import CoreLocation

struct AddMedicalRecordView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) private var colorScheme
    @Binding var medicalRecords: [MedicalRecord]
    @State private var hospital: String = ""
    @State private var department: String = ""
    @State private var symptoms: String = ""
    @State private var showingMap = false
    
    private var backgroundColor: Color {
        colorScheme == .dark ? Color.black : Color.white
    }
    
    private var placeholderColor: Color {
        colorScheme == .dark ? Color.gray.opacity(0.7) : Color.gray.opacity(0.5)
    }
    
    private var borderColor: Color {
        colorScheme == .dark ? Color.gray.opacity(0.5) : Color.gray.opacity(0.3)
    }
    
    private var textColor: Color {
        colorScheme == .dark ? Color.white : Color.black
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                backgroundColor.ignoresSafeArea()
                
                VStack(spacing: 20) {
                    // Hospital Input Field
                    HStack {
                        ZStack(alignment: .leading) {
                            if hospital.isEmpty {
                                Text("输入就诊医院")
                                    .foregroundColor(placeholderColor)
                            }
                            TextField("", text: $hospital)
                                .textFieldStyle(.plain)
                                .foregroundColor(textColor)
                        }
                        Button(action: {
                            showingMap = true
                        }) {
                            Image(colorScheme == .dark ? "MapD" : "MapW")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 24, height: 24)
                        }
                    }
                    .padding()
                    .background(colorScheme == .dark ? Color.white.opacity(0.05) : Color.white)
                    .overlay(
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(borderColor, lineWidth: 1)
                    )
                    
                    // Department Selection
                    NavigationLink(destination: DepartmentSelectionView(selectedDepartment: $department)) {
                        HStack {
                            Text(department.isEmpty ? "选择就诊科室" : department)
                                .foregroundColor(department.isEmpty ? placeholderColor : textColor)
                            Spacer()
                            Image(systemName: "chevron.right")
                                .foregroundColor(placeholderColor)
                        }
                        .padding()
                        .background(colorScheme == .dark ? Color.white.opacity(0.05) : Color.white)
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .stroke(borderColor, lineWidth: 1)
                        )
                    }
                    
                    // Symptoms TextEditor
                    ZStack(alignment: .topLeading) {
                        TextEditor(text: $symptoms)
                            .frame(height: 100)
                            .padding()
                            .foregroundColor(textColor)
                        
                        if symptoms.isEmpty {
                            Text("症状描述")
                                .foregroundColor(placeholderColor)
                                .padding(.leading, 20)
                                .padding(.top, 20)
                        }
                    }
                    .background(colorScheme == .dark ? Color.white.opacity(0.05) : Color.white)
                    .overlay(
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(borderColor, lineWidth: 1)
                    )
                    
                    Spacer()
                    
                    // Save Button
                    Button(action: {
                        saveRecord()
                        dismiss()
                    }) {
                        Text("保存")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(8)
                    }
                }
                .padding()
            }
            .navigationBarTitleDisplayMode(.inline)
            .navigationTitle("新增就诊记录")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("取消") {
                        dismiss()
                    }
                }
            }
            .sheet(isPresented: $showingMap) {
                NavigationView {
                    HospitalMapView { selectedHospital in
                        hospital = selectedHospital
                    }
                    .edgesIgnoringSafeArea(.all)
                    .navigationBarTitle("选择医院", displayMode: .inline)
                    .navigationBarItems(trailing: Button("关闭") {
                        showingMap = false
                    })
                }
            }
        }
    }
    
    private func saveRecord() {
        let newRecord = MedicalRecord(
            date: Date(),
            hospital: hospital,
            department: department,
            symptoms: symptoms
        )
        medicalRecords.append(newRecord)
    }
}

// 确保MedicalRecord模型定义

struct AddMedicalRecordWithMap_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            AddMedicalRecordView(medicalRecords: .constant([]))
                .preferredColorScheme(.light)
            
            AddMedicalRecordView(medicalRecords: .constant([]))
                .preferredColorScheme(.dark)
        }
    }
}
