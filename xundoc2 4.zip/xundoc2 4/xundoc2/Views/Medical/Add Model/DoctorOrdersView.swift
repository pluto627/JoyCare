import SwiftUI

struct DoctorOrdersView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var orderText = ""
    @State private var orderDate = Date()
    @State private var showAlert = false
    
    var body: some View {
        Form {
            Section(header: Text("医嘱内容")) {
                TextEditor(text: $orderText)
                    .frame(height: 150)
                DatePicker("医嘱日期", selection: $orderDate, displayedComponents: .date)
            }
            
            Section {
                Button(action: saveOrder) {
                    Text("保存医嘱")
                        .frame(maxWidth: .infinity)
                        .foregroundColor(.white)
                }
                .listRowBackground(Color.blue)
            }
        }
        .navigationTitle("添加医生医嘱")
        .alert("保存成功", isPresented: $showAlert) {
            Button("确定") {
                dismiss()
            }
        }
    }
    
    private func saveOrder() {
        // 这里添加保存医嘱的逻辑
        showAlert = true
    }
}


#Preview {
    DoctorOrdersView()
}

