import SwiftUI
import HealthKit

struct HealthAnalysisView: View {
    @Environment(\.colorScheme) private var colorScheme
    @State private var selectedTimeRange: TimeRange = .today
    @State private var healthData: [TimeRange: HealthData] = [:]
    private let healthStore = HKHealthStore()
    
    // 添加用户基本信息
    @AppStorage("userHeight") private var userHeight: Double = 170.0
    @AppStorage("userWeight") private var userWeight: Double = 65.0
    @AppStorage("userBirthday") private var userBirthday = Date()
    @AppStorage("userGender") private var userGender: String = "male"
    
    enum TimeRange: String, CaseIterable {
        case today = "今天"
        case yesterday = "昨天"
        case lastWeek = "过去7天"
    }
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                // 时间范围选择器
                Picker("时间范围", selection: $selectedTimeRange) {
                    ForEach(TimeRange.allCases, id: \.self) { range in
                        Text(range.rawValue).tag(range)
                    }
                }
                .pickerStyle(.segmented)
                .padding(.horizontal)
                .padding(.top)
                
                if let data = healthData[selectedTimeRange] {
                    // 活动环
                    ActivityRingsView(data: data)
                        .frame(height: 200)
                        .padding(.vertical)
                    
                    // 详细数据卡片
                    LazyVGrid(columns: [
                        GridItem(.flexible()),
                        GridItem(.flexible())
                    ], spacing: 16) {
                        DataCard(
                            title: "步数",
                            value: "\(data.steps)",
                            unit: "步"
                        )
                        
                        DataCard(
                            title: "睡眠",
                            value: String(format: "%.1f", data.sleepHours),
                            unit: "小时"
                        )
                        
                        DataCard(
                            title: "任务完成",
                            value: "\(data.completedTasks)",
                            unit: "/ \(data.totalTasks)项"
                        )
                        
                        // 添加卡路里目标卡片
                        DataCard(
                            title: "每日卡路里目标",
                            value: "\(data.dailyCalorieGoal)",
                            unit: "千卡"
                        )
                    }
                    .padding(.horizontal)
                    
                    // 添加健康建议部分
                    VStack(alignment: .leading, spacing: 16) {
                        Text("今日建议")
                            .font(.headline)
                            .padding(.horizontal)
                        
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 16) {
                                ForEach(getHealthSuggestions(for: data), id: \.title) { suggestion in
                                    SuggestionCard(suggestion: suggestion)
                                }
                            }
                            .padding(.horizontal)
                        }
                    }
                }
            }
        }
        .navigationTitle("健康分析")
        .onAppear {
            requestHealthKitAuthorization()
        }
    }
    
    private func requestHealthKitAuthorization() {
        // 定义需要读取的数据类型
        let healthTypes: Set<HKSampleType> = [
            HKObjectType.quantityType(forIdentifier: .stepCount)!,
            HKObjectType.categoryType(forIdentifier: .sleepAnalysis)!
        ]
        
        // 请求授权
        healthStore.requestAuthorization(toShare: nil, read: healthTypes) { success, error in
            if success {
                loadHealthData()
            }
        }
    }
    
    private func loadHealthData() {
        // 加载今天的数据
        loadDataForTimeRange(.today)
        // 加载昨天的数据
        loadDataForTimeRange(.yesterday)
        // 加载过去7天的数据
        loadDataForTimeRange(.lastWeek)
    }
    
    private func loadDataForTimeRange(_ timeRange: TimeRange) {
        let calendar = Calendar.current
        let now = Date()
        let startDate: Date
        let endDate: Date
        
        switch timeRange {
        case .today:
            startDate = calendar.startOfDay(for: now)
            endDate = now
        case .yesterday:
            startDate = calendar.date(byAdding: .day, value: -1, to: calendar.startOfDay(for: now))!
            endDate = calendar.startOfDay(for: now)
        case .lastWeek:
            startDate = calendar.date(byAdding: .day, value: -7, to: calendar.startOfDay(for: now))!
            endDate = now
        }
        
        // 获取步数
        getSteps(from: startDate, to: endDate) { steps in
            // 获取睡眠时间
            getSleepHours(from: startDate, to: endDate) { sleepHours in
                // 获取任务完成情况（这里仍使用模拟数据，因为需要单独的任务管理系统）
                let (completed, total) = getTasksCount(for: timeRange)
                let calorieGoal = calculateDailyCalorieGoal()
                
                DispatchQueue.main.async {
                    self.healthData[timeRange] = HealthData(
                        steps: steps,
                        sleepHours: sleepHours,
                        completedTasks: completed,
                        totalTasks: total,
                        dailyCalorieGoal: calorieGoal
                    )
                }
            }
        }
    }
    
    private func getSteps(from startDate: Date, to endDate: Date, completion: @escaping (Int) -> Void) {
        guard let stepType = HKQuantityType.quantityType(forIdentifier: .stepCount) else {
            completion(0)
            return
        }
        
        let predicate = HKQuery.predicateForSamples(withStart: startDate, end: endDate, options: .strictStartDate)
        let query = HKStatisticsQuery(
            quantityType: stepType,
            quantitySamplePredicate: predicate,
            options: .cumulativeSum
        ) { _, result, error in
            guard let result = result,
                  let sum = result.sumQuantity() else {
                completion(0)
                return
            }
            
            let steps = Int(sum.doubleValue(for: HKUnit.count()))
            completion(steps)
        }
        
        healthStore.execute(query)
    }
    
    private func getSleepHours(from startDate: Date, to endDate: Date, completion: @escaping (Double) -> Void) {
        guard let sleepType = HKObjectType.categoryType(forIdentifier: .sleepAnalysis) else {
            completion(0)
            return
        }
        
        let predicate = HKQuery.predicateForSamples(withStart: startDate, end: endDate, options: .strictStartDate)
        let query = HKSampleQuery(
            sampleType: sleepType,
            predicate: predicate,
            limit: HKObjectQueryNoLimit,
            sortDescriptors: nil
        ) { _, samples, error in
            guard let samples = samples as? [HKCategorySample] else {
                completion(0)
                return
            }
            
            let totalSeconds = samples.reduce(0.0) { sum, sample in
                sum + sample.endDate.timeIntervalSince(sample.startDate)
            }
            
            let hours = totalSeconds / 3600.0
            completion(hours)
        }
        
        healthStore.execute(query)
    }
    
    private func getTasksCount(for timeRange: TimeRange) -> (completed: Int, total: Int) {
        // 这里使用模拟数据，实际应用中需要连接到任务管理系统
        switch timeRange {
        case .today:
            return (3, 5)
        case .yesterday:
            return (5, 5)
        case .lastWeek:
            return (28, 35)
        }
    }
    
    private func calculateBMR() -> Double {
        let age = Calendar.current.dateComponents([.year], from: userBirthday, to: Date()).year ?? 25
        
        // 使用 Harris-Benedict 公式计算基础代谢率
        if userGender == "male" {
            return 66.5 + (13.75 * userWeight) + (5.003 * userHeight) - (6.75 * Double(age))
        } else {
            return 655.1 + (9.563 * userWeight) + (1.850 * userHeight) - (4.676 * Double(age))
        }
    }
    
    private func calculateDailyCalorieGoal() -> Int {
        let bmr = calculateBMR()
        
        // 根据活动水平调整卡路里目标
        // 假设用户为轻度活动水平，乘以1.375
        let dailyCalories = bmr * 1.375
        
        return Int(dailyCalories)
    }
    
    private func getHealthSuggestions(for data: HealthData) -> [HealthSuggestion] {
        var suggestions: [HealthSuggestion] = []
        
        // 步数建议
        if data.steps < 8000 {
            suggestions.append(HealthSuggestion(
                title: "增加运动量",
                description: "今天步数偏少，建议再走\(8000 - data.steps)步达到健康标准",
                icon: "figure.walk",
                color: .green
            ))
        }
        
        // 睡眠建议
        if data.sleepHours < 7 {
            suggestions.append(HealthSuggestion(
                title: "改善睡眠",
                description: "睡眠不足会影响身体健康，建议保持7-8小时充足睡眠",
                icon: "bed.double.fill",
                color: .blue
            ))
        }
        
        // 任务完成建议
        if data.completedTasks < data.totalTasks {
            suggestions.append(HealthSuggestion(
                title: "待办事项",
                description: "还有\(data.totalTasks - data.completedTasks)项待办事项未完成，合理安排时间处理",
                icon: "checkmark.circle.fill",
                color: .purple
            ))
        }
        
        // 添加卡路里相关建议
        suggestions.append(HealthSuggestion(
            title: "每日能量目标",
            description: "根据您的身高体重，建议每日摄入\(data.dailyCalorieGoal)千卡来维持健康体重",
            icon: "flame.fill",
            color: .orange
        ))
        
        // 如果都达标了，给出鼓励
        if suggestions.isEmpty {
            suggestions.append(HealthSuggestion(
                title: "状态良好",
                description: "今天的各项指标都达标了，继续保持！",
                icon: "star.fill",
                color: .orange
            ))
        }
        
        return suggestions
    }
}

struct HealthData {
    let steps: Int
    let sleepHours: Double
    let completedTasks: Int
    let totalTasks: Int
    let dailyCalorieGoal: Int
}

struct ActivityRingsView: View {
    let data: HealthData
    
    var body: some View {
        ZStack {
            // 步数环
            ActivityRing(
                progress: min(Double(data.steps) / 8000.0, 1.0),
                color: .green,
                thickness: 20
            )
            .frame(width: 180, height: 180)
            
            // 睡眠环
            ActivityRing(
                progress: min(data.sleepHours / 8.0, 1.0),
                color: .blue,
                thickness: 20
            )
            .frame(width: 140, height: 140)
            
            // 任务环
            ActivityRing(
                progress: Double(data.completedTasks) / Double(data.totalTasks),
                color: .purple,
                thickness: 20
            )
            .frame(width: 100, height: 100)
        }
    }
}

struct ActivityRing: View {
    let progress: Double
    let color: Color
    let thickness: CGFloat
    
    var body: some View {
        ZStack {
            Circle()
                .stroke(color.opacity(0.2), lineWidth: thickness)
            
            Circle()
                .trim(from: 0, to: CGFloat(progress))
                .stroke(color, style: StrokeStyle(
                    lineWidth: thickness,
                    lineCap: .round
                ))
                .rotationEffect(.degrees(-90))
                .animation(.easeInOut, value: progress)
        }
    }
}

struct HealthSuggestion {
    let title: String
    let description: String
    let icon: String
    let color: Color
}

struct SuggestionCard: View {
    let suggestion: HealthSuggestion
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: suggestion.icon)
                    .font(.title2)
                    .foregroundColor(suggestion.color)
                Text(suggestion.title)
                    .font(.headline)
            }
            
            Text(suggestion.description)
                .font(.subheadline)
                .foregroundColor(.gray)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding()
        .frame(width: 280)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Color(UIColor.systemBackground))
                .shadow(color: Color.black.opacity(0.1),
                       radius: 10, x: 0, y: 4)
        )
    }
}

struct DataCard: View {
    let title: String
    let value: String
    let unit: String
    
    var body: some View {
        VStack(spacing: 8) {
            Text(title)
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            Text(value)
                .font(.system(size: 24, weight: .bold))
            
            Text(unit)
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
    }
}


#Preview {
    NavigationView {
        HealthAnalysisView()
    }
}
