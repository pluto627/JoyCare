import SwiftUI

struct AboutView: View {
    // 版本号和构建号
    private let appVersion = "0.8"
    private let buildNumber = "25"
    
    var body: some View {
        VStack(spacing: 0) {
            // 顶部导航栏
            HStack {
                Text("关于")
                    .font(.title2)
                    .padding()
                Spacer()
            }
            .background(Color.white)
            
            ScrollView {
                VStack(spacing: 15) {
                    // App Logo
                    VStack(spacing: 12) {
                        Image(systemName: "cross.case.fill")
                            .resizable()
                            .frame(width: 80, height: 80)
                            .foregroundColor(Color(hex: "9253f3"))
                            .padding(.top, 20)
                        
                        Text("xundoc")
                            .font(.title)
                            .bold()
                        
                        Text("版本 \(appVersion) (\(buildNumber))")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                            .padding(.bottom, 20)
                    }
                    .frame(maxWidth: .infinity)
                    .background(Color.white)
                    .cornerRadius(10)
                    .padding(.horizontal)
                    
                    // 功能介绍
                    VStack(spacing: 0) {
                        AboutItemView(
                            icon: "doc.text.fill",
                            title: "使用条款",
                            showDivider: true
                        )
                        
                        AboutItemView(
                            icon: "hand.raised.fill",
                            title: "隐私政策",
                            showDivider: true
                        )
                        
                        AboutItemView(
                            icon: "envelope.fill",
                            title: "联系我们",
                            showDivider: true
                        )
                        
                        AboutItemView(
                            icon: "star.fill",
                            title: "给我们评分",
                            showDivider: false
                        )
                    }
                    .background(Color.white)
                    .cornerRadius(10)
                    .padding(.horizontal)
                    
                    // 版权信息
                    VStack(spacing: 4) {
                        Text("© 2025 Pluto. All rights reserved.")
                            .font(.caption)
                            .foregroundColor(.gray)
                        
                        Text("Made with ❤️ in Shanghai")
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                    .padding(.vertical, 30)
                }
                .padding(.top, 12)
            }
            .background(Color(.systemGray6))
        }
    }
}

struct AboutItemView: View {
    let icon: String
    let title: String
    let showDivider: Bool
    
    var body: some View {
        VStack(spacing: 0) {
            Button(action: {
                // 处理点击事件
            }) {
                HStack(spacing: 12) {
                    Image(systemName: icon)
                        .frame(width: 24)
                        .foregroundColor(Color(hex: "9253f3"))
                        .font(.system(size: 18))
                    
                    Text(title)
                        .foregroundColor(.primary)
                        .font(.system(size: 17))
                    
                    Spacer()
                    
                    Image(systemName: "chevron.right")
                        .foregroundColor(.gray)
                }
                .padding(.vertical, 16)
                .padding(.horizontal)
            }
            .buttonStyle(PlainButtonStyle())
            
            if showDivider {
                Divider()
                    .padding(.horizontal)
            }
        }
    }
}

#Preview {
    AboutView()
}
