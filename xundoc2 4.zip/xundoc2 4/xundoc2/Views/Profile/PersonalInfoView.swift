import SwiftUI

struct PersonalInfoView: View {
    @Environment(\.presentationMode) var presentationMode
    
    // 示例用户数据
    @State private var userData = UserData(
        name: "陈美玲",
        id: "88888888",
        gender: "女",
        birthDate: Date(),
        phone: "13800138000",
        email: "chen@example.com",
        address: "上海市浦东新区张江高科技园区"
    )
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("基本信息")) {
                    HStack {
                        Text("姓名")
                        Spacer()
                        Text(userData.name)
                            .foregroundColor(.gray)
                    }
                    
                    HStack {
                        Text("ID")
                        Spacer()
                        Text(userData.id)
                            .foregroundColor(.gray)
                    }
                    
                    HStack {
                        Text("性别")
                        Spacer()
                        Text(userData.gender)
                            .foregroundColor(.gray)
                    }
                    
                    HStack {
                        Text("出生日期")
                        Spacer()
                        Text(userData.birthDate.formatted(date: .abbreviated, time: .omitted))
                            .foregroundColor(.gray)
                    }
                }
                
                Section(header: Text("联系方式")) {
                    HStack {
                        Text("手机号码")
                        Spacer()
                        Text(userData.phone)
                            .foregroundColor(.gray)
                    }
                    
                    HStack {
                        Text("电子邮箱")
                        Spacer()
                        Text(userData.email)
                            .foregroundColor(.gray)
                    }
                }
                
                Section(header: Text("地址信息")) {
                    HStack {
                        Text("居住地址")
                        Spacer()
                        Text(userData.address)
                            .foregroundColor(.gray)
                            .multilineTextAlignment(.trailing)
                    }
                }
            }
            .navigationTitle("个人信息")
            .navigationBarTitleDisplayMode(.inline)
            
        }
    }
}

// 用户数据模型
struct UserData {
    var name: String
    var id: String
    var gender: String
    var birthDate: Date
    var phone: String
    var email: String
    var address: String
}

#Preview {
    PersonalInfoView()
}
