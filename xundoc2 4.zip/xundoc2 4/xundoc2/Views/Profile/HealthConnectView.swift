import SwiftUI
import HealthKit

struct HealthConnectView: View {
    @State private var isHealthKitAuthorized = false
    @State private var showingAlert = false
    
    // 需要访问的健康数据类型
    private let healthStore = HKHealthStore()
    private let typesToRead: Set = [
        HKObjectType.quantityType(forIdentifier: .stepCount)!,
        HKObjectType.quantityType(forIdentifier: .heartRate)!,
        HKObjectType.quantityType(forIdentifier: .bodyMass)!,
        HKObjectType.quantityType(forIdentifier: .bloodPressureSystolic)!
    ]
    
    var body: some View {
        VStack(spacing: 0) {
            // 顶部导航栏
            HStack {
                Text("与健康 app 连接")
                    .font(.title2)
                    .padding()
                Spacer()
            }
            .background(Color.white)
            
            ScrollView {
                VStack(spacing: 15) {
                    // 连接状态卡片
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Image(systemName: isHealthKitAuthorized ? "checkmark.circle.fill" : "xmark.circle.fill")
                                .foregroundColor(isHealthKitAuthorized ? .green : .red)
                            Text(isHealthKitAuthorized ? "已连接健康" : "未连接健康")
                                .font(.headline)
                        }
                        .padding(.bottom, 4)
                        
                        Text("连接健康后，可以同步以下数据：")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.white)
                    .cornerRadius(10)
                    .padding(.horizontal)
                    
                    // 可同步数据列表
                    VStack(spacing: 0) {
                        HealthDataItemView(icon: "figure.walk", title: "步数", description: "每日运动步数")
                        
                        Divider()
                            .padding(.horizontal)
                        
                        HealthDataItemView(icon: "heart.fill", title: "心率", description: "实时心率数据")
                        
                        Divider()
                            .padding(.horizontal)
                        
                        HealthDataItemView(icon: "scalemass.fill", title: "体重", description: "体重记录")
                        
                        Divider()
                            .padding(.horizontal)
                        
                        HealthDataItemView(icon: "waveform.path.ecg", title: "血压", description: "血压测量数据")
                    }
                    .background(Color.white)
                    .cornerRadius(10)
                    .padding(.horizontal)
                    
                    // 连接按钮
                    Button(action: {
                        requestHealthKitAuthorization()
                    }) {
                        Text(isHealthKitAuthorized ? "断开连接" : "立即连接")
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color(hex: "9253f3"))
                            .cornerRadius(10)
                    }
                    .padding(.horizontal)
                    .padding(.top, 10)
                }
                .padding(.top, 12)
            }
            .background(Color(.systemGray6))
        }
        .alert(isPresented: $showingAlert) {
            Alert(
                title: Text("授权失败"),
                message: Text("请在系统设置中允许访问健康数据"),
                dismissButton: .default(Text("确定"))
            )
        }
        .onAppear {
            checkHealthKitAuthorization()
        }
    }
    
    private func checkHealthKitAuthorization() {
        guard HKHealthStore.isHealthDataAvailable() else {
            return
        }
        
        for type in typesToRead {
            let status = healthStore.authorizationStatus(for: type)
            if status == .sharingAuthorized {
                isHealthKitAuthorized = true
                return
            }
        }
        isHealthKitAuthorized = false
    }
    
    private func requestHealthKitAuthorization() {
        guard HKHealthStore.isHealthDataAvailable() else {
            showingAlert = true
            return
        }
        
        healthStore.requestAuthorization(toShare: nil, read: typesToRead) { success, error in
            DispatchQueue.main.async {
                if success {
                    isHealthKitAuthorized = true
                } else {
                    showingAlert = true
                }
            }
        }
    }
}

struct HealthDataItemView: View {
    let icon: String
    let title: String
    let description: String
    
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .frame(width: 24)
                .foregroundColor(Color(hex: "9253f3"))
                .font(.system(size: 18))
            
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.system(size: 17))
                Text(description)
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
            
            Spacer()
        }
        .padding(.vertical, 16)
        .padding(.horizontal)
    }
}

#Preview {
    HealthConnectView()
}
