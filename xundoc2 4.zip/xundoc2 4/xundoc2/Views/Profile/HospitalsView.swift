import SwiftUI

struct HospitalsView: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var searchText = ""
    
    // 示例医院数据
    let hospitals = [
        Hospital1(name: "浦东新区人民医院", address: "上海市浦东新区川沙新镇新川路519号", distance: "2.3km", type: "三级甲等"),
        Hospital1(name: "上海市第七人民医院", address: "上海市浦东新区高桥镇大同路358号", distance: "4.1km", type: "三级甲等"),
        Hospital1(name: "上海市浦东医院", address: "上海市浦东新区浦东南路2800号", distance: "5.7km", type: "三级乙等"),
        Hospital1(name: "上海中医药大学附属曙光医院(东院)", address: "上海市浦东新区张衡路528号", distance: "6.2km", type: "三级甲等")
    ]
    
    var filteredHospitals: [Hospital1] {
        if searchText.isEmpty {
            return hospitals
        } else {
            return hospitals.filter { $0.name.contains(searchText) }
        }
    }
    
    var body: some View {
        NavigationView {
            VStack {
                // 搜索栏
                SearchBar(text: $searchText)
                    .padding()
                
                List(filteredHospitals) { hospital in
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text(hospital.name)
                                .font(.headline)
                            Spacer()
                            Text(hospital.distance)
                                .font(.subheadline)
                                .foregroundColor(.gray)
                        }
                        
                        Text(hospital.type)
                            .font(.subheadline)
                            .foregroundColor(Color(hex: "9253f3"))
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(Color(hex: "9253f3").opacity(0.1))
                            .cornerRadius(4)
                        
                        Text(hospital.address)
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }
                    .padding(.vertical, 8)
                }
            }
            .navigationTitle("常用医院")
            .navigationBarTitleDisplayMode(.inline)
            
        }
    }
}

// 医院数据模型
struct Hospital1: Identifiable {
    let id = UUID()
    let name: String
    let address: String
    let distance: String
    let type: String
}

// 自定义搜索栏
struct SearchBar: View {
    @Binding var text: String
    
    var body: some View {
        HStack {
            Image(systemName: "magnifyingglass")
                .foregroundColor(.gray)
            
            TextField("搜索医院", text: $text)
                .textFieldStyle(PlainTextFieldStyle())
            
            if !text.isEmpty {
                Button(action: {
                    text = ""
                }) {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundColor(.gray)
                }
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(Color(.systemGray6))
        .cornerRadius(10)
    }
}

#Preview {
    HospitalsView()
}
