import SwiftUI

struct CommonFunctionsSection: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("常用功能")
                .font(.title3)
                .bold()
            
            VStack(spacing: 15) {
                FunctionCard(icon: "person.2", title: "Agent 挂号", subtitle: "智能预约就医服务", description: "全天候在线预约")
                
                FunctionCard(icon: "chart.bar", title: "日常分析", subtitle: "健康数据追踪", description: "专业数据解读")
            }
        }
    }
}

// 功能卡片
struct FunctionCard: View {
    let icon: String
    let title: String
    let subtitle: String
    let description: String
    
    var body: some View {
        HStack {
            Image(systemName: icon)
                .font(.title2)
                .foregroundColor(.purple)
                .frame(width: 40, height: 40)
                .background(Color.purple.opacity(0.1))
                .cornerRadius(10)
            
            VStack(alignment: .leading) {
                Text(title)
                    .font(.headline)
                Text(subtitle)
                    .font(.subheadline)
                    .foregroundColor(.gray)
                Text(description)
                    .font(.caption)
                    .foregroundColor(.gray)
            }
            Spacer()
        }
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(color: .gray.opacity(0.1), radius: 5)
    }
}

#Preview {
    CommonFunctionsSection()
}
