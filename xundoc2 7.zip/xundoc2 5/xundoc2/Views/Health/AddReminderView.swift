import SwiftUI
import Foundation
import UIKit

struct AddReminderView: View {
    @Environment(\.dismiss) var dismiss
    @ObservedObject var reminderManager: ReminderManager
    @State private var title = ""
    @State private var selectedTime = Date()
    @State private var selectedType: String
    @State private var selectedTimes: [Date] = [Date()]
    @State private var showingTimePickerSheet = false
    @State private var showImagePicker = false
    @State private var selectedImage: UIImage?
    @State private var medicineTimings: [Date] = []
    @State private var medicineDuration: String = ""
    @State private var medicineNotes: String = ""
    @State private var selectedImages: [UIImage] = []
    @State private var hospital: String = ""
    @State private var selectedFrequency = "每天"
    @State private var customDays = 1
    @State private var tempSelectedTime = Date()
    @State private var timePickerMode: TimePickerMode = .none
    
    let reminderTypes = [
        "用药提醒",
        "检测提醒",
        "就医提醒",
        "运动提醒",
        "坐卧提醒",
        "饮食提醒",
        "睡眠提醒"
    ]
    
    init(reminderManager: ReminderManager, initialType: String) {
        self.reminderManager = reminderManager
        _selectedType = State(initialValue: initialType)
    }
    
    private var navigationToolbar: some ToolbarContent {
        Group {
            ToolbarItem(placement: .navigationBarLeading) {
                Button("取消") {
                    dismiss()
                }
            }
            ToolbarItem(placement: .navigationBarTrailing) {
                Button("保存") {
                    saveReminder()
                }
                .disabled(title.isEmpty)
            }
        }
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                mainContent
                timePickerOverlay
            }
            .sheet(isPresented: $showImagePicker) {
                ImagePicker(
                    selectedImages: $selectedImages,
                    sourceType: .camera
                )
            }
            .onChange(of: selectedImages) { newImages in
                if let image = newImages.last {
                    selectedImage = image
                }
            }
        }
    }
    
    private var mainContent: some View {
        Form {
            basicInfoSection
            reminderTypeSection
            frequencySection
            timesSection
            
            if selectedType == "用药提醒" && medicineTimings.count > 1 {
                medicineTimingsSection
            }
            
            if !medicineNotes.isEmpty {
                notesSection
            }
        }
        .navigationTitle("添加提醒")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            navigationToolbar
        }
    }
    
    private var timePickerOverlay: some View {
        Group {
            if case .none = timePickerMode {
                EmptyView()
            } else {
                Color.black.opacity(0.3)
                    .edgesIgnoringSafeArea(.all)
                    .onTapGesture {
                        timePickerMode = .none
                    }
                
                timePickerView
                    .padding()
                    .transition(.move(edge: .bottom))
                    .animation(.easeInOut, value: timePickerMode)
            }
        }
    }
    
    private var basicInfoSection: some View {
        Section(header: Text("基本信息")) {
            HStack {
                TextField("提醒内容", text: $title)
                Button(action: {
                    showImagePicker = true
                }) {
                    Image(systemName: "camera")
                        .foregroundColor(.blue)
                }
            }
            
            if let image = selectedImage {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 200)
                    .clipped()
            }
            
            DatePicker("提醒时间", selection: $selectedTime, displayedComponents: .hourAndMinute)
        }
    }
    
    private var reminderTypeSection: some View {
        Section(header: Text("提醒类型")) {
            Picker("类型", selection: $selectedType) {
                ForEach(reminderTypes, id: \.self) { type in
                    Text(type).tag(type)
                }
            }
        }
    }
    
    private var frequencySection: some View {
        Section(header: Text("提醒周期")) {
            Picker("重复", selection: $selectedFrequency) {
                Text("不重复").tag("不重复")
                Text("每天").tag("每天")
                Text("隔天").tag("隔天")
                Text("自定义").tag("自定义")
            }
            
            if selectedFrequency == "自定义" {
                Stepper("每隔 \(customDays) 天", value: $customDays, in: 1...30)
            }
        }
    }
    
    private var timesSection: some View {
        Section(header: Text("提醒时间")) {
            ForEach(selectedTimes, id: \.self) { time in
                HStack {
                    Text(timeFormatter.string(from: time))
                    Spacer()
                    Button(action: {
                        withAnimation {
                            if let index = selectedTimes.firstIndex(of: time) {
                                selectedTimes.remove(at: index)
                            }
                        }
                    }) {
                        Image(systemName: "minus.circle.fill")
                            .foregroundColor(.red)
                    }
                }
            }
            
            Button(action: {
                tempSelectedTime = Date()
                timePickerMode = .adding
            }) {
                HStack {
                    Image(systemName: "plus.circle.fill")
                    Text("添加时间")
                }
            }
        }
    }
    
    private var medicineTimingsSection: some View {
        Section(header: Text("服用时间")) {
            ForEach(medicineTimings, id: \.self) { time in
                Text(timeFormatter.string(from: time))
            }
        }
    }
    
    private var notesSection: some View {
        Section(header: Text("备注信息")) {
            Text(medicineNotes)
                .font(.body)
        }
    }
    
    private var timePickerView: some View {
        VStack {
            DatePicker("选择时间",
                      selection: $tempSelectedTime,
                      in: Date()...,
                      displayedComponents: [.hourAndMinute, .date])
                .datePickerStyle(.wheel)
                .labelsHidden()
            
            HStack {
                Button("取消") {
                    timePickerMode = .none
                }
                .padding()
                
                Spacer()
                
                Button("确定") {
                    addNewTime(tempSelectedTime)
                    timePickerMode = .none
                }
                .padding()
            }
        }
        .padding()
        .background(Color(UIColor.systemBackground))
        .cornerRadius(10)
        .shadow(radius: 5)
    }
    
    private func saveReminder() {
        var description = medicineNotes
        if description.isEmpty {
            description = getDefaultDescription(for: selectedType)
        }
        
        // 计算重复周期
        let repeatPattern: String? = {
            switch selectedFrequency {
            case "每天": return "daily"
            case "隔天": return "alternate"
            case "自定义": return "custom_\(customDays)"
            case "不重复": return nil
            default: return nil
            }
        }()
        
        // 为每个选择的时间创建一个提醒
        for baseTime in selectedTimes {
            let reminder = Reminder(
                title: title,
                date: baseTime,
                isCompleted: false,
                description: description.isEmpty ? nil : description,
                type: selectedType,
                repeatPattern: repeatPattern  // 添加重复模式
            )
            reminderManager.addReminder(reminder)
        }
        
        HapticManager.shared.notification(type: .success)
        dismiss()
    }
    
    private var timeFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateFormat = "MM-dd HH:mm"
        return formatter
    }
    
    private func handleScanResult(_ image: UIImage) {
        selectedImage = image
    }
    
    private func getDefaultDescription(for type: String) -> String {
        switch type {
        case "运动提醒":
            return "建议运动时间：30-60分钟\n运动强度：中等\n注意事项：请适量饮水，注意身体状况"
        case "坐卧提醒":
            return """
            久坐提醒：
            1. 每60分钟需要：
               - 起身走动3-5分钟
               - 活动颈部和手腕
               - 远眺放松眼睛
            
            2. 坐姿建议：
               - 保持腰背挺直
               - 双脚平放地面
               - 电脑屏幕与眼睛齐平
            
            3. 简单运动建议：
               - 原地踏步
               - 伸展手臂
               - 颈部转动
               - 深呼吸放松
            
            4. 警示：长期久坐可能导致：
               - 颈椎疾病
               - 腰椎问题
               - 静脉血栓
            """
            
        case "饮食提醒":
            return "注意事项：\n1. 规律进餐\n2. 细嚼慢咽\n3. 注意营养均衡"
        case "睡眠提醒":
            return "建议：\n1. 保持规律作息\n2. 睡前避免使用电子设备\n3. 保证7-8小时睡眠"
        case "就医提醒":
            return """
            就医前准备事项：
            1. 提前准备（建议提前1天）：
               - 整理近期症状记录
               - 准备既往病历和检查报告
               - 准备身份证、医保卡等证件
               
            2. 就医当天：
               - 建议提前30分钟到达医院
               - 如需空腹检查请注意遵医嘱
               - 携带当前服用的药物清单
               
            3. 就医记录要点：
               - 准备要咨询的问题清单
               - 记录医生建议和用药方案
               - 预约下次复诊时间
            """
        default:
            return ""
        }
    }
    
    private func addNewTime(_ time: Date) {
        let calendar = Calendar.current
        
        // 获取选择的时间的小时和分钟
        let hour = calendar.component(.hour, from: time)
        let minute = calendar.component(.minute, from: time)
        
        // 使用今天的日期创建新的时间
        var components = calendar.dateComponents([.year, .month, .day], from: Date())
        components.hour = hour
        components.minute = minute
        
        if let newTime = calendar.date(from: components) {
            // 如果选择的时间早于当前时间，添加一天
            if newTime < Date() {
                if let adjustedTime = calendar.date(byAdding: .day, value: 1, to: newTime) {
                    if !selectedTimes.contains(where: { calendar.isDate($0, equalTo: adjustedTime, toGranularity: .minute) }) {
                        selectedTimes.append(adjustedTime)
                        selectedTimes.sort()
                    }
                }
            } else {
                if !selectedTimes.contains(where: { calendar.isDate($0, equalTo: newTime, toGranularity: .minute) }) {
                    selectedTimes.append(newTime)
                    selectedTimes.sort()
                }
            }
        }
    }
}

private enum TimePickerMode: Equatable {
    case none
    case adding
    case editing(Date)
    
    static func == (lhs: TimePickerMode, rhs: TimePickerMode) -> Bool {
        switch (lhs, rhs) {
        case (.none, .none):
            return true
        case (.adding, .adding):
            return true
        case let (.editing(date1), .editing(date2)):
            return date1 == date2
        default:
            return false
        }
    }
}




class HapticManager {
    static let shared = HapticManager()
    
    private init() {}
    
    func impact(style: UIImpactFeedbackGenerator.FeedbackStyle) {
        let generator = UIImpactFeedbackGenerator(style: style)
        generator.prepare()
        generator.impactOccurred()
    }
    
    func notification(type: UINotificationFeedbackGenerator.FeedbackType) {
        let generator = UINotificationFeedbackGenerator()
        generator.prepare()
        generator.notificationOccurred(type)
    }
}




