import SwiftUI
import HealthKit

struct HealthDataView: View {
    @StateObject private var healthManager = HealthKitManager.shared
    @State private var isAuthorized = false
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                if isAuthorized {
                    HealthDataCard()
                } else {
                    requestAccessButton
                }
            }
            .padding()
        }
        .onAppear {
            checkAuthorization()
        }
    }
    
    
    
    private var requestAccessButton: some View {
        Button {
            requestHealthKitAccess()
        } label: {
            Text("授权访问健康数据")
                .font(.headline)
                .foregroundColor(.white)
                .padding()
                .background(Color.blue)
                .cornerRadius(10)
        }
    }
    
    private func checkAuthorization() {
        HealthKitManager.shared.requestAuthorization { success, error in
            DispatchQueue.main.async {
                isAuthorized = success
                if success {
                    healthManager.updateData()
                }
            }
        }
    }
    
    private func requestHealthKitAccess() {
        HealthKitManager.shared.requestAuthorization { success, error in
            DispatchQueue.main.async {
                isAuthorized = success
                if success {
                    healthManager.updateData()
                }
            }
        }
    }
} 

#Preview {
    HealthDataView()
}
