import SwiftUI
import HealthKit

struct HealthAnalysisView: View {
    @Environment(\.colorScheme) private var colorScheme
    @State private var selectedTimeRange: TimeRange = .today
    @State private var healthData: [TimeRange: HealthData] = [:]
    private let healthStore = HKHealthStore()
    
    // 添加用户基本信息
    @AppStorage("userHeight") private var userHeight: Double = 170.0
    @AppStorage("userWeight") private var userWeight: Double = 65.0
    @AppStorage("userBirthday") private var userBirthday = Date()
    @AppStorage("userGender") private var userGender: String = "male"
    
    enum TimeRange: String, CaseIterable {
        case today = "今天"
        case yesterday = "昨天"
        case lastWeek = "过去7天"
    }
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                // 时间范围选择器
                Picker("时间范围", selection: $selectedTimeRange) {
                    ForEach(TimeRange.allCases, id: \.self) { range in
                        Text(range.rawValue).tag(range)
                    }
                }
                .pickerStyle(.segmented)
                .padding(.horizontal)
                .padding(.top)
                
                if let data = healthData[selectedTimeRange] {
                    if selectedTimeRange == .lastWeek {
                        WeeklyStatsView(data: data)
                    } else {
                        // 活动环
                        ActivityRingsView(data: data)
                            .frame(height: 200)
                            .padding(.vertical)
                        
                        // 详细数据卡片
                        LazyVGrid(columns: [
                            GridItem(.flexible()),
                            GridItem(.flexible())
                        ], spacing: 16) {
                            DataCard(
                                title: "步数",
                                value: "\(data.steps)",
                                unit: "步"
                            )
                            
                            DataCard(
                                title: "睡眠",
                                value: String(format: "%.1f", data.sleepHours),
                                unit: "小时"
                            )
                            
                            DataCard(
                                title: "任务完成",
                                value: "\(data.completedTasks)",
                                unit: "/ \(data.totalTasks)项"
                            )
                            
                            // 添加卡路里目标卡片
                            DataCard(
                                title: "每日卡路里目标",
                                value: "\(data.dailyCalorieGoal)",
                                unit: "千卡"
                            )
                        }
                        .padding(.horizontal)
                        
                        // 添加健康建议部分
                        VStack(alignment: .leading, spacing: 16) {
                            Text("今日建议")
                                .font(.headline)
                                .padding(.horizontal)
                            
                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack(spacing: 16) {
                                    ForEach(getHealthSuggestions(for: data), id: \.title) { suggestion in
                                        SuggestionCard(suggestion: suggestion)
                                    }
                                }
                                .padding(.horizontal)
                            }
                        }
                    }
                }
            }
        }
        .navigationTitle("健康分析")
        .onAppear {
            requestHealthKitAuthorization()
        }
    }
    
    private func requestHealthKitAuthorization() {
        // 定义需要读取的数据类型
        let typesToRead: Set<HKSampleType> = [
            HKObjectType.quantityType(forIdentifier: .stepCount)!,
            HKObjectType.categoryType(forIdentifier: .sleepAnalysis)!
        ]
        
        // 请求授权
        healthStore.requestAuthorization(toShare: nil, read: typesToRead) { success, error in
            if success {
                print("HealthKit authorization granted")
                self.loadHealthData()
            } else if let error = error {
                print("HealthKit authorization failed: \(error.localizedDescription)")
            }
        }
    }
    
    private func loadHealthData() {
        // 加载今天的数据
        loadDataForTimeRange(.today)
        // 加载昨天的数据
        loadDataForTimeRange(.yesterday)
        // 加载过去7天的数据
        loadDataForTimeRange(.lastWeek)
    }
    
    private func loadDataForTimeRange(_ timeRange: TimeRange) {
        let calendar = Calendar.current
        let now = Date()
        let startDate: Date
        let endDate: Date
        
        switch timeRange {
        case .today:
            startDate = calendar.startOfDay(for: now)
            endDate = now
        case .yesterday:
            startDate = calendar.date(byAdding: .day, value: -1, to: calendar.startOfDay(for: now))!
            endDate = calendar.startOfDay(for: now)
        case .lastWeek:
            startDate = calendar.date(byAdding: .day, value: -7, to: calendar.startOfDay(for: now))!
            endDate = now
        }
        
        // 获取步数
        getSteps(from: startDate, to: endDate) { steps in
            // 获取睡眠时间
            getSleepHours(from: startDate, to: endDate) { sleepHours in
                // 获取任务完成情况（这里仍使用模拟数据，因为需要单独的任务管理系统）
                let (completed, total) = getTasksCount(for: timeRange)
                let calorieGoal = calculateDailyCalorieGoal()
                
                DispatchQueue.main.async {
                    self.healthData[timeRange] = HealthData(
                        steps: steps,
                        sleepHours: sleepHours,
                        completedTasks: completed,
                        totalTasks: total,
                        dailyCalorieGoal: calorieGoal
                    )
                }
            }
        }
    }
    
    private func getSteps(from startDate: Date, to endDate: Date, completion: @escaping (Int) -> Void) {
        guard let stepType = HKQuantityType.quantityType(forIdentifier: .stepCount) else {
            completion(0)
            return
        }
        
        let predicate = HKQuery.predicateForSamples(withStart: startDate, end: endDate, options: .strictStartDate)
        let query = HKStatisticsQuery(
            quantityType: stepType,
            quantitySamplePredicate: predicate,
            options: .cumulativeSum
        ) { _, result, error in
            guard let result = result,
                  let sum = result.sumQuantity() else {
                completion(0)
                return
            }
            
            let steps = Int(sum.doubleValue(for: HKUnit.count()))
            completion(steps)
        }
        
        healthStore.execute(query)
    }
    
    private func getSleepHours(from startDate: Date, to endDate: Date, completion: @escaping (Double) -> Void) {
        guard let sleepType = HKObjectType.categoryType(forIdentifier: .sleepAnalysis) else {
            completion(0)
            return
        }
        
        let predicate = HKQuery.predicateForSamples(withStart: startDate, end: endDate, options: .strictStartDate)
        let sortDescriptor = NSSortDescriptor(key: HKSampleSortIdentifierStartDate, ascending: true)
        
        let query = HKSampleQuery(
            sampleType: sleepType,
            predicate: predicate,
            limit: HKObjectQueryNoLimit,
            sortDescriptors: [sortDescriptor]
        ) { _, samples, error in
            guard let samples = samples as? [HKCategorySample],
                  error == nil else {
                print("Error fetching sleep data: \(String(describing: error))")
                completion(0)
                return
            }
            
            var totalSleepTime = 0.0
            
            for sample in samples {
                // 只计算在床睡眠时间（asleep）的数据
                if sample.value == HKCategoryValueSleepAnalysis.asleep.rawValue {
                    let sleepTime = sample.endDate.timeIntervalSince(sample.startDate)
                    totalSleepTime += sleepTime
                }
            }
            
            // 转换为小时
            let sleepHours = totalSleepTime / 3600.0
            completion(sleepHours)
        }
        
        healthStore.execute(query)
    }
    
    private func getTasksCount(for timeRange: TimeRange) -> (completed: Int, total: Int) {
        // 这里使用模拟数据，实际应用中需要连接到任务管理系统
        switch timeRange {
        case .today:
            return (3, 5)
        case .yesterday:
            return (5, 5)
        case .lastWeek:
            return (28, 35)
        }
    }
    
    private func calculateBMR() -> Double {
        let age = Calendar.current.dateComponents([.year], from: userBirthday, to: Date()).year ?? 25
        
        // 使用 Harris-Benedict 公式计算基础代谢率
        if userGender == "male" {
            return 66.5 + (13.75 * userWeight) + (5.003 * userHeight) - (6.75 * Double(age))
        } else {
            return 655.1 + (9.563 * userWeight) + (1.850 * userHeight) - (4.676 * Double(age))
        }
    }
    
    private func calculateDailyCalorieGoal() -> Int {
        let bmr = calculateBMR()
        
        // 根据活动水平调整卡路里目标
        // 假设用户为轻度活动水平，乘以1.375
        let dailyCalories = bmr * 1.375
        
        return Int(dailyCalories)
    }
    
    private func getHealthSuggestions(for data: HealthData) -> [HealthSuggestion] {
        var suggestions: [HealthSuggestion] = []
        
        // 步数建议
        if data.steps < 8000 {
            suggestions.append(HealthSuggestion(
                title: "增加运动量",
                description: "今天步数偏少，建议再走\(8000 - data.steps)步达到健康标准",
                icon: "figure.walk",
                color: .green
            ))
        }
        
        // 睡眠建议
        if data.sleepHours < 7 {
            suggestions.append(HealthSuggestion(
                title: "改善睡眠",
                description: "睡眠不足会影响身体健康，建议保持7-8小时充足睡眠",
                icon: "bed.double.fill",
                color: .blue
            ))
        }
        
        // 任务完成建议
        if data.completedTasks < data.totalTasks {
            suggestions.append(HealthSuggestion(
                title: "待办事项",
                description: "还有\(data.totalTasks - data.completedTasks)项待办事项未完成，合理安排时间处理",
                icon: "checkmark.circle.fill",
                color: .purple
            ))
        }
        
        // 添加卡路里相关建议
        suggestions.append(HealthSuggestion(
            title: "每日能量目标",
            description: "根据您的身高体重，建议每日摄入\(data.dailyCalorieGoal)千卡来维持健康体重",
            icon: "flame.fill",
            color: .orange
        ))
        
        // 如果都达标了，给出鼓励
        if suggestions.isEmpty {
            suggestions.append(HealthSuggestion(
                title: "状态良好",
                description: "今天的各项指标都达标了，继续保持！",
                icon: "star.fill",
                color: .orange
            ))
        }
        
        return suggestions
    }
}

struct HealthData {
    let steps: Int
    let sleepHours: Double
    let completedTasks: Int
    let totalTasks: Int
    let dailyCalorieGoal: Int
}

struct ActivityRingsView: View {
    let data: HealthData
    
    var body: some View {
        VStack {
            ZStack {
                // 步数环
                ActivityRing(
                    progress: min(Double(data.steps) / 8000.0, 1.0),
                    color: .green,
                    thickness: 20
                )
                .frame(width: 180, height: 180)
                
                // 睡眠环
                ActivityRing(
                    progress: min(data.sleepHours / 8.0, 1.0),
                    color: .blue,
                    thickness: 20
                )
                .frame(width: 140, height: 140)
                
                // 任务环
                ActivityRing(
                    progress: Double(data.completedTasks) / Double(data.totalTasks),
                    color: .purple,
                    thickness: 20
                )
                .frame(width: 100, height: 100)
            }
            
            // 添加图例
            HStack(spacing: 16) {
                LegendItem(color: .green, text: "步数: \(data.steps)/8000")
                LegendItem(color: .blue, text: "睡眠: \(String(format: "%.1f", data.sleepHours))/8小时")
                LegendItem(color: .purple, text: "任务: \(data.completedTasks)/\(data.totalTasks)")
            }
            .padding(.top, 8)
        }
    }
}

struct ActivityRing: View {
    let progress: Double
    let color: Color
    let thickness: CGFloat
    
    var body: some View {
        ZStack {
            Circle()
                .stroke(color.opacity(0.2), lineWidth: thickness)
            
            Circle()
                .trim(from: 0, to: CGFloat(progress))
                .stroke(color, style: StrokeStyle(
                    lineWidth: thickness,
                    lineCap: .round
                ))
                .rotationEffect(.degrees(-90))
                .animation(.easeInOut, value: progress)
        }
    }
}

struct HealthSuggestion {
    let title: String
    let description: String
    let icon: String
    let color: Color
}

struct SuggestionCard: View {
    let suggestion: HealthSuggestion
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: suggestion.icon)
                    .font(.title2)
                    .foregroundColor(suggestion.color)
                Text(suggestion.title)
                    .font(.headline)
            }
            
            Text(suggestion.description)
                .font(.subheadline)
                .foregroundColor(.gray)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding()
        .frame(width: 280)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Color(UIColor.systemBackground))
                .shadow(color: Color.black.opacity(0.1),
                       radius: 10, x: 0, y: 4)
        )
    }
}

struct DataCard: View {
    let title: String
    let value: String
    let unit: String
    
    var body: some View {
        VStack(spacing: 8) {
            Text(title)
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            Text(value)
                .font(.system(size: 24, weight: .bold))
            
            Text(unit)
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
    }
}

// 添加图例项组件
struct LegendItem: View {
    let color: Color
    let text: String
    
    var body: some View {
        HStack(spacing: 4) {
            Circle()
                .fill(color)
                .frame(width: 8, height: 8)
            Text(text)
                .font(.caption)
                .foregroundColor(.secondary)
        }
    }
}

struct WeeklyStatsView: View {
    let data: HealthData
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("过去7天趋势")
                .font(.headline)
                .padding(.horizontal)
            
            VStack(spacing: 24) {
                // 步数趋势
                ChartSection(
                    title: "步数",
                    color: .green,
                    data: mockWeeklySteps(),
                    unit: "步"
                )
                
                // 睡眠趋势
                ChartSection(
                    title: "睡眠时长",
                    color: .blue,
                    data: mockWeeklySleep(),
                    unit: "小时"
                )
                
                // 任务完成率趋势
                ChartSection(
                    title: "任务完成率",
                    color: .purple,
                    data: mockWeeklyTasks(),
                    unit: "%"
                )
            }
            .padding()
            .background(Color(UIColor.secondarySystemBackground))
            .cornerRadius(12)
            .padding(.horizontal)
        }
    }
    
    private func mockWeeklySteps() -> [(String, Double)] {
        [
            ("周一", 6500),
            ("周二", 7200),
            ("周三", 8100),
            ("周四", 7800),
            ("周五", 6900),
            ("周六", 9200),
            ("周日", 7500)
        ]
    }
    
    private func mockWeeklySleep() -> [(String, Double)] {
        [
            ("周一", 7.5),
            ("周二", 6.8),
            ("周三", 7.2),
            ("周四", 8.0),
            ("周五", 6.5),
            ("周六", 8.5),
            ("周日", 7.8)
        ]
    }
    
    private func mockWeeklyTasks() -> [(String, Double)] {
        [
            ("周一", 80),
            ("周二", 90),
            ("周三", 85),
            ("周四", 95),
            ("周五", 75),
            ("周六", 70),
            ("周日", 85)
        ]
    }
}

struct ChartSection: View {
    let title: String
    let color: Color
    let data: [(String, Double)]
    let unit: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            GeometryReader { geometry in
                Path { path in
                    let width = geometry.size.width
                    let height = geometry.size.height
                    let stepWidth = width / CGFloat(data.count - 1)
                    let maxValue = data.map { $0.1 }.max() ?? 1
                    
                    for (index, point) in data.enumerated() {
                        let x = CGFloat(index) * stepWidth
                        let y = height - (CGFloat(point.1) / CGFloat(maxValue) * height)
                        
                        if index == 0 {
                            path.move(to: CGPoint(x: x, y: y))
                        } else {
                            path.addLine(to: CGPoint(x: x, y: y))
                        }
                    }
                }
                .stroke(color, lineWidth: 2)
                
                // 添加数据点
                ForEach(0..<data.count, id: \.self) { index in
                    let point = data[index]
                    let x = CGFloat(index) * (geometry.size.width / CGFloat(data.count - 1))
                    let y = geometry.size.height - (CGFloat(point.1) / CGFloat(data.map { $0.1 }.max() ?? 1) * geometry.size.height)
                    
                    Circle()
                        .fill(color)
                        .frame(width: 6, height: 6)
                        .position(x: x, y: y)
                }
            }
            .frame(height: 100)
            
            // X轴标签
            HStack(spacing: 0) {
                ForEach(data, id: \.0) { point in
                    Text(point.0)
                        .font(.caption2)
                        .frame(maxWidth: .infinity)
                }
            }
        }
    }
}

#Preview {
    NavigationView {
        HealthAnalysisView()
    }
}
