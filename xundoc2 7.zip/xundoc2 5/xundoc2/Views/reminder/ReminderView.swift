import SwiftUI

struct ReminderView: View {
    @StateObject var reminderManager: ReminderManager
    @State private var showingAddView = false
    @Environment(\.colorScheme) private var colorScheme
    
    var body: some View {
        NavigationView {
            ZStack(alignment: .top) {
                Color(UIColor.systemGray6)
                    .ignoresSafeArea()
                
                VStack(spacing: -60) {
                    // 标题栏背景延伸到顶部
                    Color(red: 0.4, green: 0.3, blue: 0.9)
                        .frame(height: 135)
                        .ignoresSafeArea(edges: .top)
                    
                    ScrollView {
                        VStack(spacing: 20) {
                            // 如果没有提醒，显示添加提醒的引导
                            if reminderManager.reminders.isEmpty {
                                VStack(spacing: 20) {
                                    VStack(spacing: 10) {
                                        Text("")
                                            .foregroundColor(.gray)
                                        Text("")
                                            .foregroundColor(.gray)
                                        Text("")
                                            .foregroundColor(.gray)
                                        Text("")
                                            .foregroundColor(.gray)
                                        Text("")
                                            .foregroundColor(.gray)
                                        Text("")
                                            .foregroundColor(.gray)
                                        Text("")
                                            .foregroundColor(.gray)
                                        Text("")
                                            .foregroundColor(.gray)
                                        Text("")
                                            .foregroundColor(.gray)
                                        Text("添加一个事件")
                                            .foregroundColor(.gray)
                                        Text("再制定一个时间表")
                                            .foregroundColor(.gray)
                                    }
                                    
                                    Button(action: {
                                        showingAddView = true
                                    }) {
                                        HStack {
                                            Image(systemName: "plus")
                                            Text("增加事件")
                                        }
                                        .font(.system(size: 17))
                                        .foregroundColor(.white)
                                        .frame(maxWidth: .infinity)
                                        .frame(height: 56)
                                        .background(Color(white: 0.2))
                                        .cornerRadius(16)
                                        .padding(.horizontal, 20)
                                    }
                                }
                                .padding(.top, 30)
                            } else {
                                // 显示提醒列表
                                VStack(spacing: 16) {
                                    ForEach(reminderManager.getReminders(for: Date())) { reminder in
                                        ReminderItemView(reminder: reminder, reminderManager: reminderManager)
                                            .background(
                                                RoundedRectangle(cornerRadius: 12)
                                                    .fill(colorScheme == .dark ? Color(.systemGray6) : .white)
                                                    .shadow(
                                                        color: Color.black.opacity(0.05),
                                                        radius: 8,
                                                        x: 0,
                                                        y: 2
                                                    )
                                            )
                                            .transition(.opacity)
                                    }
                                }
                                .padding(.horizontal, 16)
                                .padding(.top, 20)
                                .animation(.default, value: reminderManager.reminders)
                            }
                        }
                    }
                }
                
                // 顶部导航栏 - 使用VStack分离加号按钮和健康提醒文本
                VStack(alignment: .leading, spacing: 0) {
                    // 加号按钮，放在顶部
                    HStack {
                        Spacer()
                        Button(action: {
                            showingAddView = true
                        }) {
                            Image(systemName: "plus")
                                .font(.system(size: 25))
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                        }
                    }
                    .padding(.top, 12)
                    .padding(.trailing)
                    
                    // 健康提醒文本，放在加号下方，靠左对齐
                    Text("健康提醒")
                        .font(.title)
                        .bold()
                        .foregroundColor(.white)
                        .padding(.leading)
                        .padding(.top, -1)
                }
            }
            .navigationBarHidden(true)
            .sheet(isPresented: $showingAddView) {
                SelectReminderTypeView(reminderManager: reminderManager)
                    .presentationDetents([.medium])
                    .presentationDragIndicator(.visible)
            }
        }
    }
}

#Preview {
    ReminderView(reminderManager: ReminderManager())
}
