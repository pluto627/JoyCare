import SwiftUI

import SwiftUI

struct ProfileView: View {
    @StateObject private var userDataManager = UserDataManager()
    @Environment(\.colorScheme) private var colorScheme
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // Profile Card
                VStack(spacing: 8) {
                    // Avatar and Name
                    HStack {
                        if let avatarData = userDataManager.userData.avatarData,
                           let uiImage = UIImage(data: avatarData) {
                            Image(uiImage: uiImage)
                                .resizable()
                                .scaledToFill()
                                .frame(width: 60, height: 60)
                                .clipShape(Circle())
                        } else {
                            Image(systemName: "person.circle.fill")
                                .resizable()
                                .frame(width: 60, height: 60)
                                .foregroundColor(.gray)
                        }
                        
                        VStack(alignment: .leading, spacing: 6) {
                            Text(userDataManager.userData.name)
                                .font(.title2)
                           
                        }
                        
                        Spacer()
                    }
                    .padding(.vertical, 20)
                    .padding(.horizontal)
                }
                .background(Color(uiColor: .systemBackground))
                
                // Menu Items
                VStack(spacing: 15) {
                    // 个人信息按钮
                    NavigationLink(destination: PersonalInfoView().environmentObject(userDataManager)) {
                        MenuItemView(icon: "person", title: NSLocalizedString("personal_info", comment: ""))
                    }
                    .background(Color(uiColor: .systemBackground))
                    .cornerRadius(10)
                    .padding(.horizontal)
                    
                    // 医疗相关区域
                    VStack(spacing: 0) {
                        NavigationLink(destination: HospitalsView()) {
                            MenuItemView(icon: "building.2", title: NSLocalizedString("common_hospitals", comment: ""))
                        }
                        .background(Color(uiColor: .systemBackground))
                        
                        Divider()
                            .background(Color(uiColor: .separator))
                            .padding(.horizontal)
                        
                        NavigationLink(destination: DepartmentsView()) {
                            MenuItemView(icon: "stethoscope", title: NSLocalizedString("departments", comment: ""))
                        }
                        .background(Color(uiColor: .systemBackground))
                    }
                    .cornerRadius(10)
                    .padding(.horizontal)
                    
                    // 健康连接按钮
                    NavigationLink(destination: HealthConnectView()) {
                        MenuItemView(icon: "heart", title: NSLocalizedString("health_connect", comment: ""))
                    }
                    .background(Color(uiColor: .systemBackground))
                    .cornerRadius(10)
                    .padding(.horizontal)
                    
                    // 关于按钮
                    NavigationLink(destination: AboutView()) {
                        MenuItemView(icon: "info.circle", title: NSLocalizedString("about", comment: ""))
                    }
                    .background(Color(uiColor: .systemBackground))
                    .cornerRadius(10)
                    .padding(.horizontal)
                }
                .padding(.top, 12)
                
                Spacer()
                
                // Footer
                VStack(spacing: 4) {
                    Text("JoyCare v1.0")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    Text("by Pluto 2025")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                .padding(.bottom, 20)
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationBarHidden(true)
        }
    }
}

struct MenuItemView: View {
    let icon: String
    let title: String
    
    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: icon)
                .frame(width: 24)
                .foregroundColor(Color(hex: "9253f3"))
                .font(.system(size: 18))
            
            Text(title)
                .foregroundColor(.primary)
                .font(.system(size: 17))
            
            Spacer()
            
            Image(systemName: "chevron.right")
                .foregroundColor(.secondary)
        }
        .padding(.vertical, 20)
        .padding(.horizontal)
    }
}

extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3: // RGB (12-bit)
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6: // RGB (24-bit)
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8: // ARGB (32-bit)
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (1, 1, 1, 0)
        }

        self.init(
            .sRGB,
            red: Double(r) / 255,
            green: Double(g) / 255,
            blue:  Double(b) / 255,
            opacity: Double(a) / 255
        )
    }
}

#Preview {
    ProfileView()
}

