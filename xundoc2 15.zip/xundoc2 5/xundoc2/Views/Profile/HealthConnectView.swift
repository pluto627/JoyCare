import SwiftUI
import HealthKit

struct HealthConnectView: View {
    @State private var isHealthKitAuthorized = false
    @State private var showingAlert = false
    @State private var showingDisconnectAlert = false // 添加断开连接确认弹窗状态
    
    // 需要访问的健康数据类型
    private let healthStore = HKHealthStore()
    private let typesToRead: Set = [
        HKObjectType.quantityType(forIdentifier: .stepCount)!,
        HKObjectType.quantityType(forIdentifier: .heartRate)!,
        HKObjectType.quantityType(forIdentifier: .bodyMass)!,
        HKObjectType.quantityType(forIdentifier: .bloodPressureSystolic)!
    ]
    
    var body: some View {
        VStack(spacing: 0) {
            // 顶部导航栏
            HStack {
                Text(NSLocalizedString("health_connect", comment: ""))
                    .font(.title2)
                    .padding()
                Spacer()
            }
            .background(Color(uiColor: .systemBackground))
            
            ScrollView {
                VStack(spacing: 15) {
                    // 连接状态卡片
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Image(systemName: isHealthKitAuthorized ? "checkmark.circle.fill" : "xmark.circle.fill")
                                .foregroundColor(isHealthKitAuthorized ? .green : .red)
                            Text(isHealthKitAuthorized ? 
                                NSLocalizedString("health_connected", comment: "") : 
                                NSLocalizedString("health_not_connected", comment: ""))
                                .font(.headline)
                        }
                        .padding(.bottom, 4)
                        
                        Text(NSLocalizedString("health_sync_description", comment: ""))
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color(uiColor: .systemBackground))
                    .cornerRadius(10)
                    .padding(.horizontal)
                    
                    // 可同步数据列表
                    VStack(spacing: 0) {
                        HealthDataItemView(
                            icon: "figure.walk",
                            title: NSLocalizedString("steps", comment: ""),
                            description: NSLocalizedString("steps_description", comment: "")
                        )
                        
                        Divider()
                            .padding(.horizontal)
                        
                        HealthDataItemView(
                            icon: "heart.fill",
                            title: NSLocalizedString("heart_rate", comment: ""),
                            description: NSLocalizedString("heart_rate_description", comment: "")
                        )
                        
                        Divider()
                            .padding(.horizontal)
                        
                        HealthDataItemView(
                            icon: "scalemass.fill",
                            title: NSLocalizedString("weight", comment: ""),
                            description: NSLocalizedString("weight_description", comment: "")
                        )
                        
                        Divider()
                            .padding(.horizontal)
                        
                        HealthDataItemView(
                            icon: "waveform.path.ecg",
                            title: NSLocalizedString("blood_pressure", comment: ""),
                            description: NSLocalizedString("blood_pressure_description", comment: "")
                        )
                    }
                    .background(Color(uiColor: .systemBackground))
                    .cornerRadius(10)
                    .padding(.horizontal)
                    
                    // 连接按钮
                    Button(action: {
                        if isHealthKitAuthorized {
                            showingDisconnectAlert = true
                        } else {
                            requestHealthKitAuthorization()
                        }
                    }) {
                        Text(isHealthKitAuthorized ? 
                            NSLocalizedString("disconnect", comment: "") : 
                            NSLocalizedString("connect_now", comment: ""))
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color(hex: "9253f3"))
                            .cornerRadius(10)
                    }
                    .padding(.horizontal)
                    .padding(.top, 10)
                }
                .padding(.top, 12)
            }
            .background(Color(.systemGray6))
        }
        .alert(isPresented: $showingAlert) {
            Alert(
                title: Text(NSLocalizedString("authorization_failed", comment: "")),
                message: Text(NSLocalizedString("health_permission_message", comment: "")),
                dismissButton: .default(Text(NSLocalizedString("ok", comment: "")))
            )
        }
        .alert(NSLocalizedString("confirm_disconnect", comment: ""), isPresented: $showingDisconnectAlert) {
            Button(NSLocalizedString("cancel", comment: ""), role: .cancel) { }
            Button(NSLocalizedString("disconnect", comment: ""), role: .destructive) {
                disconnectHealthKit()
            }
        } message: {
            Text(NSLocalizedString("disconnect_confirmation", comment: ""))
        }
        .onAppear {
            checkHealthKitAuthorization()
        }
    }
    
    private func checkHealthKitAuthorization() {
        guard HKHealthStore.isHealthDataAvailable() else {
            return
        }
        
        for type in typesToRead {
            let status = healthStore.authorizationStatus(for: type)
            if status == .sharingAuthorized {
                isHealthKitAuthorized = true
                return
            }
        }
        isHealthKitAuthorized = false
    }
    
    private func requestHealthKitAuthorization() {
        guard HKHealthStore.isHealthDataAvailable() else {
            showingAlert = true
            return
        }
        
        healthStore.requestAuthorization(toShare: nil, read: typesToRead) { success, error in
            DispatchQueue.main.async {
                if success {
                    isHealthKitAuthorized = true
                } else {
                    showingAlert = true
                }
            }
        }
    }
    
    private func disconnectHealthKit() {
        // 在这里实现断开连接的逻辑
        isHealthKitAuthorized = false
    }
}

struct HealthDataItemView: View {
    let icon: String
    let title: String
    let description: String
    
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .frame(width: 24)
                .foregroundColor(Color(hex: "9253f3"))
                .font(.system(size: 18))
            
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.system(size: 17))
                Text(description)
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
            
            Spacer()
        }
        .padding(.vertical, 16)
        .padding(.horizontal)
    }
}

#Preview {
    HealthConnectView()
}
