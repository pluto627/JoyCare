import SwiftUI
import Speech
import CoreML
import AVFoundation
import Foundation

// 使用相同的 ConversationSegment 定义



struct RecordingsView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var audioRecorder = AudioRecorder()
    @State private var showAlert = false
    @State private var recordingName = ""
    let recordId: UUID
    var onSave: ((Recording) -> Void)?
    
    @State private var recordings: [RecordingListItem] = []
    
    var body: some View {
        NavigationView {
            VStack {
                if audioRecorder.isRecording {
                    // 录音状态视图
                    VStack(spacing: 20) {
                        Text(NSLocalizedString("recording_in_progress", comment: ""))
                            .font(.headline)
                        
                        Button(action: stopRecording) {
                            Text(NSLocalizedString("stop_recording", comment: ""))
                                .foregroundColor(.white)
                                .padding()
                                .background(Color.red)
                                .cornerRadius(8)
                        }
                    }
                } else {
                    // 开始录音按钮
                    Button(action: startRecording) {
                        Text(NSLocalizedString("start_recording", comment: ""))
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.blue)
                            .cornerRadius(8)
                    }
                }
                
                if !recordings.isEmpty {
                    List {
                        ForEach(recordings) { recording in
                            VStack(alignment: .leading) {
                                Text(recording.createdAt, style: .date)
                                    .font(.headline)
                                Text("时长: \(Int(recording.duration))秒")
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                            }
                            .padding(.vertical, 4)
                        }
                    }
                } else {
                    Text(NSLocalizedString("no_recordings", comment: ""))
                        .foregroundColor(.gray)
                        .padding()
                }
            }
            .navigationTitle(NSLocalizedString("recordings", comment: ""))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(NSLocalizedString("cancel", comment: "")) {
                        dismiss()
                    }
                }
            }
        }
    }
    
    private func startRecording() {
        audioRecorder.startRecording()
    }
    
    private func stopRecording() {
        guard let audioURL = audioRecorder.stopRecording() else { return }
        saveRecording(from: audioURL)
    }
    
    private func saveRecording(from audioURL: URL) {
        let fileName = "\(UUID().uuidString).m4a"
        let permanentURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent(fileName)
        
        do {
            // 配置音频会话
            let audioSession = AVAudioSession.sharedInstance()
            try audioSession.setCategory(.playAndRecord, 
                                       mode: .default,
                                       options: [.defaultToSpeaker, .allowBluetooth])
            try audioSession.setActive(true)
            
            // 添加日志来检查源文件是否存在
            let fileExists = FileManager.default.fileExists(atPath: audioURL.path)
            print("源音频文件是否存在: \(fileExists)")
            print("源音频文件路径: \(audioURL.path)")
            
            // 确保目标URL不存在
            if FileManager.default.fileExists(atPath: permanentURL.path) {
                try FileManager.default.removeItem(at: permanentURL)
            }
            
            // 使用文件复制替代读写操作
            try FileManager.default.copyItem(at: audioURL, to: permanentURL)
            
            // 验证文件是否成功保存并检查文件大小
            let savedFileExists = FileManager.default.fileExists(atPath: permanentURL.path)
            if let attributes = try? FileManager.default.attributesOfItem(atPath: permanentURL.path) {
                let fileSize = attributes[.size] as? UInt64 ?? 0
                print("保存的音频文件大小: \(fileSize) bytes")
            }
            print("保存的音频文件是否存在: \(savedFileExists)")
            print("保存的音频文件路径: \(permanentURL.path)")
            
            let recording = Recording(
                id: UUID(),
                recordId: recordId,
                name: recordingName.isEmpty ? "就诊录音" : recordingName,
                date: Date(),
                audioURL: permanentURL,
                conversation: audioRecorder.transcribedText
            )
            
            var savedRecordings = RecordingStorage.shared.loadRecordings()
            if !savedRecordings.contains(where: { $0.id == recording.id }) {
                savedRecordings.append(recording)
                RecordingStorage.shared.saveRecordings(savedRecordings)
            }
            
            // 获取音频文件时长
            let audioAsset = AVAsset(url: permanentURL)
            let duration = CMTimeGetSeconds(audioAsset.duration)
            
            // 添加新录音到recordings数组
            let newRecording = RecordingListItem(
                url: permanentURL,
                createdAt: Date(),
                duration: duration
            )
            recordings.append(newRecording)
            
            onSave?(recording)
            showAlert = true
        } catch {
            print("保存录音失败: \(error.localizedDescription)")
            print("错误详情: \(error)")
        }
    }
    
    private func requestPermissions() {
        SFSpeechRecognizer.requestAuthorization { _ in }
        try? AVAudioSession.sharedInstance().requestRecordPermission { _ in }
    }
}

// 拆分子视图
struct RecordingStatusView: View {
    let isRecording: Bool
    
    var body: some View {
        if isRecording {
            Text("正在录音...")
                .font(.title)
                .foregroundColor(.red)
        }
    }
}

struct TranscriptionView: View {
    let transcribedText: [ConversationSegment]
    
    var body: some View {
        if !transcribedText.isEmpty {
            ScrollViewReader { proxy in
                ScrollView {
                    VStack(alignment: .leading, spacing: 12) {
                        ForEach(transcribedText.indices, id: \.self) { index in
                            TranscriptionRow(segment: transcribedText[index])
                                .id(index)
                        }
                    }
                    .padding()
                }
                .onChange(of: transcribedText.count) { _ in
                    withAnimation {
                        proxy.scrollTo(transcribedText.count - 1, anchor: .bottom)
                    }
                }
            }
        }
    }
}

struct TranscriptionRow: View {
    let segment: ConversationSegment
    @StateObject private var audioPlayer = AudioPlayer()
    
    var body: some View {
        VStack {
            HStack(alignment: .top) {
                Text(segment.speaker)
                    .font(.headline)
                    .foregroundColor(segment.speaker == "医生" ? .blue : .green)
                    .frame(width: 60)
                
                Text(segment.content)
                    .fixedSize(horizontal: false, vertical: true)
            }
            
            // 添加播放按钮
            if let audioURL = segment.audioURL {
                Button(action: {
                    if audioPlayer.isPlaying {
                        audioPlayer.stop()
                    } else {
                        audioPlayer.play(url: audioURL)
                    }
                }) {
                    Image(systemName: audioPlayer.isPlaying ? "stop.circle.fill" : "play.circle.fill")
                        .font(.system(size: 24))
                        .foregroundColor(.blue)
                }
            }
        }
    }
}

struct ControlButtons: View {
    let isRecording: Bool
    @Binding var recordingName: String
    let onRecord: () -> Void
    let onStop: () -> Void
    
    var body: some View {
        VStack {
            if !isRecording {
                TextField("录音名称", text: $recordingName)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.horizontal)
            }
            
            Button(action: {
                if isRecording {
                    onStop()
                } else {
                    onRecord()
                }
            }) {
                Image(systemName: isRecording ? "stop.circle.fill" : "record.circle.fill")
                    .font(.system(size: 64))
                    .foregroundColor(isRecording ? .red : .blue)
            }
        }
    }
}

// 音频录制管理器
class AudioRecorder: ObservableObject {
    @Published var isRecording = false
    @Published var transcribedText: [ConversationSegment] = []
    private var audioEngine = AVAudioEngine()
    private var audioFile: AVAudioFile?
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private var speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "zh-CN"))
    private var lastSpeechTime = Date()
    private var lastTranscription = ""
    private var currentSpeaker = "患者"
    private var recordingURL: URL?
    private var silenceTimer: Timer?
    private let silenceThreshold: TimeInterval = 1.5 // 调整为1.5秒的停顿检测
    
    private var currentSegment: String = ""
    private var processingTimer: Timer?
    
    private func getDocumentsDirectory() -> URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }
    
    func startRecording() {
        guard let recognizer = speechRecognizer, recognizer.isAvailable else {
            print("Speech recognition not available")
            return
        }
        
        // 创建新的录音文件URL
        let fileName = "\(Date().timeIntervalSince1970).m4a"
        recordingURL = getDocumentsDirectory().appendingPathComponent(fileName)
        
        do {
            let audioSession = AVAudioSession.sharedInstance()
            try audioSession.setCategory(.playAndRecord, 
                                       mode: .default,
                                       options: [.defaultToSpeaker, .allowBluetooth])
            try audioSession.setActive(true)
            
            let settings: [String: Any] = [
                AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
                AVSampleRateKey: 44100.0,
                AVNumberOfChannelsKey: 1,
                AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue,
                AVEncoderBitRateKey: 128000
            ]
            
            guard let recordingURL = recordingURL else { return }
            audioFile = try AVAudioFile(forWriting: recordingURL, settings: settings)
            
            recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
            guard let recognitionRequest = recognitionRequest else { return }
            
            let inputNode = audioEngine.inputNode
            recognitionRequest.shouldReportPartialResults = true
            
            recognitionTask = recognizer.recognitionTask(with: recognitionRequest) { [weak self] result, error in
                guard let self = self else { return }
                if let result = result {
                    let transcription = result.bestTranscription.formattedString
                    
                    // 重置处理计时器
                    self.processingTimer?.invalidate()
                    self.processingTimer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: false) { [weak self] _ in
                        guard let self = self else { return }
                        
                        // 检测到新的完整句子
                        if let newSentence = self.extractNewSentence(from: transcription) {
                            self.currentSegment = ""  // 清空当前段落
                            
                            DispatchQueue.main.async {
                                let segment = ConversationSegment(
                                    speaker: self.currentSpeaker,
                                    content: newSentence,
                                    timestamp: Date(),
                                    audioURL: self.recordingURL
                                )
                                self.transcribedText.append(segment)
                                
                                // 检查是否需要切换说话者
                                self.silenceTimer?.invalidate()
                                self.silenceTimer = Timer.scheduledTimer(withTimeInterval: self.silenceThreshold, repeats: false) { [weak self] _ in
                                    guard let self = self else { return }
                                    self.currentSpeaker = self.currentSpeaker == "患者" ? "医生" : "患者"
                                }
                            }
                        }
                    }
                }
            }
            
            let recordingFormat = inputNode.outputFormat(forBus: 0)
            inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { [weak self] buffer, _ in
                guard let self = self else { return }
                recognitionRequest.append(buffer)
                try? self.audioFile?.write(from: buffer)
            }
            
            audioEngine.prepare()
            try audioEngine.start()
            isRecording = true
            
        } catch {
            print("Recording failed: \(error.localizedDescription)")
        }
    }
    
    private func extractNewSentence(from transcription: String) -> String? {
        // 按句号、逗号等分割文本
        let separators = CharacterSet(charactersIn: "。，,.!?！？")
        let sentences = transcription.components(separatedBy: separators)
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
        
        // 如果有新的完整句子
        if let lastSentence = sentences.last,
           !lastSentence.isEmpty,
           lastSentence != currentSegment {
            currentSegment = lastSentence
            
            let segment = ConversationSegment(
                speaker: self.currentSpeaker,
                content: lastSentence,
                timestamp: Date()
            )
            
            DispatchQueue.main.async {
                self.transcribedText.append(segment)
            }
            
            return lastSentence
        }
        
        return nil
    }
    
    func stopRecording() -> URL? {
        defer {
            // 停止录音后重置音频会话
            do {
                try AVAudioSession.sharedInstance().setActive(false)
            } catch {
                print("停止音频会话失败: \(error)")
            }
        }
        
        processingTimer?.invalidate()
        processingTimer = nil
        silenceTimer?.invalidate()
        silenceTimer = nil
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)
        recognitionRequest?.endAudio()
        recognitionTask?.cancel()
        isRecording = false
        return recordingURL
    }
}

// 添加 AudioPlayer 类
class AudioPlayer: NSObject, ObservableObject, AVAudioPlayerDelegate {
    @Published var isPlaying = false
    private var audioPlayer: AVAudioPlayer?
    
    func play(url: URL) {
        do {
            // 配置音频会话
            let audioSession = AVAudioSession.sharedInstance()
            try audioSession.setCategory(.playback, mode: .default)
            try audioSession.setActive(true)
            
            // 创建播放器
            audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer?.delegate = self
            audioPlayer?.prepareToPlay()
            audioPlayer?.play()
            isPlaying = true
        } catch {
            print("音频播放初始化失败: \(error.localizedDescription)")
        }
    }
    
    func stop() {
        audioPlayer?.stop()
        isPlaying = false
        
        do {
            try AVAudioSession.sharedInstance().setActive(false)
        } catch {
            print("停止音频会话失败: \(error)")
        }
    }
    
    // AVAudioPlayerDelegate
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        DispatchQueue.main.async {
            self.isPlaying = false
        }
    }
}

// 在文件的适当位置添加RecordingListItem结构体
struct RecordingListItem: Identifiable {
    let id = UUID()
    let url: URL
    let createdAt: Date
    let duration: TimeInterval
}

#Preview {
    NavigationView {
        RecordingsView(recordId: UUID()) // 添加测试用的 UUID
    }
}
