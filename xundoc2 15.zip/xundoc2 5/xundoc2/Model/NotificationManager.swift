import Foundation
import UserNotifications

class NotificationManager {
    static let shared = NotificationManager()
    
    func requestAuthorization() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
            if granted {
                print(NSLocalizedString("notification_permission_success", comment: ""))
            }
        }
    }
    
    func scheduleReminderNotification(for reminder: Reminder) {
        let content = UNMutableNotificationContent()
        content.title = NSLocalizedString("reminder_title", comment: "")
        content.subtitle = reminder.title
        
        // Set different messages based on reminder type
        if reminder.type == NSLocalizedString("medication_reminder", comment: "") {
            content.body = NSLocalizedString("medication_reminder_body", comment: "")
        } else if reminder.type == NSLocalizedString("checkup_reminder", comment: "") {
            content.body = NSLocalizedString("checkup_reminder_body", comment: "")
        } else if reminder.type == NSLocalizedString("medical_visit_reminder", comment: "") {
            content.body = NSLocalizedString("medical_visit_reminder_body", comment: "")
        } else {
            content.body = NSLocalizedString("general_reminder_body", comment: "")
        }
        
        content.sound = .default
        
        let dateComponents = Calendar.current.dateComponents([.hour, .minute], from: reminder.date)
        let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: false)
        
        let request = UNNotificationRequest(
            identifier: reminder.id.uuidString,
            content: content,
            trigger: trigger
        )
        
        UNUserNotificationCenter.current().add(request)
    }
    
    func cancelNotification(for reminderId: UUID) {
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [reminderId.uuidString])
    }
} 