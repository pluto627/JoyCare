import Foundation

class LanguageManager: ObservableObject {
    @Published var currentLanguage: Language = .chinese
    
    enum Language: String {
        case chinese = "zh"
        case english = "en"
        
        var displayName: String {
            switch self {
            case .chinese: return "中文"
            case .english: return "English"
            }
        }
    }
    
    func toggleLanguage() {
        currentLanguage = currentLanguage == .chinese ? .english : .chinese
    }
} 