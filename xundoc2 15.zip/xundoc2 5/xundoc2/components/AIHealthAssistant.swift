import SwiftUI

// 添加Message类型定义
struct Message: Identifiable {
    let id = UUID()
    let content: String
    let isUser: Bool
    let timestamp: Date
    
    init(content: String, isUser: Bool) {
        self.content = content
        self.isUser = isUser
        self.timestamp = Date()
    }
}

struct AIHealthAssistant: View {
    @State private var userInput = ""
    @State private var messages: [Message] = []
    @State private var isLoading = false
    @State private var showError = false // 添加错误状态
    @State private var errorMessage = "" // 添加错误消息
    @FocusState private var isFocused: Bool
    
    var body: some View {
        VStack(spacing: 0) {
            // 消息列表
            ScrollView {
                LazyVStack(spacing: 16) {
                    ForEach(messages) { message in
                        MessageBubble(message: message)
                    }
                    
                    if isLoading {
                        HStack {
                            Spacer()
                            ProgressView()
                                .padding()
                            Spacer()
                        }
                    }
                }
                .padding()
            }
            
            // 输入区域
            VStack(spacing: 0) {
                Divider()
                HStack(alignment: .bottom) {
                    TextField(NSLocalizedString("enter_health_question", comment: ""),
                            text: $userInput,
                            axis: .vertical)
                        .textFieldStyle(.roundedBorder)
                        .focused($isFocused)
                        .lineLimit(1...5)
                    
                    Button(action: sendMessage) {
                        Image(systemName: "arrow.up.circle.fill")
                            .font(.system(size: 30))
                            .foregroundColor(userInput.isEmpty ? .gray : .blue)
                    }
                    .disabled(userInput.isEmpty || isLoading)
                }
                .padding()
            }
            .background(Color(UIColor.systemBackground))
        }
        .navigationTitle(NSLocalizedString("ai_health_assistant", comment: ""))
        .navigationBarTitleDisplayMode(.inline)
        .alert(NSLocalizedString("error", comment: ""), isPresented: $showError) {
            Button(NSLocalizedString("ok", comment: "")) {}
        } message: {
            Text(errorMessage)
        }
    }
    
    private func sendMessage() {
        guard !userInput.isEmpty else { return }
        
        let userMessage = Message(content: userInput, isUser: true)
        messages.append(userMessage)
        
        let currentInput = userInput
        userInput = ""
        
        isLoading = true
        
        // 模拟AI响应
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            let aiResponse = Message(
                content: "这是一个示例回复，实际应用中需要接入真实的AI服务。",
                isUser: false
            )
            messages.append(aiResponse)
            isLoading = false
        }
    }
}

// 添加MessageBubble视图
struct MessageBubble: View {
    let message: Message
    
    var body: some View {
        HStack {
            if message.isUser {
                Spacer()
            }
            
            Text(message.content)
                .padding()
                .background(message.isUser ? Color.blue : Color.gray.opacity(0.2))
                .foregroundColor(message.isUser ? .white : .primary)
                .cornerRadius(16)
            
            if !message.isUser {
                Spacer()
            }
        }
    }
}

#Preview {
    NavigationView {
        AIHealthAssistant()
    }
}
