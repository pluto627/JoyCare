import SwiftUI

struct ReminderViewItem: View {
    let reminder: Reminder
    let allReminders: [Reminder]
    @ObservedObject var reminderManager: ReminderManager
    @State private var showingEditSheet = false
    @State private var showingDeleteAlert = false
    @Environment(\.colorScheme) private var colorScheme
    
    private func getTypeIcon(_ type: String) -> String {
        switch type {
        case "用药提醒":
            return "pills.fill"
        case "检测提醒":
            return "heart.text.square.fill"
        case "就医提醒":
            return "cross.case.fill"
        case "运动提醒":
            return "figure.run"
        case "坐卧提醒":
            return "bed.double.fill"
        case "饮食提醒":
            return "fork.knife"
        case "睡眠提醒":
            return "moon.zzz.fill"
        default:
            return "bell.fill"
        }
    }
    
    var body: some View {
        Button(action: {
            showingEditSheet = true
        }) {
            HStack(spacing: 16) {
                // 左侧图标和餐后标签
                VStack(spacing: 8) {
                    Image(systemName: getTypeIcon(reminder.type))
                        .foregroundColor(.purple)
                        .font(.system(size: 24))
                    
                    // 餐后信息
                    if reminder.type == "用药提醒", let mealTime = reminder.beforeOrAfterMeal {
                        Text(mealTime)
                            .font(.system(size: 12))
                            .foregroundColor(.purple)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(Color.purple.opacity(0.1))
                            .cornerRadius(12)
                    }
                }
                .frame(width: 60)
                
                // 提醒内容
                VStack(alignment: .leading, spacing: 6) {
                    HStack(alignment: .top, spacing: 8) {
                        Text(reminder.title)
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(colorScheme == .dark ? .white : .black)
                            .fixedSize(horizontal: false, vertical: true)
                        
                        if let repeatPattern = reminder.repeatPattern {
                            HStack(spacing: 4) {
                                Image(systemName: "repeat")
                                    .font(.system(size: 12))
                                    .foregroundColor(.gray)
                                Text(getRepeatText(for: repeatPattern))
                                    .font(.system(size: 12))
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                    
                    if let description = reminder.description {
                        HStack(spacing: 8) {
                            Text(description)
                                .font(.system(size: 14))
                                .foregroundColor(.gray)
                            
                            if let mealTime = reminder.beforeOrAfterMeal {
                                Text("·")
                                    .foregroundColor(.gray)
                                Text(mealTime)
                                    .font(.system(size: 14))
                                    .foregroundColor(.gray)
                            }
                        }
                        .fixedSize(horizontal: false, vertical: true)
                        .multilineTextAlignment(.leading)
                    }
                }
                .padding(.vertical, 4)
                
                Spacer()
            }
            .padding(.vertical, 16)
            .padding(.horizontal, 20)
            .background(Color(hex: "FAFAFA"))
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color(hex: "E6E6E6"), lineWidth: 0.5)
            )
        }
        .contextMenu {
            Button(role: .destructive, action: {
                showingDeleteAlert = true
            }) {
                Label("删除", systemImage: "trash")
            }
        }
        .alert("确认删除", isPresented: $showingDeleteAlert) {
            Button("取消", role: .cancel) { }
            Button("删除", role: .destructive) {
                deleteReminders()
            }
        } message: {
            Text("确定要删除这个提醒吗？此操作无法撤销。")
        }
        .sheet(isPresented: $showingEditSheet) {
            if reminder.type == "用药提醒" {
                MedicationDetailView(
                    reminderManager: reminderManager,
                    records: allReminders
                )
            } else {
                EditReminderView(reminder: reminder, reminderManager: reminderManager)
            }
        }
    }
    
    private func getRepeatText(for pattern: String) -> String {
        switch pattern {
        case "daily":
            return "每天"
        case "alternate":
            return "隔天"
        case let custom where custom.starts(with: "custom_"):
            let days = custom.split(separator: "_")[1]
            return "每\(days)天"
        default:
            return ""
        }
    }
    
    private func formatTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        return formatter.string(from: date)
    }
    
    private var timeFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        return formatter
    }
    
    private func deleteReminders() {
        if reminder.type == "用药提醒" {
            for reminder in allReminders {
                reminderManager.reminders.removeAll { $0.id == reminder.id }
            }
        } else {
            reminderManager.reminders.removeAll { $0.id == reminder.id }
        }
        
        let tempReminder = Reminder(title: "", date: Date(), type: "")
        reminderManager.addReminder(tempReminder)
        reminderManager.reminders.removeAll { $0.id == tempReminder.id }
    }
} 