from flask import Flask, request, jsonify
from openai import OpenAI
import logging
import base64

app = Flask(__name__)

# 配置日志
logging.basicConfig(level=logging.INFO)

# OpenAI客户端配置
client = OpenAI(
    api_key = "sk-jd5MkIT85IKYqN4ETO2vVjyEpiygh5WPNt2yWNjTja3dCUbx",
    base_url = "https://api.agicto.cn/v1"
)

# 系统提示词，定义AI助手的角色
SYSTEM_PROMPT = """你是一位经验丰富的家庭医生。请分析这张医学检查报告，并提供专业的健康建议。

请按以下格式提供分析：
1. 报告概述：简要描述报告类型和主要内容
2. 异常指标分析：列出异常指标及其可能的健康影响
3. 健康建议：
   - 生活方式调整
   - 饮食建议
   - 是否需要进一步检查
   - 是否需要就医
4. 注意事项：需要特别关注的健康问题

请使用专业但通俗易懂的语言，帮助患者理解检查结果。"""

@app.route('/vision', methods=['POST'])
def vision_analysis():
    try:
        # 获取 base64 编码的图像
        image_data = request.json.get('image', '')
        if not image_data:
            return jsonify({'error': '未提供图像数据'}), 400
        
        # 使用 OpenAI 的 Vision 模型分析图像
        chat_completion = client.chat.completions.create(
            messages=[
                {
                    "role": "system",
                    "content": SYSTEM_PROMPT
                },
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": "请分析这张医学相关的图像，并提供专业的健康建议，告诉患者需要注意些什么，在以上报告有什么问题可能出现了什么健康上的问题。"},
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/jpeg;base64,{image_data}"
                            } 
                        }
                    ]
                }
            ],
            model="gpt-4-vision-preview",
        )
        
        # 添加错误处理和日志记录
        if not chat_completion or not chat_completion.choices:
            logging.error("Vision API 返回空结果")
            return jsonify({'error': '图像分析失败，请稍后重试'}), 500
            
        response = chat_completion.choices[0].message.content
        if not response:
            logging.error("Vision API 返回空内容")
            return jsonify({'error': '无法解析图像内容，请尝试上传清晰的医学相关图像'}), 500
            
        return jsonify({'response': response})

    except Exception as e:
        logging.error(f"Vision API Error: {str(e)}")
        return jsonify({'error': '服务器错误，请稍后重试'}), 500

@app.route('/report_analysis', methods=['POST'])
def report_analysis():
    try:
        # 获取 base64 编码的图像
        image_data = request.json.get('image', '')
        if not image_data:
            return jsonify({'error': '未提供图像数据'}), 400
        
        # 第一步：使用华为混元视觉模型提取图片文本
        logging.info("开始使用hunyuan-vision提取图片文本")
        text_extraction = client.chat.completions.create(
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": "这是一个医学报告，请你帮我把以上内容全部变为文本，尽可能保留所有数值和医学术语。"},
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/jpeg;base64,{image_data}"
                            } 
                        }
                    ]
                }
            ],
            model="hunyuan-vision",
        )
        
        if not text_extraction or not text_extraction.choices:
            logging.error("文本提取失败")
            return jsonify({'error': '文本提取失败，请稍后重试'}), 500
        
        extracted_text = text_extraction.choices[0].message.content
        if not extracted_text:
            logging.error("提取的文本为空")
            return jsonify({'error': '无法从图像中提取文本，请上传清晰的报告图片'}), 500
        
        logging.info(f"提取的文本: {extracted_text[:100]}...")
        
        # 第二步：使用deepseek-v3模型解读提取的文本
        logging.info("开始使用deepseek-v3解读文本")
        interpretation = client.chat.completions.create(
            messages=[
                {
                    "role": "system",
                    "content": """你是一位经验丰富的医学专家。请分析以下医学报告文本，并提供专业的健康建议。

请按以下格式提供分析，确保格式规范以便于前端解析：

## 报告类型
[简要说明这是什么类型的检查报告]

## 关键指标
- 指标名称1: 检测值 单位 (参考范围: 下限-上限 单位)
- 指标名称2: 检测值 单位 (参考范围: 下限-上限 单位)
- 指标名称3: 检测值 单位 (参考范围: 下限-上限 单位)
[列出所有关键指标，特别是异常指标，确保格式统一，便于前端解析]

## 异常指标分析
[解释异常指标的医学意义，每个异常指标单独一段]

## 综合分析
[根据所有指标给出整体健康状况评估]

## 健康建议
- 生活方式: [具体建议]
- 饮食建议: [具体建议]
- 进一步检查: [是否需要及建议]
- 就医建议: [是否需要就医及科室建议]

## 注意事项
[需要特别关注的健康问题]

请使用专业但通俗易懂的语言，帮助患者理解检查结果。确保格式规范，特别是关键指标部分，以便于前端解析。"""
                },
                {
                    "role": "user",
                    "content": f"请解读以下医学报告内容：\n\n{extracted_text}"
                }
            ],
            model="deepseek-v3",
        )
        
        if not interpretation or not interpretation.choices:
            logging.error("解读失败")
            return jsonify({'error': '解读失败，请稍后重试'}), 500
        
        interpretation_text = interpretation.choices[0].message.content
        if not interpretation_text:
            logging.error("解读结果为空")
            return jsonify({'error': '无法解读报告内容，请稍后重试'}), 500
        
        # 返回完整结果，包括原始提取文本和解读结果
        return jsonify({
            'extracted_text': extracted_text,
            'interpretation': interpretation_text
        })

    except Exception as e:
        logging.error(f"Report Analysis Error: {str(e)}")
        return jsonify({'error': f'服务器错误，请稍后重试: {str(e)}'}), 500

if __name__ == '__main__':
    # 使用8000端口替代默认的5000端口
    app.run(host='0.0.0.0', port=8000, debug=True)
