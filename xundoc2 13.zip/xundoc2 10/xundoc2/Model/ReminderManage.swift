import Foundation
import SwiftUI
// 添加 UserNotifications 框架
import UserNotifications

struct Reminder: Identifiable, Codable, Equatable {
    let id: UUID
    var title: String
    var date: Date
    var isCompleted: Bool
    var description: String?
    var type: String
    var repeatPattern: String?
    
    // 添加药品相关字段
    var dosage: String?          // 剂量
    var unit: String?           // 单位(片/毫升等)
    var medicineMethod: String?  // 服用方式
    var beforeOrAfterMeal: String? // 饭前/饭后
    var medicineNotes: String?   // 用药注意事项
    
    init(id: UUID = UUID(),
         title: String,
         date: Date,
         isCompleted: Bool = false,
         description: String? = nil,
         type: String = "用药提醒",
         repeatPattern: String? = nil,
         dosage: String? = nil,
         unit: String? = nil,
         medicineMethod: String? = nil,
         beforeOrAfterMeal: String? = nil,
         medicineNotes: String? = nil) {
        self.id = id
        self.title = title
        self.date = date
        self.isCompleted = isCompleted
        self.description = description
        self.type = type
        self.repeatPattern = repeatPattern
        self.dosage = dosage
        self.unit = unit
        self.medicineMethod = medicineMethod
        self.beforeOrAfterMeal = beforeOrAfterMeal
        self.medicineNotes = medicineNotes
    }
    
    // 实现 Equatable 协议的 == 方法
    static func == (lhs: Reminder, rhs: Reminder) -> Bool {
        return lhs.id == rhs.id &&
               lhs.title == rhs.title &&
               lhs.date == rhs.date &&
               lhs.isCompleted == rhs.isCompleted &&
               lhs.description == rhs.description &&
               lhs.type == rhs.type &&
               lhs.repeatPattern == rhs.repeatPattern &&
               lhs.dosage == rhs.dosage &&
               lhs.unit == rhs.unit &&
               lhs.medicineMethod == rhs.medicineMethod &&
               lhs.beforeOrAfterMeal == rhs.beforeOrAfterMeal &&
               lhs.medicineNotes == rhs.medicineNotes
    }
}

class ReminderManager: ObservableObject {
    @Published var reminders: [Reminder] = []
    
    init() {
        loadReminders()
        // 请求通知权限
        requestNotificationPermission()
    }
    
    // 请求通知权限
    private func requestNotificationPermission() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { success, error in
            if success {
                print("通知权限已获取")
            } else if let error = error {
                print("请求通知权限失败: \(error.localizedDescription)")
            }
        }
    }
    
    func addReminder(_ reminder: Reminder) {
        reminders.append(reminder)
        saveReminders()
        
        // 为新添加的提醒设置通知
        scheduleNotification(for: reminder)
    }
    
    // 为提醒设置本地通知
    private func scheduleNotification(for reminder: Reminder) {
        // 移除之前为该提醒设置的通知（如果有的话）
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [reminder.id.uuidString])
        
        let content = UNMutableNotificationContent()
        content.title = reminder.title
        content.body = reminder.description ?? "到了该执行的时间了"
        content.sound = .default
        
        // 根据提醒类型设置不同的通知正文
        switch reminder.type {
        case "用药提醒":
            var medicineInfo = ""
            if let dosage = reminder.dosage, let unit = reminder.unit {
                medicineInfo += "剂量: \(dosage)\(unit) "
            }
            if let method = reminder.medicineMethod {
                medicineInfo += "服用方式: \(method) "
            }
            if let mealTime = reminder.beforeOrAfterMeal {
                medicineInfo += "\(mealTime)"
            }
            content.body = medicineInfo.isEmpty ? "该吃药了" : medicineInfo
            
        case "运动提醒":
            content.body = "该进行运动锻炼了"
            
        case "喝水提醒":
            content.body = "该喝水了，保持水分很重要"
            
        case "睡眠提醒":
            content.body = "该休息了，保证充足的睡眠"
            
        case "复诊提醒":
            content.body = "您有一个复诊预约要记得安排"
            
        default:
            if let desc = reminder.description, !desc.isEmpty {
                content.body = desc
            }
        }
        
        // 创建时间触发器
        let triggerDate = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: reminder.date)
        let trigger = UNCalendarNotificationTrigger(dateMatching: triggerDate, repeats: false)
        
        // 创建通知请求
        let request = UNNotificationRequest(identifier: reminder.id.uuidString, content: content, trigger: trigger)
        
        // 添加通知请求
        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("设置通知失败: \(error.localizedDescription)")
            } else {
                print("成功设置通知: \(reminder.title) 在 \(reminder.date)")
            }
        }
    }
    
    func completeReminder(_ id: UUID) {
        withAnimation {
            if let index = reminders.firstIndex(where: { $0.id == id }) {
                let completedReminder = reminders[index]
                
                // 取消该提醒的通知
                UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [id.uuidString])
                
                // 如果是重复提醒，创建下一次提醒
                if let pattern = completedReminder.repeatPattern {
                    let calendar = Calendar.current
                    var nextDate: Date?
                    
                    switch pattern {
                    case "daily":
                        // 获取明天的相同时间
                        nextDate = calendar.date(byAdding: .day, value: 1, to: completedReminder.date)
                    case "alternate":
                        nextDate = calendar.date(byAdding: .day, value: 2, to: completedReminder.date)
                    case let custom where custom.starts(with: "custom_"):
                        if let days = Int(custom.split(separator: "_")[1]) {
                            nextDate = calendar.date(byAdding: .day, value: days, to: completedReminder.date)
                        }
                    default:
                        break
                    }
                    
                    if let nextDate = nextDate {
                        // 创建新的提醒，使用新的 UUID
                        let newReminder = Reminder(
                            id: UUID(), // 新的 UUID
                            title: completedReminder.title,
                            date: nextDate,
                            isCompleted: false,
                            description: completedReminder.description,
                            type: completedReminder.type,
                            repeatPattern: completedReminder.repeatPattern,
                            dosage: completedReminder.dosage,
                            unit: completedReminder.unit,
                            medicineMethod: completedReminder.medicineMethod,
                            beforeOrAfterMeal: completedReminder.beforeOrAfterMeal,
                            medicineNotes: completedReminder.medicineNotes
                        )
                        reminders.append(newReminder)
                        
                        // 为新的重复提醒设置通知
                        scheduleNotification(for: newReminder)
                    }
                }
                
                // 删除当前提醒
                reminders.remove(at: index)
                saveReminders()
            }
        }
    }
    
    private func loadReminders() {
        if let data = UserDefaults.standard.data(forKey: "reminders") {
            if let decoded = try? JSONDecoder().decode([Reminder].self, from: data) {
                self.reminders = decoded
                
                // 加载时重新设置所有提醒的通知
                for reminder in self.reminders {
                    if !reminder.isCompleted && reminder.date > Date() {
                        scheduleNotification(for: reminder)
                    }
                }
            }
        }
    }
    
    private func saveReminders() {
        if let encoded = try? JSONEncoder().encode(reminders) {
            UserDefaults.standard.set(encoded, forKey: "reminders")
        }
    }
    
    // 获取指定日期的提醒
    func getReminders(for date: Date) -> [Reminder] {
        let calendar = Calendar.current
        return reminders.filter { reminder in
            // 如果已完成，不显示
            if reminder.isCompleted {
                return false
            }
            
            // 检查是否是同一天
            if calendar.isDate(reminder.date, inSameDayAs: date) {
                return true
            }
            
            // 处理重复提醒
            if let pattern = reminder.repeatPattern {
                let components = calendar.dateComponents([.year, .month, .day], from: reminder.date, to: date)
                guard let daysDifference = components.day else { return false }
                
                switch pattern {
                case "daily":
                    // 对于每日重复，只显示当天的提醒
                    return calendar.isDate(reminder.date, equalTo: date, toGranularity: .day)
                case "alternate":
                    return daysDifference % 2 == 0
                case let custom where custom.starts(with: "custom_"):
                    if let days = Int(custom.split(separator: "_")[1]) {
                        return daysDifference % days == 0
                    }
                default:
                    return false
                }
            }
            
            return false
        }
    }
}
