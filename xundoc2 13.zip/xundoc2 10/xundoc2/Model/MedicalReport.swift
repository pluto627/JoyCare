import SwiftUI
import UIKit

struct MedicalReportModel: Identifiable, Codable {
    let id: UUID
    let recordId: UUID
    let type: String
    let date: Date
    let description: String
    var images: [UIImage]
    
    enum CodingKeys: String, CodingKey {
        case id, recordId, type, date, description
        case images
    }
    
    init(id: UUID = UUID(), 
         recordId: UUID, 
         type: String, 
         date: Date, 
         description: String = "", 
         images: [UIImage] = []) {
        self.id = id
        self.recordId = recordId
        self.type = type
        self.date = date
        self.description = description
        self.images = images
    }
    
    // 添加编码解码方法
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(id, forKey: .id)
        try container.encode(recordId, forKey: .recordId)
        try container.encode(type, forKey: .type)
        try container.encode(date, forKey: .date)
        try container.encode(description, forKey: .description)
        
        // 将图片转换为Data后编码
        let imageData = images.compactMap { $0.jpegData(compressionQuality: 0.8) }
        try container.encode(imageData, forKey: .images)
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(UUID.self, forKey: .id)
        recordId = try container.decode(UUID.self, forKey: .recordId)
        type = try container.decode(String.self, forKey: .type)
        date = try container.decode(Date.self, forKey: .date)
        description = try container.decode(String.self, forKey: .description)
        
        // 将Data转换回UIImage
        let imageData = try container.decode([Data].self, forKey: .images)
        images = imageData.compactMap { UIImage(data: $0) }
    }
} 