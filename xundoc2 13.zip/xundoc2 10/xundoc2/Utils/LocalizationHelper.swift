import Foundation
import SwiftUI

// 本地化辅助类
class LocalizationHelper {
    static let shared = LocalizationHelper()
    
    private init() {}
    
    // 强制刷新本地化资源
    func forceRefreshLocalization() {
        // 重置NSBundle缓存
        resetBundleCache()
        
        // 强制刷新所有视图
        NotificationCenter.default.post(name: NSNotification.Name("ForceRefreshViews"), object: nil)
        
        // 打印调试信息
        print("Forcing localization refresh")
        
        // 测试本地化是否生效
        let testKey = "medical_record"
        let localizedValue = NSLocalizedString(testKey, comment: "")
        print("Test localization: \(testKey) = \(localizedValue)")
    }
    
    // 重置NSBundle缓存
    private func resetBundleCache() {
        // 这是一个私有API调用，可能在未来的iOS版本中不可用
        // 但目前它是强制刷新本地化资源的最有效方法
        let selector = NSSelectorFromString("_resetBundleCache")
        if Bundle.main.responds(to: selector) {
            Bundle.main.perform(selector)
        }
        
        // 强制刷新主Bundle
        let mainBundleSelector = NSSelectorFromString("_resetStringsCache")
        if Bundle.main.responds(to: mainBundleSelector) {
            Bundle.main.perform(mainBundleSelector)
        }
        
        // 额外的刷新方法
        Bundle.main.localizedString(forKey: "", value: nil, table: nil)
    }
}

// 添加一个扩展，使NSLocalizedString能够实时刷新
extension String {
    // 重写本地化方法，确保每次都从Bundle中获取最新的本地化字符串
    static func localizedString(_ key: String, comment: String = "") -> String {
        // 强制从Bundle中获取最新的本地化字符串
        return Bundle.main.localizedString(forKey: key, value: nil, table: nil)
    }
}

// 添加一个视图修饰符，使视图能够响应语言变化
struct LocalizationModifier: ViewModifier {
    @State private var refreshToken = UUID()
    
    func body(content: Content) -> some View {
        content
            .id(refreshToken) // 这会在refreshToken变化时完全重建视图
            .onReceive(NotificationCenter.default.publisher(for: NSNotification.Name("ForceRefreshViews"))) { _ in
                // 当收到强制刷新通知时，更新refreshToken
                refreshToken = UUID()
                print("View refresh triggered by notification")
            }
    }
}

extension View {
    // 添加一个方法，使视图能够响应语言变化
    func localized() -> some View {
        self.modifier(LocalizationModifier())
    }
} 