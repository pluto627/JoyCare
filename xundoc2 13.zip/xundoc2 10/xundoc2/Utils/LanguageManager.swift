import Foundation
import SwiftUI

class LanguageManager: ObservableObject {
    @Published var currentLanguage: Language {
        didSet {
            // 保存语言设置到UserDefaults
            UserDefaults.standard.set(currentLanguage.rawValue, forKey: "appLanguage")
            // 设置应用程序的语言
            setAppLanguage(to: currentLanguage)
        }
    }
    
    // 添加一个属性来强制视图刷新
    @Published var refreshToken: UUID = UUID()
    
    enum Language: String {
        case chinese = "zh"
        case english = "en"
        
        var displayName: String {
            switch self {
            case .chinese: return "中文"
            case .english: return "English"
            }
        }
    }
    
    init() {
        // 从UserDefaults读取保存的语言设置，如果没有则默认为中文
        let savedLanguage = UserDefaults.standard.string(forKey: "appLanguage") ?? "zh"
        self.currentLanguage = Language(rawValue: savedLanguage) ?? .chinese
        
        // 初始化时设置应用程序语言
        setAppLanguage(to: currentLanguage)
    }
    
    func toggleLanguage() {
        currentLanguage = currentLanguage == .chinese ? .english : .chinese
    }
    
    func setLanguage(to language: Language) {
        currentLanguage = language
    }
    
    private func setAppLanguage(to language: Language) {
        // 设置应用程序的语言
        UserDefaults.standard.set([language.rawValue], forKey: "AppleLanguages")
        UserDefaults.standard.set(language.rawValue, forKey: "AppleLocale")
        UserDefaults.standard.synchronize()
        
        // 通知应用程序语言已更改
        NotificationCenter.default.post(name: NSNotification.Name("LanguageChanged"), object: nil)
        
        // 使用LocalizationHelper强制刷新本地化资源
        LocalizationHelper.shared.forceRefreshLocalization()
        
        // 生成新的刷新令牌，强制所有观察者刷新
        refreshToken = UUID()
        
        // 发布语言变更通知，让所有视图都能感知到变化
        objectWillChange.send()
        
        // 打印当前语言设置，用于调试
        print("Language changed to: \(language.rawValue)")
        print("AppleLanguages: \(UserDefaults.standard.array(forKey: "AppleLanguages") ?? [])")
        print("AppleLocale: \(UserDefaults.standard.string(forKey: "AppleLocale") ?? "nil")")
    }
} 