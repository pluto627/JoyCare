import SwiftUI

// 移除 @main 标记，因为我们已经在 xundoc2App.swift 中使用了它
struct YourApp {
    // 如果这个结构体不再需要，可以完全删除这个文件
    // 如果需要保留一些功能，可以将它们移动到适当的地方
} 
