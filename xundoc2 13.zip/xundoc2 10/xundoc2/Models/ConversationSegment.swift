import Foundation

public struct ConversationSegment: Identifiable, Codable {
    public let id: UUID
    public let speaker: String
    public let content: String
    public let timestamp: Date
    public var audioURL: URL?
    
    public init(id: UUID = UUID(), speaker: String, content: String, timestamp: Date, audioURL: URL? = nil) {
        self.id = id
        self.speaker = speaker
        self.content = content
        self.timestamp = timestamp
        self.audioURL = audioURL
    }
    
    private enum CodingKeys: String, CodingKey {
        case id, speaker, content, timestamp, audioURL
    }
    
    // 将 encode 方法声明为 public
    public func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(id, forKey: .id)
        try container.encode(speaker, forKey: .speaker)
        try container.encode(content, forKey: .content)
        try container.encode(timestamp, forKey: .timestamp)
        try container.encode(audioURL?.absoluteString, forKey: .audioURL)
    }
    
    // 将 init(from:) 声明为 public
    public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(UUID.self, forKey: .id)
        speaker = try container.decode(String.self, forKey: .speaker)
        content = try container.decode(String.self, forKey: .content)
        timestamp = try container.decode(Date.self, forKey: .timestamp)
        if let urlString = try container.decodeIfPresent(String.self, forKey: .audioURL) {
            audioURL = URL(string: urlString)
        }
    }
} 