import Foundation
import UIKit
import UserNotifications

class ReportAnalysisService {
    static let shared = ReportAnalysisService()
    
    private let baseURL = "http://192.168.1.14:8000"
    
    // 跟踪待处理的报告
    private var pendingReports: [UUID: PendingReport] = [:]
    
    private init() {
        // 请求通知权限
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
            if granted {
                print("通知权限已获取")
            } else if let error = error {
                print("通知权限错误: \(error.localizedDescription)")
            }
        }
    }
    
    // 提交报告进行分析，返回任务ID
    func submitReportForAnalysis(recordId: UUID, type: String, date: Date, images: [UIImage]) -> UUID {
        let taskId = UUID()
        
        // 创建待处理报告
        let pendingReport = PendingReport(
            taskId: taskId,
            recordId: recordId,
            type: type,
            date: date,
            images: images,
            status: .processing
        )
        
        // 保存待处理报告
        pendingReports[taskId] = pendingReport
        
        // 后台处理
        DispatchQueue.global(qos: .userInitiated).async {
            // 如果有多张图片，选择第一张进行分析
            if let image = images.first {
                self.analyzeReport(image: image) { result in
                    DispatchQueue.main.async {
                        switch result {
                        case .success(let analysisResult):
                            // 更新待处理报告状态
                            if var report = self.pendingReports[taskId] {
                                report.status = .completed
                                report.extractedText = analysisResult.extractedText
                                report.interpretation = analysisResult.interpretation
                                self.pendingReports[taskId] = report
                                
                                // 保存报告
                                let medicalReport = MedicalReport(
                                    recordId: recordId,
                                    type: type,
                                    date: date,
                                    images: images,
                                    extractedText: analysisResult.extractedText,
                                    interpretation: analysisResult.interpretation
                                )
                                
                                // 保存到存储
                                var savedReports = ReportStorage.shared.loadReports()
                                // 确保不重复添加
                                if !savedReports.contains(where: { $0.id == medicalReport.id }) {
                                    savedReports.append(medicalReport)
                                    ReportStorage.shared.saveReports(savedReports)
                                }
                                
                                // 发送通知
                                self.sendNotification(
                                    title: "报告分析完成",
                                    body: "您的\(type)报告已完成分析"
                                )
                                
                                // 通知观察者
                                NotificationCenter.default.post(
                                    name: .reportAnalysisCompleted,
                                    object: nil,
                                    userInfo: ["taskId": taskId, "reportId": medicalReport.id]
                                )
                            }
                            
                        case .failure(let error):
                            // 更新待处理报告状态为失败
                            if var report = self.pendingReports[taskId] {
                                report.status = .failed(error.localizedDescription)
                                self.pendingReports[taskId] = report
                                
                                // 发送失败通知
                                self.sendNotification(
                                    title: "报告分析失败",
                                    body: "您的\(type)报告分析失败: \(error.localizedDescription)"
                                )
                                
                                // 通知观察者
                                NotificationCenter.default.post(
                                    name: .reportAnalysisFailed,
                                    object: nil,
                                    userInfo: ["taskId": taskId, "error": error.localizedDescription]
                                )
                            }
                        }
                    }
                }
            }
        }
        
        return taskId
    }
    
    // 发送本地通知
    private func sendNotification(title: String, body: String) {
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = body
        content.sound = .default
        
        let request = UNNotificationRequest(
            identifier: UUID().uuidString,
            content: content,
            trigger: UNTimeIntervalNotificationTrigger(timeInterval: 0.1, repeats: false)
        )
        
        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("发送通知错误: \(error.localizedDescription)")
            }
        }
    }
    
    // 获取任务状态
    func getTaskStatus(for taskId: UUID) -> TaskStatus? {
        return pendingReports[taskId]?.status
    }
    
    // 原始分析方法
    func analyzeReport(image: UIImage, completion: @escaping (Result<ReportAnalysisResult, Error>) -> Void) {
        guard let url = URL(string: "\(baseURL)/report_analysis") else {
            completion(.failure(APIError.invalidURL))
            return
        }
        
        // 将图片转换为 base64 编码
        guard let imageData = image.jpegData(compressionQuality: 0.7) else {
            completion(.failure(APIError.invalidImageData))
            return
        }
        
        let base64Image = imageData.base64EncodedString()
        
        // 准备请求数据
        let requestBody: [String: Any] = ["image": base64Image]
        
        guard let jsonData = try? JSONSerialization.data(withJSONObject: requestBody) else {
            completion(.failure(APIError.invalidRequestData))
            return
        }
        
        // 创建请求
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.httpBody = jsonData
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // 发送请求
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let data = data else {
                completion(.failure(APIError.noData))
                return
            }
            
            do {
                if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any] {
                    if let errorMessage = json["error"] as? String {
                        completion(.failure(APIError.serverError(errorMessage)))
                        return
                    }
                    
                    guard let extractedText = json["extracted_text"] as? String,
                          let interpretation = json["interpretation"] as? String else {
                        completion(.failure(APIError.invalidResponse))
                        return
                    }
                    
                    let result = ReportAnalysisResult(
                        extractedText: extractedText,
                        interpretation: interpretation
                    )
                    
                    completion(.success(result))
                } else {
                    completion(.failure(APIError.invalidResponse))
                }
            } catch {
                completion(.failure(error))
            }
        }
        
        task.resume()
    }
}

// 待处理报告模型
struct PendingReport {
    let taskId: UUID
    let recordId: UUID
    let type: String
    let date: Date
    let images: [UIImage]
    var status: TaskStatus
    var extractedText: String?
    var interpretation: String?
}

// 任务状态枚举
enum TaskStatus {
    case processing
    case completed
    case failed(String)
}

// 报告分析结果模型
struct ReportAnalysisResult {
    let extractedText: String
    let interpretation: String
}

// 添加通知名称扩展
extension Notification.Name {
    static let reportAnalysisCompleted = Notification.Name("reportAnalysisCompleted")
    static let reportAnalysisFailed = Notification.Name("reportAnalysisFailed")
}

// API错误枚举
enum APIError: Error {
    case invalidURL
    case invalidRequestData
    case noData
    case invalidResponse
    case invalidImageData
    case serverError(String)
    
    var localizedDescription: String {
        switch self {
        case .invalidURL:
            return "无效的URL"
        case .invalidRequestData:
            return "无效的请求数据"
        case .noData:
            return "服务器未返回数据"
        case .invalidResponse:
            return "无效的响应数据"
        case .invalidImageData:
            return "无效的图片数据"
        case .serverError(let message):
            return "服务器错误: \(message)"
        }
    }
} 
