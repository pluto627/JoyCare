import SwiftUI

struct AudioWaveformBar: View {
    let index: Int
    let amplitude: CGFloat
    let barWidth: CGFloat
    
    @State private var height: CGFloat = 0
    
    // 添加显式初始化器
    init(index: Int, amplitude: CGFloat, barWidth: CGFloat) {
        self.index = index
        self.amplitude = amplitude
        self.barWidth = barWidth
    }
    
    private var barColor: Color {
        Color(red: 0.44, green: 0.36, blue: 0.98) // 紫色，模拟截图中的颜色
    }
    
    private var maxHeight: CGFloat = 80
    
    var body: some View {
        RoundedRectangle(cornerRadius: barWidth / 2)
            .fill(barColor)
            .frame(width: barWidth, height: height)
            .animation(.spring(response: 0.15, dampingFraction: 0.86, blendDuration: 0), value: height)
            .onAppear {
                // 初始显示时有个动画效果
                DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.02) {
                    self.height = amplitude * maxHeight
                }
            }
            .onChange(of: amplitude) { newValue in
                self.height = newValue * maxHeight
            }
    }
}

struct AudioWaveformView: View {
    var audioLevel: CGFloat // 音量大小，范围0.0-1.0
    var isPaused: Bool = false
    
    private let numberOfBars = 30
    private let minBarHeight: CGFloat = 3
    private let spacing: CGFloat = 4
    private let barWidth: CGFloat = 3
    
    var body: some View {
        HStack(spacing: spacing) {
            ForEach(0..<numberOfBars, id: \.self) { index in
                AudioWaveformBar(
                    index: index,
                    amplitude: isPaused ? 0 : generateAmplitude(for: index),
                    barWidth: barWidth
                )
            }
        }
        .frame(height: 100)
        .padding(.horizontal)
    }
    
    // 为每个柱体生成高度
    private func generateAmplitude(for index: Int) -> CGFloat {
        let middleIndex = numberOfBars / 2
        let distanceFromMiddle = abs(index - middleIndex)
        let baseAmplitude = max(0.3, 1.0 - CGFloat(distanceFromMiddle) / CGFloat(middleIndex))
        
        // 添加随机性和音量影响
        let randomVariation = CGFloat.random(in: -0.15...0.15)
        let volumeInfluence = baseAmplitude * audioLevel + randomVariation
        
        // 确保振幅在合理范围内
        return max(minBarHeight / 100, min(volumeInfluence, 1.0))
    }
}

#Preview {
    VStack(spacing: 30) {
        AudioWaveformView(audioLevel: 0.2)
        AudioWaveformView(audioLevel: 0.5)
        AudioWaveformView(audioLevel: 0.8)
        AudioWaveformView(audioLevel: 1.0, isPaused: true)
    }
    .padding()
    .previewLayout(.sizeThatFits)
    .background(Color.black.opacity(0.1))
} 