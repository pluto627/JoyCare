import SwiftUI

struct CommonFunctionsSection: View {
    @EnvironmentObject private var languageManager: LanguageManager
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(NSLocalizedString("common_functions", comment: ""))
                .font(.title3)
                .bold()
            
            VStack(spacing: 15) {
                FunctionCard(
                    icon: "person.2",
                    title: NSLocalizedString("agent_booking", comment: ""),
                    subtitle: NSLocalizedString("smart_medical_service", comment: ""),
                    description: NSLocalizedString("online_service", comment: "")
                )
                
                FunctionCard(
                    icon: "chart.bar",
                    title: NSLocalizedString("daily_analysis", comment: ""),
                    subtitle: NSLocalizedString("health_data_tracking", comment: ""),
                    description: NSLocalizedString("professional_analysis", comment: "")
                )
            }
        }
        .localized()
        .id(languageManager.refreshToken)
    }
}

// 功能卡片
struct FunctionCard: View {
    let icon: String
    let title: String
    let subtitle: String
    let description: String
    @Environment(\.colorScheme) private var colorScheme
    
    var body: some View {
        HStack {
            Image(systemName: icon)
                .font(.title2)
                .foregroundColor(.purple)
                .frame(width: 40, height: 40)
                .background(Color.purple.opacity(0.1))
                .cornerRadius(10)
            
            VStack(alignment: .leading) {
                Text(title)
                    .font(.headline)
                Text(subtitle)
                    .font(.subheadline)
                    .foregroundColor(.gray)
                Text(description)
                    .font(.caption)
                    .foregroundColor(.gray)
            }
            Spacer()
        }
        .padding()
        .background(colorScheme == .dark ? Color.black.opacity(0.3) : Color.white)
        .cornerRadius(15)
        .shadow(color: colorScheme == .dark ? Color.clear : Color.gray.opacity(0.1), radius: 5)
        .localized()
    }
}

#Preview {
    CommonFunctionsSection()
}
