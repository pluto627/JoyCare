import SwiftUI

struct HealthDataCard: View {
    @StateObject private var healthManager = HealthKitManager.shared
    @EnvironmentObject private var languageManager: LanguageManager
    
    var body: some View {
        NavigationLink(destination: HealthAnalysisView()) {
            ZStack {
                // 渐变背景
                RoundedRectangle(cornerRadius: 25)
                    .fill(
                        LinearGradient(
                            gradient: Gradient(colors: [
                                Color(red: 0.53, green: 0.23, blue: 0.96),  // 亮紫色
                                Color(red: 0.43, green: 0.15, blue: 0.85)   // 深紫色
                            ]),
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .overlay(
                        // 添加光晕效果
                        RoundedRectangle(cornerRadius: 25)
                            .fill(
                                LinearGradient(
                                    gradient: Gradient(colors: [
                                        Color.white.opacity(0.2),
                                        Color.white.opacity(0)
                                    ]),
                                    startPoint: .topLeading,
                                    endPoint: .center
                                )
                            )
                    )
                    .overlay(
                        // 添加细微边框
                        RoundedRectangle(cornerRadius: 25)
                            .strokeBorder(Color.white.opacity(0.2), lineWidth: 0.5)
                    )
                
                VStack(spacing: 10) {
                    // 标题栏
                    HStack {
                        Text(NSLocalizedString("today_health_data", comment: ""))
                            .font(.system(size: 18, weight: .medium))
                            .foregroundColor(.white)
                        Spacer()
                        Text(formatTime(healthManager.lastUpdateTime))
                            .font(.system(size: 12))
                            .foregroundColor(.white.opacity(0.8))
                        
                    }
                    .padding(.bottom, 8)
                    
                    // 数据展示
                    HStack(spacing: 0) {
                        DataItem(
                            value: "\(healthManager.steps)",
                            unit: NSLocalizedString("steps", comment: "")
                        )
                        .frame(maxWidth: .infinity)
                        
                       
                        .frame(maxWidth: .infinity)
                        
                        DataItem(
                            value: String(format: "%.1f", healthManager.distance),
                            unit: NSLocalizedString("distance", comment: "")
                        )
                        .frame(maxWidth: .infinity)
                        
                        DataItem(
                            value: String(format: "%.1f", healthManager.calories),
                            unit: NSLocalizedString("calories", comment: "")
                        )
                        .frame(maxWidth: .infinity)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
            }
            .frame(height: 130)
            .shadow(color: Color.purple.opacity(0.3), radius: 15, x: 0, y: 5)
        }
        .localized()
        .id(languageManager.refreshToken)
    }
    
    private func formatTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        return formatter.string(from: date) + " " + NSLocalizedString("updated_at", comment: "")
    }
}

struct DataItem: View {
    let value: String
    let unit: String
    
    var body: some View {
        VStack(spacing: 4) {
            Text(value)
                .font(.system(size: 24, weight: .medium))
                .foregroundColor(.white)
                .shadow(color: .white.opacity(0.2), radius: 2, x: 0, y: 0)
            Text(unit)
                .font(.system(size: 14))
                .foregroundColor(.white.opacity(0.8))
        }
        .localized()
    }
}

#Preview {
    HealthDataCard()
}
