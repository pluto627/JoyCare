import SwiftUI

struct ReminderSection: View {
    @ObservedObject var reminderManager: ReminderManager
    @State private var showingAddReminder = false
    @Environment(\.colorScheme) private var colorScheme
    @EnvironmentObject private var languageManager: LanguageManager
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            // 标题行
            HStack {
                Text(NSLocalizedString("today_reminders", comment: ""))
                    .font(.headline)
                    .fontWeight(.medium)
                    .foregroundColor(colorScheme == .dark ? .white : .black)
                
                Spacer()
                
                Button(action: {
                    showingAddReminder = true
                }) {
                    Text(NSLocalizedString("add", comment: ""))
                        .font(.subheadline)
                        .foregroundColor(.blue)
                }
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 12)
            
            // 提醒列表
            VStack(spacing: 10) {
                ForEach(reminderManager.getReminders(for: Date())) { reminder in
                    ReminderItemView(
                        reminder: reminder,
                        allReminders: [reminder],
                        reminderManager: reminderManager
                    )
                    .background(
                        RoundedRectangle(cornerRadius: 16)
                            .fill(colorScheme == .dark ? Color.black.opacity(0.3) : Color(hex: "FAFAFA"))
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 16)
                            .stroke(colorScheme == .dark ? Color.gray.opacity(0.3) : Color(UIColor.systemGray4), lineWidth: 0.5)
                    )
                }
            }
            .padding(.bottom, 16)
        }
        .frame(maxWidth: .infinity)
        .sheet(isPresented: $showingAddReminder) {
            SelectReminderTypeView(reminderManager: reminderManager)
        }
        .localized()
        .id(languageManager.refreshToken)
        .padding(.horizontal)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(colorScheme == .dark ? Color.black.opacity(0.2) : Color(hex: "FAFAFA"))
        )
    }
}

struct ReminderItemView: View {
    let reminder: Reminder
    let allReminders: [Reminder]
    @ObservedObject var reminderManager: ReminderManager
    @State private var showingEditSheet = false
    @Environment(\.colorScheme) private var colorScheme
    @EnvironmentObject private var languageManager: LanguageManager
    
    private func getTypeIcon(_ type: String) -> String {
        switch type {
        case NSLocalizedString("medication_reminder", comment: ""):
            return "pills"
        case NSLocalizedString("checkup_reminder", comment: ""):
            return "heart.text.square"
        case NSLocalizedString("medical_visit_reminder", comment: ""):
            return "cross.case"
        case NSLocalizedString("exercise_reminder", comment: ""):
            return "figure.walk"
        case NSLocalizedString("posture_reminder", comment: ""):
            return "figure.stand"
        case NSLocalizedString("diet_reminder", comment: ""):
            return "fork.knife"
        case NSLocalizedString("sleep_reminder", comment: ""):
            return "moon.zzz"
        case NSLocalizedString("water_reminder", comment: ""):
            return "drop"
        case NSLocalizedString("eye_protection_reminder", comment: ""):
            return "eye"
        case NSLocalizedString("oral_hygiene_reminder", comment: ""):
            return "mouth"
        case NSLocalizedString("skin_care_reminder", comment: ""):
            return "hand.raised"
        case NSLocalizedString("custom_reminder", comment: ""):
            return "plus"
        default:
            return "bell"
        }
    }
    
    private func getTypeColor(_ type: String) -> Color {
        switch type {
        case NSLocalizedString("medication_reminder", comment: ""):
            return .blue
        case NSLocalizedString("exercise_reminder", comment: ""):
            return .green
        case NSLocalizedString("water_reminder", comment: ""):
            return Color(hex: "00AEEF")
        case NSLocalizedString("sleep_reminder", comment: ""):
            return .indigo
        case NSLocalizedString("posture_reminder", comment: ""):
            return .orange
        case NSLocalizedString("eye_protection_reminder", comment: ""):
            return Color(hex: "5856D6")
        case NSLocalizedString("oral_hygiene_reminder", comment: ""):
            return .pink
        case NSLocalizedString("skin_care_reminder", comment: ""):
            return Color(hex: "8E8E93")
        case NSLocalizedString("medical_visit_reminder", comment: ""), 
             NSLocalizedString("checkup_reminder", comment: ""),
             NSLocalizedString("follow_up_reminder", comment: ""):
            return .red
        case NSLocalizedString("diet_reminder", comment: ""):
            return .orange
        case NSLocalizedString("custom_reminder", comment: ""):
            return .purple
        default:
            return .purple
        }
    }
    
    var body: some View {
        Button(action: {
            showingEditSheet = true
        }) {
            VStack(alignment: .leading, spacing: 12) {
                HStack(spacing: 16) {
                    // 左侧图标和服药时间标签
                    VStack(spacing: 8) {
                        Image(systemName: getTypeIcon(reminder.type))
                            .foregroundColor(getTypeColor(reminder.type))
                            .font(.system(size: 24))
                        
                        // 服药时间标签（仅用药提醒显示）
                        if reminder.type == NSLocalizedString("medication_reminder", comment: ""),
                           let mealTime = reminder.beforeOrAfterMeal {
                            Text(mealTime)
                                .font(.system(size: 12))
                                .foregroundColor(getTypeColor(reminder.type))
                                .padding(.horizontal, 8)
                                .padding(.vertical, 4)
                                .background(getTypeColor(reminder.type).opacity(0.1))
                                .cornerRadius(12)
                        }
                    }
                    .frame(width: 50)
                    
                    // 分隔线
                    Rectangle()
                        .fill(Color(.systemGray5))
                        .frame(width: 1, height: 45)
                    
                    // 标题和描述
                    VStack(alignment: .leading, spacing: 4) {
                        // 标题
                        Text(reminder.title)
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(colorScheme == .dark ? .white : .black)
                            .fixedSize(horizontal: false, vertical: true) // 允许标题换行
                        
                        // 描述信息
                        if let description = reminder.description {
                            Text(description)
                                .font(.system(size: 14))
                                .foregroundColor(.gray)
                                .lineLimit(calculateLineLimit(for: description)) // 根据字符长度决定是否限制行数
                        }
                    }
                    
                    Spacer()
                    
                    // 完成按钮和时间
                    VStack(alignment: .trailing, spacing: 8) {
                        Text(formatTime(reminder.date))
                            .font(.system(size: 14))
                            .foregroundColor(.gray)
                            .padding(.vertical, 4)
                        
                        Button(action: {
                            reminderManager.completeReminder(reminder.id)
                        }) {
                            Text(NSLocalizedString("complete", comment: ""))
                                .font(.system(size: 14, weight: .medium))
                                .foregroundColor(.white)
                                .padding(.horizontal, 12)
                                .padding(.vertical, 6)
                                .background(getTypeColor(reminder.type))
                                .cornerRadius(14)
                        }
                    }
                    .frame(height: 45, alignment: .center)
                }
            }
            .padding(.vertical, 16)
            .padding(.horizontal, 16)
        }
        .sheet(isPresented: $showingEditSheet) {
            if reminder.type == NSLocalizedString("medication_reminder", comment: "") {
                MedicationDetailView(
                    reminderManager: reminderManager,
                    records: allReminders
                )
            } else {
                EditReminderView(reminder: reminder, reminderManager: reminderManager)
            }
        }
        .localized()
        .id(languageManager.refreshToken)
    }
    
    private func getRepeatText(for pattern: String) -> String {
        switch pattern {
        case "daily":
            return NSLocalizedString("daily", comment: "")
        case "alternate":
            return NSLocalizedString("alternate_days", comment: "")
        case let custom where custom.starts(with: "custom_"):
            let days = custom.split(separator: "_")[1]
            return String(format: NSLocalizedString("every_n_days", comment: ""), String(days))
        default:
            return ""
        }
    }
    
    private func formatTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        return formatter.string(from: date)
    }
    
    // 根据字符长度计算行数限制
    private func calculateLineLimit(for text: String) -> Int? {
        let byteCount = text.utf8.count
        return byteCount > 24 ? 2 : nil // 超过24字节时限制为2行，否则不限制
    }
}

struct EditReminderView: View {
    @Environment(\.dismiss) var dismiss
    @ObservedObject var reminderManager: ReminderManager
    @State private var title: String
    @State private var selectedTime: Date
    @State private var selectedType: String
    @State private var description: String
    @State private var showDeleteAlert = false
    @State private var selectedFrequency: String
    @State private var customDays: Int
    @EnvironmentObject private var languageManager: LanguageManager
    
    let reminder: Reminder
    
    init(reminder: Reminder, reminderManager: ReminderManager) {
        self.reminder = reminder
        self.reminderManager = reminderManager
        _title = State(initialValue: reminder.title)
        _selectedTime = State(initialValue: reminder.date)
        _selectedType = State(initialValue: reminder.type)
        _description = State(initialValue: reminder.description ?? "")
        
        // 初始化重复模式
        let (frequency, days) = Self.parseRepeatPattern(reminder.repeatPattern)
        _selectedFrequency = State(initialValue: frequency)
        _customDays = State(initialValue: days)
    }
    
    private static func parseRepeatPattern(_ pattern: String?) -> (String, Int) {
        guard let pattern = pattern else { return (NSLocalizedString("no_repeat", comment: ""), 1) }
        
        switch pattern {
        case "daily":
            return (NSLocalizedString("daily", comment: ""), 1)
        case "alternate":
            return (NSLocalizedString("alternate_days", comment: ""), 2)
        case let custom where custom.starts(with: "custom_"):
            let days = Int(custom.split(separator: "_")[1]) ?? 1
            return (NSLocalizedString("custom", comment: ""), days)
        default:
            return (NSLocalizedString("no_repeat", comment: ""), 1)
        }
    }
    
    private var reminderTypes: [String] {
        [
            NSLocalizedString("medication_reminder", comment: ""),
            NSLocalizedString("checkup_reminder", comment: ""),
            NSLocalizedString("medical_visit_reminder", comment: ""),
            NSLocalizedString("exercise_reminder", comment: ""),
            NSLocalizedString("posture_reminder", comment: ""),
            NSLocalizedString("diet_reminder", comment: ""),
            NSLocalizedString("sleep_reminder", comment: "")
        ]
    }
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text(NSLocalizedString("basic_info", comment: ""))) {
                    TextField(NSLocalizedString("reminder_content", comment: ""), text: $title)
                    DatePicker(NSLocalizedString("reminder_time", comment: ""), selection: $selectedTime, displayedComponents: .hourAndMinute)
                }
                
                Section(header: Text(NSLocalizedString("reminder_type", comment: ""))) {
                    Picker(NSLocalizedString("type", comment: ""), selection: $selectedType) {
                        ForEach(reminderTypes, id: \.self) { type in
                            Text(type).tag(type)
                        }
                    }
                }
                
                Section(header: Text(NSLocalizedString("repeat", comment: ""))) {
                    Picker(NSLocalizedString("repeat", comment: ""), selection: $selectedFrequency) {
                        Text(NSLocalizedString("no_repeat", comment: "")).tag(NSLocalizedString("no_repeat", comment: ""))
                        Text(NSLocalizedString("daily", comment: "")).tag(NSLocalizedString("daily", comment: ""))
                        Text(NSLocalizedString("alternate_days", comment: "")).tag(NSLocalizedString("alternate_days", comment: ""))
                        Text(NSLocalizedString("custom", comment: "")).tag(NSLocalizedString("custom", comment: ""))
                    }
                    
                    if selectedFrequency == NSLocalizedString("custom", comment: "") {
                        Stepper(String(format: NSLocalizedString("every_n_days", comment: ""), customDays), value: $customDays, in: 1...30)
                    }
                }
                
                Section(header: Text(NSLocalizedString("notes", comment: ""))) {
                    TextEditor(text: $description)
                        .frame(height: 100)
                }
                
                Section {
                    HStack {
                        Spacer()
                        Button(action: {
                            showDeleteAlert = true
                        }) {
                            Text(NSLocalizedString("delete_reminder", comment: ""))
                                .foregroundColor(.red)
                        }
                        Spacer()
                    }
                }
            }
            .navigationTitle(NSLocalizedString("edit_reminder", comment: ""))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(NSLocalizedString("cancel", comment: "")) {
                        dismiss()
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(NSLocalizedString("save", comment: "")) {
                        saveChanges()
                    }
                    .disabled(title.isEmpty)
                }
            }
            .alert(NSLocalizedString("confirm_delete", comment: ""), isPresented: $showDeleteAlert) {
                Button(NSLocalizedString("cancel", comment: ""), role: .cancel) { }
                Button(NSLocalizedString("delete", comment: ""), role: .destructive) {
                    deleteReminder()
                }
            } message: {
                Text(NSLocalizedString("delete_reminder_confirmation", comment: ""))
            }
        }
        .localized()
        .id(languageManager.refreshToken)
    }
    
    private func getRepeatPattern() -> String? {
        switch selectedFrequency {
        case NSLocalizedString("daily", comment: ""):
            return "daily"
        case NSLocalizedString("alternate_days", comment: ""):
            return "alternate"
        case NSLocalizedString("custom", comment: ""):
            return "custom_\(customDays)"
        default:
            return nil
        }
    }
    
    private func saveChanges() {
        let updatedReminder = Reminder(
            id: reminder.id,
            title: title,
            date: selectedTime,
            isCompleted: reminder.isCompleted,
            description: description.isEmpty ? nil : description,
            type: selectedType,
            repeatPattern: getRepeatPattern()
        )
        
        // 先删除旧的提醒
        reminderManager.reminders.removeAll { $0.id == reminder.id }
        // 添加更新后的提醒
        reminderManager.addReminder(updatedReminder)
        
        dismiss()
    }

    private func deleteReminder() {
        // 使用数组过滤来删除提醒
        reminderManager.reminders.removeAll { $0.id == reminder.id }
        // 添加一个空的提醒并立即删除它来触发保存
        let tempReminder = Reminder(title: "", date: Date(), type: "")
        reminderManager.addReminder(tempReminder)
        reminderManager.reminders.removeAll { $0.id == tempReminder.id }
        
        dismiss()
    }
}

#Preview {
    ReminderSection(reminderManager: ReminderManager())
        .padding()
        .background(Color(.systemGray6))
}
