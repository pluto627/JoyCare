import SwiftUI

struct ReminderViewItem: View {
    let reminder: Reminder
    let allReminders: [Reminder]
    @ObservedObject var reminderManager: ReminderManager
    @State private var showingEditSheet = false
    @State private var showingDeleteAlert = false
    @Environment(\.colorScheme) private var colorScheme
    @EnvironmentObject private var languageManager: LanguageManager
    
    private func getTypeIcon(_ type: String) -> String {
        switch type {
        case NSLocalizedString("medication_reminder", comment: ""):
            return "pills"
        case NSLocalizedString("checkup_reminder", comment: ""):
            return "heart.text.square"
        case NSLocalizedString("medical_visit_reminder", comment: ""):
            return "cross.case"
        case NSLocalizedString("exercise_reminder", comment: ""):
            return "figure.walk"
        case NSLocalizedString("posture_reminder", comment: ""):
            return "figure.stand"
        case NSLocalizedString("diet_reminder", comment: ""):
            return "fork.knife"
        case NSLocalizedString("sleep_reminder", comment: ""):
            return "moon.zzz"
        case NSLocalizedString("water_reminder", comment: ""):
            return "drop"
        case NSLocalizedString("eye_protection_reminder", comment: ""):
            return "eye"
        case NSLocalizedString("oral_hygiene_reminder", comment: ""):
            return "mouth"
        case NSLocalizedString("skin_care_reminder", comment: ""):
            return "hand.raised"
        case NSLocalizedString("custom_reminder", comment: ""):
            return "plus"
        default:
            return "bell"
        }
    }
    
    private func getTypeColor(_ type: String) -> Color {
        switch type {
        case NSLocalizedString("medication_reminder", comment: ""):
            return .blue
        case NSLocalizedString("exercise_reminder", comment: ""):
            return .green
        case NSLocalizedString("water_reminder", comment: ""):
            return Color(hex: "00AEEF")
        case NSLocalizedString("sleep_reminder", comment: ""):
            return .indigo
        case NSLocalizedString("posture_reminder", comment: ""):
            return .orange
        case NSLocalizedString("eye_protection_reminder", comment: ""):
            return Color(hex: "5856D6")
        case NSLocalizedString("oral_hygiene_reminder", comment: ""):
            return .pink
        case NSLocalizedString("skin_care_reminder", comment: ""):
            return Color(hex: "8E8E93")
        case NSLocalizedString("medical_visit_reminder", comment: ""), 
             NSLocalizedString("checkup_reminder", comment: ""),
             NSLocalizedString("follow_up_reminder", comment: ""):
            return .red
        case NSLocalizedString("diet_reminder", comment: ""):
            return .orange
        case NSLocalizedString("custom_reminder", comment: ""):
            return .purple
        default:
            return .purple
        }
    }
    
    var body: some View {
        Button(action: {
            showingEditSheet = true
        }) {
            HStack(spacing: 16) {
                // 左侧图标和餐后标签
                VStack(spacing: 8) {
                    Image(systemName: getTypeIcon(reminder.type))
                        .foregroundColor(getTypeColor(reminder.type))
                        .font(.system(size: 24))
                    
                    // 餐后信息
                    if reminder.type == NSLocalizedString("medication_reminder", comment: ""), let mealTime = reminder.beforeOrAfterMeal {
                        Text(mealTime)
                            .font(.system(size: 12))
                            .foregroundColor(getTypeColor(reminder.type))
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(getTypeColor(reminder.type).opacity(0.1))
                            .cornerRadius(12)
                    }
                }
                .frame(width: 60)
                
                // 提醒内容
                VStack(alignment: .leading, spacing: 6) {
                    HStack(alignment: .top, spacing: 8) {
                        Text(reminder.title)
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(colorScheme == .dark ? .white : .black)
                            .fixedSize(horizontal: false, vertical: true)
                        
                        if let repeatPattern = reminder.repeatPattern {
                            HStack(spacing: 4) {
                                Image(systemName: "repeat")
                                    .font(.system(size: 12))
                                    .foregroundColor(.gray)
                                Text(getRepeatText(for: repeatPattern))
                                    .font(.system(size: 12))
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                    
                    if let description = reminder.description {
                        HStack(spacing: 8) {
                            Text(description)
                                .font(.system(size: 14))
                                .foregroundColor(.gray)
                            
                            if let mealTime = reminder.beforeOrAfterMeal {
                                Text("·")
                                    .foregroundColor(.gray)
                                Text(mealTime)
                                    .font(.system(size: 14))
                                    .foregroundColor(.gray)
                            }
                        }
                        .fixedSize(horizontal: false, vertical: true)
                        .multilineTextAlignment(.leading)
                    }
                }
                .padding(.vertical, 4)
                
                Spacer()
            }
            .padding(.vertical, 16)
            .padding(.horizontal, 20)
            .background(colorScheme == .dark ? Color.black.opacity(0.3) : Color(hex: "FAFAFA"))
            .cornerRadius(12)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(colorScheme == .dark ? Color.gray.opacity(0.3) : Color(hex: "E6E6E6"), lineWidth: 0.5)
            )
        }
        .contextMenu {
            Button(role: .destructive, action: {
                showingDeleteAlert = true
            }) {
                Label(NSLocalizedString("delete", comment: ""), systemImage: "trash")
            }
        }
        .alert(NSLocalizedString("confirm_delete", comment: ""), isPresented: $showingDeleteAlert) {
            Button(NSLocalizedString("cancel", comment: ""), role: .cancel) { }
            Button(NSLocalizedString("delete", comment: ""), role: .destructive) {
                deleteReminders()
            }
        } message: {
            Text(NSLocalizedString("delete_reminder_confirmation", comment: ""))
        }
        .sheet(isPresented: $showingEditSheet) {
            if reminder.type == NSLocalizedString("medication_reminder", comment: "") {
                MedicationDetailView(
                    reminderManager: reminderManager,
                    records: allReminders
                )
            } else {
                EditReminderView(reminder: reminder, reminderManager: reminderManager)
            }
        }
        .localized()
        .id(languageManager.refreshToken)
    }
    
    private func getRepeatText(for pattern: String) -> String {
        switch pattern {
        case "daily":
            return NSLocalizedString("daily", comment: "")
        case "alternate":
            return NSLocalizedString("alternate_days", comment: "")
        case let custom where custom.starts(with: "custom_"):
            let days = custom.split(separator: "_")[1]
            return String(format: NSLocalizedString("every_n_days", comment: ""), String(days))
        default:
            return ""
        }
    }
    
    private func formatTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        return formatter.string(from: date)
    }
    
    private var timeFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        return formatter
    }
    
    private func deleteReminders() {
        if reminder.type == NSLocalizedString("medication_reminder", comment: "") {
            for reminder in allReminders {
                reminderManager.reminders.removeAll { $0.id == reminder.id }
            }
        } else {
            reminderManager.reminders.removeAll { $0.id == reminder.id }
        }
        
        let tempReminder = Reminder(title: "", date: Date(), type: "")
        reminderManager.addReminder(tempReminder)
        reminderManager.reminders.removeAll { $0.id == tempReminder.id }
    }
} 
