import SwiftUI

struct DepartmentsView: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var searchText = ""
    @EnvironmentObject private var languageManager: LanguageManager
    
    // 示例科室数据
    let departments = [
        DepartmentGroup(name: NSLocalizedString("internal_medicine", comment: ""), departments: [
            Department(name: NSLocalizedString("respiratory", comment: ""), 
                      description: "Treatment of respiratory diseases"),
            Department(name: NSLocalizedString("digestive", comment: ""), 
                      description: "Treatment of digestive diseases"),
            Department(name: "Cardiovascular medicine", description: "Treating heart and blood vessel diseases"),
           
        ]),
        DepartmentGroup(name: "Surgery", departments: [
            Department(name: "General Surgery", description: "Performs common surgical procedures"),
            Department(name: "Orthopedics", description: "Treats bone and joint diseases"),
        ]),

        DepartmentGroup(name: "Specialties", departments: [
            Department(name: "Ophthalmology", description: "Treats eye diseases"),
            Department(name: "Otolaryngology", description: "Treats ear, nose, and throat diseases"),
        ])
    ]
    
    var filteredDepartments: [DepartmentGroup] {
        if searchText.isEmpty {
            return departments
        } else {
            return departments.map { group in
                DepartmentGroup(
                    name: group.name,
                    departments: group.departments.filter { $0.name.contains(searchText) }
                )
            }.filter { !$0.departments.isEmpty }
        }
    }
    
    var body: some View {
        NavigationView {
            VStack {
                // 搜索栏
                SearchBark(text: $searchText)
                    .padding()
                
                List {
                    ForEach(filteredDepartments) { group in
                        Section(header: Text(group.name).font(.headline)) {
                            ForEach(group.departments) { department in
                                VStack(alignment: .leading, spacing: 6) {
                                    Text(department.name)
                                        .font(.system(size: 17))
                                    
                                    Text(department.description)
                                        .font(.subheadline)
                                        .foregroundColor(.gray)
                                }
                                .padding(.vertical, 8)
                            }
                        }
                    }
                }
            }
            .navigationTitle(NSLocalizedString("departments", comment: ""))
            .navigationBarTitleDisplayMode(.inline)
            .searchable(text: $searchText, prompt: NSLocalizedString("search_department", comment: ""))
            .localized()
            .id(languageManager.refreshToken)
        }
    }
}

// 科室组数据模型
struct DepartmentGroup: Identifiable {
    let id = UUID()
    let name: String
    let departments: [Department]
}

// 科室数据模型
struct Department: Identifiable {
    let id = UUID()
    let name: String
    let description: String
}

// 搜索栏组件（与HospitalsView中相同）
struct SearchBark: View {
    @Binding var text: String
    
    var body: some View {
        HStack {
            Image(systemName: "magnifyingglass")
                .foregroundColor(.gray)
            
            TextField(NSLocalizedString("search_department", comment: ""), text: $text)
                .textFieldStyle(PlainTextFieldStyle())
            
            if !text.isEmpty {
                Button(action: {
                    text = ""
                }) {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundColor(.gray)
                }
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(Color(.systemGray6))
        .cornerRadius(10)
    }
}

#Preview {
    DepartmentsView()
}
