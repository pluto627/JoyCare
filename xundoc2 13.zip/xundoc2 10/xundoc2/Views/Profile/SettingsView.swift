import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var languageManager: LanguageManager
    @Environment(\.dismiss) private var dismiss
    @State private var showRestartAlert = false
    @State private var selectedLanguage: LanguageManager.Language
    
    init() {
        // 初始化时从UserDefaults读取当前语言设置
        let savedLanguage = UserDefaults.standard.string(forKey: "appLanguage") ?? "zh"
        _selectedLanguage = State(initialValue: LanguageManager.Language(rawValue: savedLanguage) ?? .chinese)
    }
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text(NSLocalizedString("language settings", comment: "语言设置"))) {
                    HStack {
                        Text(NSLocalizedString("current language", comment: "当前语言："))
                            .foregroundColor(.primary)
                        
                        Picker("", selection: $selectedLanguage) {
                            Text(NSLocalizedString("language_english", comment: "英文"))
                                .tag(LanguageManager.Language.english)
                            Text(NSLocalizedString("language_chinese", comment: "中文"))
                                .tag(LanguageManager.Language.chinese)
                        }
                        .pickerStyle(.menu)
                        .onChange(of: selectedLanguage) { oldValue, newValue in
                            if oldValue != newValue {
                                print("Language selection changed from \(oldValue) to \(newValue)")
                                
                                // 更新LanguageManager中的语言设置
                                languageManager.setLanguage(to: newValue)
                                
                                // 强制刷新本地化资源
                                LocalizationHelper.shared.forceRefreshLocalization()
                                
                                // 显示提示
                                showRestartAlert = true
                            }
                        }
                    }
                }
                
                Section(header: Text(NSLocalizedString("about_app", comment: "关于应用"))) {
                    HStack {
                        Text(NSLocalizedString("version", comment: "版本"))
                        Spacer()
                        Text("1.0")
                            .foregroundColor(.gray)
                    }
                }
            }
            .navigationTitle(NSLocalizedString("settings", comment: "设置"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(NSLocalizedString("close", comment: "关闭")) {
                        dismiss()
                    }
                }
            }
            .alert(NSLocalizedString("language_changed", comment: "语言已更改"), isPresented: $showRestartAlert) {
                Button(NSLocalizedString("ok", comment: "确定"), role: .cancel) { }
            } message: {
                Text(NSLocalizedString("language_change_message", comment: "语言设置已更改，部分更改可能需要重启应用后生效。"))
            }
            .onAppear {
                // 确保selectedLanguage与languageManager.currentLanguage保持同步
                selectedLanguage = languageManager.currentLanguage
                print("SettingsView appeared, current language: \(languageManager.currentLanguage.rawValue)")
            }
            .id(languageManager.refreshToken) // 这会在refreshToken变化时完全重建视图
            .localized() // 使用本地化修饰符
        }
    }
}

#Preview {
    SettingsView()
        .environmentObject(LanguageManager())
} 
