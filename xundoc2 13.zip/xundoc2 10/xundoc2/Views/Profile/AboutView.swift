import SwiftUI

struct AboutView: View {
    @EnvironmentObject private var languageManager: LanguageManager
    
    // 版本号和构建号
    private let appVersion = "1.0"
    private let buildNumber = "25"
    
    var body: some View {
        VStack(spacing: 0) {
            // 顶部导航栏
            HStack {
                Text(NSLocalizedString("about", comment: ""))
                    .font(.title2)
                    .padding()
                Spacer()
            }
            .background(Color(uiColor: .systemBackground))
            
            ScrollView {
                VStack(spacing: 15) {
                    // App Logo
                    VStack(spacing: 12) {
                        Image("Icon") // 替换为你的App图标资源名称
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 80, height: 80)
                            .padding(.top, 20)
                        
                        Text("JoyCare")
                            .font(.title)
                            .bold()
                        
                        Text("版本 \(appVersion)")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                            .padding(.bottom, 20)
                    }
                    .frame(maxWidth: .infinity)
                    .background(Color(uiColor: .systemBackground))
                    .cornerRadius(10)
                    .padding(.horizontal)
                    
                    // 介绍文本
                    VStack(spacing: 5) {
                        Text(NSLocalizedString("about_text", comment: ""))
                            .font(.system(size: 16))
                            .foregroundColor(.primary)
                            .multilineTextAlignment(.leading)
                            .padding(.vertical, 24)
                            .padding(.horizontal,24)
                        
                        Divider()
                            .padding(.horizontal)
                        
                        Text("plutoguoyq@gmail.com")
                            .font(.system(size: 16))
                            .foregroundColor(Color(hex: "9253f3"))
                            .padding(.vertical, 16)
                    }
                    .frame(maxWidth: .infinity)
                    .background(Color(uiColor: .systemBackground))
                    .cornerRadius(10)
                    .padding(.horizontal)
                    
                    // 版权信息
                    VStack(spacing: 4) {
                        Text(NSLocalizedString("made_with_love", comment: ""))
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                    .padding(.vertical, 30)
                }
                .padding(.top, 12)
            }
            .background(Color(.systemGray6))
        }
        .navigationTitle(NSLocalizedString("about", comment: ""))
        .localized()
        .id(languageManager.refreshToken)
    }
}

#Preview {
    AboutView()
}
