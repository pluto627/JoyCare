import SwiftUI
import MapKit

struct AddHospitalView: View {
    @Environment(\.presentationMode) var presentationMode
    let onAdd: (String, String) -> Void
    
    @State private var hospitalName = ""
    @State private var hospitalAddress = ""
    @State private var searchResults: [MKMapItem] = []
    @State private var isSearching = false
    @State private var selectedLocation: MKMapItem?
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text(NSLocalizedString("hospital_info", comment: ""))) {
                    TextField(NSLocalizedString("hospital_name", comment: ""), text: $hospitalName)
                        .onChange(of: hospitalName) { newValue in
                            if !newValue.isEmpty {
                                searchHospital(query: newValue)
                            } else {
                                searchResults = []
                            }
                        }
                    
                    if !searchResults.isEmpty {
                        ForEach(searchResults, id: \.self) { item in
                            VStack(alignment: .leading) {
                                Text(item.name ?? "")
                                    .font(.headline)
                                Text(item.placemark.formattedAddress ?? "")
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                            }
                            .onTapGesture {
                                selectedLocation = item
                                hospitalName = item.name ?? ""
                                hospitalAddress = item.placemark.formattedAddress ?? ""
                                searchResults = []
                            }
                        }
                    }
                    
                    TextField(NSLocalizedString("hospital_address", comment: ""), text: $hospitalAddress)
                }
            }
            .navigationTitle("添加医院")
            .navigationBarItems(
                leading: Button(NSLocalizedString("cancel", comment: "")) {
                    presentationMode.wrappedValue.dismiss()
                },
                trailing: Button(NSLocalizedString("save", comment: "")) {
                    if let location = selectedLocation {
                        onAdd(hospitalName, hospitalAddress)
                    }
                    presentationMode.wrappedValue.dismiss()
                }
                .disabled(hospitalName.isEmpty || hospitalAddress.isEmpty)
            )
        }
    }
    
    private func searchHospital(query: String) {
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = query + " 医院"
        request.region = MKCoordinateRegion(
            center: CLLocationManager().location?.coordinate ?? CLLocationCoordinate2D(latitude: 39.9042, longitude: 116.4074),
            span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
        )
        
        let search = MKLocalSearch(request: request)
        search.start { response, error in
            guard let response = response else {
                print("Error: \(error?.localizedDescription ?? "Unknown error")")
                return
            }
            
            DispatchQueue.main.async {
                self.searchResults = response.mapItems
            }
        }
    }
}

extension MKPlacemark {
    var formattedAddress: String? {
        var components = [String]()
        
        if let city = locality {
            components.append(city)
        }
        if let subLocality = subLocality {
            components.append(subLocality)
        }
        if let thoroughfare = thoroughfare {
            components.append(thoroughfare)
        }
        if let subThoroughfare = subThoroughfare {
            components.append(subThoroughfare)
        }
        
        return components.joined(separator: "")
    }
} 