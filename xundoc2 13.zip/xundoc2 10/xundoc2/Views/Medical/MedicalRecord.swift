import SwiftUI
import UIKit

// ShareSheet 包装器
struct ShareSheet: UIViewControllerRepresentable {
    let activityItems: [Any]
    
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
    }
    
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

// 数据模型

// 修改后的主视图
struct MedicalMainView: View {
    @State private var showingMedicalRecord = false
    @State private var medicalRecords: [MedicalRecord] = []
    @State private var refreshFlag = false // 添加刷新标记
    @EnvironmentObject private var languageManager: LanguageManager
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 16) {
                    Text(NSLocalizedString("medical_records", comment: ""))
                        .font(.system(size: 34))
                        .fontWeight(.bold)
                        .padding(.top, 20)
                        .padding(.horizontal)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    
                    // 就诊记录列表
                    if medicalRecords.isEmpty {
                        VStack(spacing: 20) {
                            Image(systemName: "doc.text.magnifyingglass")
                                .font(.system(size: 60))
                                .foregroundColor(.gray)
                                .padding(.top, 50)
                            
                            Text("没有就诊记录")
                                .font(.headline)
                                .foregroundColor(.gray)
                            
                            Text("点击右上角"+"添加新的就诊记录")
                                .font(.subheadline)
                                .foregroundColor(.gray)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal, 20)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 50)
                    } else {
                        ForEach(medicalRecords.sorted(by: { $0.date > $1.date })) { record in
                            MedicalRecordCard(record: record, medicalRecords: $medicalRecords)
                                .padding(.horizontal)
                        }
                    }
                }
            }
            .id(refreshFlag) // 添加ID以强制整个视图刷新
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        showingMedicalRecord = true
                    }) {
                        HStack(spacing: 6) {
                            Image(systemName: "plus")
                            Text(NSLocalizedString("add_new", comment: ""))
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 10)
                        .background(Color.purple)
                        .foregroundColor(.white)
                        .cornerRadius(16)
                    }
                }
            }
            .sheet(isPresented: $showingMedicalRecord) {
                AddMedicalRecordView(medicalRecords: $medicalRecords)
                    .presentationDetents([.medium])
                    .presentationDragIndicator(.visible)
                    .onDisappear {
                        // 确保Sheet关闭后重新加载数据
                        loadMedicalRecords()
                    }
            }
            .localized()
            .id(languageManager.refreshToken)
        }
        .navigationViewStyle(StackNavigationViewStyle()) // 添加导航视图样式
        .onAppear {
            loadMedicalRecords()
            // 触发刷新
            refreshFlag.toggle()
        }
    }
    
    private func loadMedicalRecords() {
        // 直接从本地存储加载记录
        self.medicalRecords = MedicalRecordStorage.shared.loadRecords()
    }
}

// 记录卡片视图
struct MedicalRecordCard: View {
    let record: MedicalRecord
    @Binding var medicalRecords: [MedicalRecord]
    @State private var showingDeleteAlert = false
    @State private var showingSharePDF = false
    @State private var navigateToDetail = false
    @Environment(\.colorScheme) private var colorScheme
    @EnvironmentObject private var languageManager: LanguageManager
    
    var body: some View {
        cardContent
            .padding()
            .background(backgroundShape)
            .overlay(borderShape)
            .sheet(isPresented: $showingSharePDF) {
                ShareSheet(activityItems: [generatePDF()])
            }
            .background(navigationLink)
            .onTapGesture {
                navigateToDetail = true
            }
            .onAppear(perform: loadUpdatedRecord)
            .alert(NSLocalizedString("confirm_delete_record", comment: ""), isPresented: $showingDeleteAlert) {
                Button(NSLocalizedString("cancel", comment: ""), role: .cancel) { }
                Button(NSLocalizedString("delete", comment: ""), role: .destructive) {
                    deleteRecord()
                }
            } message: {
                Text(NSLocalizedString("delete_record_message", comment: ""))
            }
            .localized()
    }
    
    // 卡片内容
    private var cardContent: some View {
        VStack(alignment: .leading, spacing: 10) {
            cardHeader
            
            Text(record.symptoms)
                .font(.body)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.leading)
                .lineLimit(3)
                .frame(maxWidth: .infinity, alignment: .leading)
            
            if !record.hospitalAddress.isEmpty {
                addressView
            }
        }
    }
    
    // 卡片头部
    private var cardHeader: some View {
        HStack {
            hospitalInfoView
            
            Spacer()
            
            menuButton
        }
    }
    
    // 医院信息视图
    private var hospitalInfoView: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(record.hospital)
                .font(.headline)
                .foregroundColor(.primary)
            
            HStack {
                departmentView
                dateView
            }
        }
    }
    
    // 科室视图
    private var departmentView: some View {
        Text(record.department)
            .font(.subheadline)
            .foregroundColor(Color(red: 0.44, green: 0.36, blue: 0.98))
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
            .background(Color(red: 0.44, green: 0.36, blue: 0.98).opacity(0.1))
            .cornerRadius(4)
    }
    
    // 日期视图
    private var dateView: some View {
        Text(formatDate(record.date))
            .font(.caption)
            .foregroundColor(.secondary)
    }
    
    // 地址视图
    private var addressView: some View {
        HStack {
            Image(systemName: "mappin.circle.fill")
                .foregroundColor(.red)
            
            Text(record.hospitalAddress)
                .font(.caption)
                .foregroundColor(.secondary)
                .lineLimit(1)
        }
    }
    
    // 菜单按钮
    private var menuButton: some View {
        Menu {
            Button(action: {
                navigateToDetail = true
            }) {
                Label(NSLocalizedString("view_details", comment: ""), systemImage: "doc.text.magnifyingglass")
            }
            
            Button(action: {
                showingSharePDF = true
            }) {
                Label(NSLocalizedString("share", comment: ""), systemImage: "square.and.arrow.up")
            }
            
            Button(role: .destructive, action: {
                showingDeleteAlert = true
            }) {
                Label(NSLocalizedString("delete", comment: ""), systemImage: "trash")
            }
        } label: {
            Image(systemName: "ellipsis.circle")
                .font(.title3)
                .foregroundColor(.secondary)
        }
    }
    
    // 背景形状
    private var backgroundShape: some View {
        RoundedRectangle(cornerRadius: 12)
            .fill(colorScheme == .dark ? Color.black.opacity(0.3) : Color.white.opacity(0.05))
            .shadow(color: colorScheme == .dark ? Color.clear : Color.black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
    
    // 边框形状
    private var borderShape: some View {
        RoundedRectangle(cornerRadius: 12)
            .stroke(colorScheme == .dark ? Color.gray.opacity(0.3) : Color.gray.opacity(0.2), lineWidth: 1)
    }
    
    // 导航链接
    private var navigationLink: some View {
        NavigationLink(
            destination: MedicalRecordDetailView(record: record),
            isActive: $navigateToDetail,
            label: { EmptyView() }
        )
    }
    
    // 加载更新的记录
    private func loadUpdatedRecord() {
        let records = MedicalRecordStorage.shared.loadRecords()
        if let updatedRecord = records.first(where: { $0.id == record.id }),
           let index = medicalRecords.firstIndex(where: { $0.id == record.id }) {
            medicalRecords[index] = updatedRecord
        }
    }
    
    // 格式化日期
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        return formatter.string(from: date)
    }
    
    // 删除记录
    private func deleteRecord() {
        // 从本地数组移除
        if let index = medicalRecords.firstIndex(where: { $0.id == record.id }) {
            medicalRecords.remove(at: index)
            
            // 保存到本地存储
            MedicalRecordStorage.shared.saveRecords(medicalRecords)
        }
    }
    
    // 生成PDF
    private func generatePDF() -> Data {
        let renderer = UIGraphicsPDFRenderer(bounds: CGRect(x: 0, y: 0, width: 595, height: 842))
        
        let data = renderer.pdfData { context in
            context.beginPage()
            
            let titleAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.boldSystemFont(ofSize: 24)
            ]
            
            let normalAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 14)
            ]
            
            // 标题
            "医疗记录".draw(at: CGPoint(x: 50, y: 50), withAttributes: titleAttributes)
            
            // 医院和科室
            "医院: \(record.hospital)".draw(at: CGPoint(x: 50, y: 100), withAttributes: normalAttributes)
            "科室: \(record.department)".draw(at: CGPoint(x: 50, y: 120), withAttributes: normalAttributes)
            
            // 日期
            let dateFormatter = DateFormatter()
            dateFormatter.dateStyle = .long
            "就诊日期: \(dateFormatter.string(from: record.date))".draw(at: CGPoint(x: 50, y: 140), withAttributes: normalAttributes)
            
            // 地址
            "医院地址: \(record.hospitalAddress)".draw(at: CGPoint(x: 50, y: 160), withAttributes: normalAttributes)
            
            // 症状
            "症状描述:".draw(at: CGPoint(x: 50, y: 200), withAttributes: normalAttributes)
            
            let symptomsParagraphStyle = NSMutableParagraphStyle()
            symptomsParagraphStyle.lineBreakMode = .byWordWrapping
            
            let symptomsAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 14),
                .paragraphStyle: symptomsParagraphStyle
            ]
            
            let symptomsRect = CGRect(x: 50, y: 220, width: 500, height: 300)
            record.symptoms.draw(in: symptomsRect, withAttributes: symptomsAttributes)
        }
        
        return data
    }
}

// 如果您的项目中还没有 Color hex 扩展，需要添加以下扩展：

// Preview Provider
struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        MedicalMainView()
    }
}

public struct MedicalRecord: Identifiable, Codable {
    public let id: UUID
    public let date: Date
    public let hospital: String
    public let department: String
    public let symptoms: String
    public let hospitalAddress: String
    public let medicationTimes: [String] // 新增用药时间数组
    public let dailyDoses: Int // 新增每日服用次数
    
    public init(id: UUID = UUID(), 
               date: Date, 
               hospital: String, 
               department: String, 
               symptoms: String, 
               hospitalAddress: String,
               medicationTimes: [String] = ["08:00", "12:00", "20:00", "22:00"],
               dailyDoses: Int = 4) {
        self.id = id
        self.date = date
        self.hospital = hospital
        self.department = department
        self.symptoms = symptoms
        self.hospitalAddress = hospitalAddress
        self.medicationTimes = medicationTimes
        self.dailyDoses = dailyDoses
    }
} 
