import SwiftUI
import PhotosUI
import Vision

struct DoctorOrdersView: View {
    let recordId: UUID
    let onSave: (DoctorOrder) -> Void
    @EnvironmentObject private var languageManager: LanguageManager
    
    @State private var orderContent: String = ""
    @Environment(\.dismiss) private var dismiss
    @State private var orderDate = Date()
    @State private var showAlert = false
    @State private var selectedItem: PhotosPickerItem?
    @State private var selectedImageData: Data?
    @State private var isProcessingImage = false
    @State private var showingFullScreenImage = false
    @State private var showingImageOptions = false
    
    var body: some View {
        NavigationView {
            Form {
                // 添加图片选择器
                if let selectedImageData,
                   let uiImage = UIImage(data: selectedImageData) {
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            Text(NSLocalizedString("order_photo", comment: ""))
                                .foregroundColor(.gray)
                            Spacer()
                            PhotosPicker(selection: $selectedItem,
                                       matching: .images,
                                       photoLibrary: .shared()) {
                                Text(NSLocalizedString("change_photo", comment: ""))
                                    .foregroundColor(.blue)
                            }
                        }
                        
                        // 缩略图显示
                        Image(uiImage: uiImage)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 100, height: 100)
                            .clipShape(RoundedRectangle(cornerRadius: 8))
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(Color.gray.opacity(0.2), lineWidth: 1)
                            )
                            .onTapGesture {
                                showingImageOptions = true
                            }
                    }
                } else {
                    PhotosPicker(selection: $selectedItem,
                               matching: .images,
                               photoLibrary: .shared()) {
                        HStack {
                            Image(systemName: "photo")
                            Text(NSLocalizedString("add_order_photo", comment: ""))
                        }
                    }
                }
                
                if isProcessingImage {
                    ProgressView(NSLocalizedString("processing_text", comment: ""))
                }

                Section(header: Text(NSLocalizedString("order_content", comment: ""))) {
                    TextEditor(text: $orderContent)
                        .frame(height: 100)
                }
            }
            .navigationTitle(NSLocalizedString("add_doctor_order", comment: ""))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(NSLocalizedString("cancel", comment: "")) {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(NSLocalizedString("save", comment: "")) {
                        let newOrder = DoctorOrder(
                            recordId: recordId,
                            content: orderContent,
                            imageData: selectedImageData,
                            diagnosis: "",
                            recommendations: "",
                            symptoms: ""
                        )
                        onSave(newOrder)
                        showAlert = true
                    }
                    .disabled(orderContent.isEmpty)
                }
            }
            .alert(isPresented: $showAlert) {
                Alert(
                    title: Text(NSLocalizedString("save_success", comment: "")),
                    message: Text(""),
                    dismissButton: .default(Text(NSLocalizedString("ok", comment: ""))) {
                        dismiss()
                    }
                )
            }
            .confirmationDialog(NSLocalizedString("photo_actions", comment: ""), isPresented: $showingImageOptions) {
                Button(NSLocalizedString("view_full_image", comment: "")) {
                    showingFullScreenImage = true
                }
                Button(NSLocalizedString("change_photo", comment: "")) {
                    selectedItem = nil
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        showingImageOptions = false
                    }
                }
                Button(NSLocalizedString("delete_photo", comment: ""), role: .destructive) {
                    selectedImageData = nil
                    selectedItem = nil
                }
                Button(NSLocalizedString("cancel", comment: ""), role: .cancel) {}
            }
            .fullScreenCover(isPresented: $showingFullScreenImage) {
                if let selectedImageData,
                   let uiImage = UIImage(data: selectedImageData) {
                    ZStack {
                        Color.black.ignoresSafeArea()
                        
                        Image(uiImage: uiImage)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                        
                        // 关闭按钮
                        VStack {
                            HStack {
                                Spacer()
                                Button(action: {
                                    showingFullScreenImage = false
                                }) {
                                    Image(systemName: "xmark.circle.fill")
                                        .font(.title)
                                        .foregroundColor(.white)
                                        .padding()
                                }
                            }
                            Spacer()
                        }
                    }
                    .statusBar(hidden: true)
                }
            }
            .onChange(of: selectedItem) { newItem in
                Task {
                    if let data = try? await newItem?.loadTransferable(type: Data.self) {
                        selectedImageData = data
                        await performOCR()
                    }
                }
            }
        }
        .id(languageManager.refreshToken)
    }
    
    private func performOCR() async {
        guard let imageData = selectedImageData,
              let uiImage = UIImage(data: imageData),
              let cgImage = uiImage.cgImage else { return }
        
        await MainActor.run { isProcessingImage = true }
        
        let requestHandler = VNImageRequestHandler(cgImage: cgImage)
        let request = VNRecognizeTextRequest { request, error in
            guard let observations = request.results as? [VNRecognizedTextObservation],
                  error == nil else { return }
            
            let recognizedText = observations.compactMap { observation in
                observation.topCandidates(1).first?.string
            }.joined(separator: "\n")
            
            // 定义可能的诊断关键词模式
            let patterns = [
                "诊断[：:](.*?)(?=\\n|$)",
                "初步诊断[：:](.*?)(?=\\n|$)",
                "临床诊断[：:](.*?)(?=\\n|$)",
                "确定诊断[：:](.*?)(?=\\n|$)",
                "诊断结果[：:](.*?)(?=\\n|$)"
            ]
            
            for pattern in patterns {
                if let regex = try? NSRegularExpression(pattern: pattern, options: []),
                   let match = regex.firstMatch(
                    in: recognizedText,
                    options: [],
                    range: NSRange(location: 0, length: recognizedText.count)
                   ),
                   let range = Range(match.range(at: 1), in: recognizedText) {
                    
                    let diagnosisText = String(recognizedText[range]).trimmingCharacters(in: .whitespaces)
                    
                    // 在主线程更新 UI
                    Task { @MainActor in
                        orderContent = diagnosisText
                        isProcessingImage = false
                    }
                    return
                }
            }
            
            // 如果没有找到诊断相关内容，则显示完整文本
            Task { @MainActor in
                orderContent = recognizedText
                isProcessingImage = false
            }
        }
        
        // 设置识别语言为中文
        request.recognitionLanguages = ["zh-Hans", "zh-Hant"]
        // 设置识别级别为精确
        request.recognitionLevel = .accurate
        
        do {
            try requestHandler.perform([request])
        } catch {
            print("OCR 识别错误: \(error)")
            await MainActor.run { isProcessingImage = false }
        }
    }
}

#Preview {
    DoctorOrdersView(recordId: UUID(), onSave: { _ in })
}

