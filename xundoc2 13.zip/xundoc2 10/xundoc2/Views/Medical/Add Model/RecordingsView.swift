import SwiftUI
import Speech
import CoreML
import AVFoundation
import Foundation

// 使用相同的 ConversationSegment 定义
// 直接引用 ConversationSegment 结构体，不需要额外导入

struct RecordingsView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var audioRecorder = AudioRecorder()
    @State private var showAlert = false
    @State private var alertMessage = ""
    @State private var recordingName = ""
    let recordId: UUID
    var onSave: ((Recording) -> Void)?
    @EnvironmentObject private var languageManager: LanguageManager
    
    @State private var recordings: [RecordingListItem] = []
    @State private var isPaused = false
    @State private var currentTime: String = "00:00:00"
    @State private var isAnimating = false
    
    var body: some View {
        VStack(spacing: 0) {
            // 顶部导航栏
            HStack {
                Text(NSLocalizedString("add_recording", comment: ""))
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundColor(Color(UIColor(red: 0.4, green: 0.6, blue: 0.9, alpha: 1.0)))
                
                Spacer()
                
                Text(currentTime)
                    .font(.title3)
                    .foregroundColor(.gray)
            }
            .padding()
            .background(Color.white)
            
            Divider()
            
            ScrollView {
                VStack(spacing: 0) {
                    // 录音状态视图
                    if audioRecorder.isRecording || isPaused {
                        VStack(spacing: 10) {
                            // 录音状态文本
                            Text(isPaused ? "录音已暂停" : "正在录音中")
                                .font(.headline)
                                .foregroundColor(isPaused ? .orange : .primary)
                                .padding(.top)
                            
                            // 新的波形视图
                            ZStack {
                                RoundedRectangle(cornerRadius: 16)
                                    .fill(Color(.systemGray6))
                                    .frame(height: 160)
                                
                                VStack {
                                    // 使用新的AudioWaveformView
                                    AudioWaveformView(
                                        audioLevel: audioRecorder.currentAudioLevel,
                                        isPaused: isPaused
                                    )
                                    .padding(.horizontal)
                                }
                            }
                            .padding(.horizontal)
                        }
                        .padding(.bottom, 10)
                    }
                    
                    // 对话内容
                    if !audioRecorder.transcribedText.isEmpty {
                        ForEach(audioRecorder.transcribedText.indices, id: \.self) { index in
                            let segment = audioRecorder.transcribedText[index]
                            RecordingConversationBubbleView(segment: segment)
                                .padding(.horizontal)
                                .padding(.vertical, 2)
                        }
                        .padding(.bottom, 80)
                    }
                }
            }
            
            Spacer()
            
            // 底部控制按钮
            HStack(spacing: 30) {
                // 音量按钮
                Button(action: {
                    // 音量控制逻辑
                }) {
                    Image(systemName: "speaker.wave.2.fill")
                        .font(.system(size: 24))
                        .foregroundColor(.gray)
                        .frame(width: 50, height: 50)
                        .background(Color(.systemGray6))
                        .clipShape(Circle())
                }
                
                // 录音/暂停按钮
                Button(action: {
                    if audioRecorder.isRecording {
                        if isPaused {
                            audioRecorder.resumeRecording()
                            isPaused = false
                        } else {
                            audioRecorder.pauseRecording()
                            isPaused = true
                        }
                    } else {
                        startRecording()
                    }
                }) {
                    Image(systemName: audioRecorder.isRecording ? (isPaused ? "mic.fill" : "pause.fill") : "mic.fill")
                        .font(.system(size: 30))
                        .foregroundColor(.white)
                        .frame(width: 70, height: 70)
                        .background(Color.blue)
                        .clipShape(Circle())
                }
                
                // 保存按钮 (原来的停止按钮)
                Button(action: {
                    if audioRecorder.isRecording {
                        stopRecordingAndSave()
                    } else {
                        // 如果没有录音，显示提示
                        showSaveAlert()
                    }
                }) {
                    Image(systemName: "square.and.arrow.down.fill")
                        .font(.system(size: 24))
                        .foregroundColor(.gray)
                        .frame(width: 50, height: 50)
                        .background(Color(.systemGray6))
                        .clipShape(Circle())
                }
            }
            .padding(.bottom, 30)
            .background(Color.white)
        }
        .onAppear {
            requestPermissions()
            startTimer()
            
            // 如果正在录音，启动动画
            if audioRecorder.isRecording && !isPaused {
                isAnimating = true
            }
        }
        .onDisappear {
            stopTimer()
        }
        .alert(isPresented: $showAlert) {
            Alert(
                title: Text(NSLocalizedString("recording_saved", comment: "")),
                message: Text(alertMessage),
                dismissButton: .default(Text(NSLocalizedString("ok", comment: ""))) {
                    dismiss()
                }
            )
        }
        .localized()
        .id(languageManager.refreshToken)
    }
    
    @State private var timer: Timer?
    @State private var elapsedTime: TimeInterval = 0
    
    private func startTimer() {
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
            if audioRecorder.isRecording && !isPaused {
                elapsedTime += 1
                updateTimeDisplay()
            }
        }
    }
    
    private func stopTimer() {
        timer?.invalidate()
        timer = nil
    }
    
    private func updateTimeDisplay() {
        let hours = Int(elapsedTime) / 3600
        let minutes = (Int(elapsedTime) % 3600) / 60
        let seconds = Int(elapsedTime) % 60
        
        currentTime = String(format: "%02d:%02d:%02d", hours, minutes, seconds)
    }
    
    private func resetTimer() {
        elapsedTime = 0
        updateTimeDisplay()
    }
    
    private func startRecording() {
        audioRecorder.startRecording()
        isPaused = false
        isAnimating = true
        resetTimer()
        startTimer()
    }
    
    private func stopRecordingAndSave() {
        guard let audioURL = audioRecorder.stopRecording() else { return }
        saveRecording(from: audioURL)
        isAnimating = false
        stopTimer()
        resetTimer()
    }
    
    private func showSaveAlert() {
        let alert = UIAlertController(title: "保存录音", message: "请先开始录音才能保存", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "确定", style: .default))
        
        // 获取当前视图控制器并显示警告
        if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
           let rootViewController = windowScene.windows.first?.rootViewController {
            rootViewController.present(alert, animated: true)
        }
    }
    
    private func saveRecording(from audioURL: URL) {
        // 创建一个唯一的文件名 - 使用m4a格式
        let fileName = recordingName.isEmpty ? "录音_\(Date().timeIntervalSince1970).m4a" : "\(recordingName).m4a"
        let permanentURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent(fileName)
        
        do {
            // 配置音频会话
            let audioSession = AVAudioSession.sharedInstance()
            try audioSession.setCategory(.playAndRecord, 
                                       mode: .default,
                                       options: [.defaultToSpeaker, .allowBluetooth])
            
            // 如果目标文件已存在则删除
            if FileManager.default.fileExists(atPath: permanentURL.path) {
                try FileManager.default.removeItem(at: permanentURL)
            }
            
            // 复制临时录音文件到永久位置
            try FileManager.default.copyItem(at: audioURL, to: permanentURL)
            print("录音已保存到: \(permanentURL.path)")
            
            // 创建Recording对象
            let recording = Recording(
                id: UUID(),
                recordId: recordId,
                name: recordingName.isEmpty ? "就诊录音" : recordingName,
                date: Date(),
                audioURL: permanentURL,
                conversation: audioRecorder.transcribedText
            )
            
            // 保存到本地存储
            var savedRecordings = RecordingStorage.shared.loadRecordings()
            if !savedRecordings.contains(where: { $0.id == recording.id }) {
                savedRecordings.append(recording)
                RecordingStorage.shared.saveRecordings(savedRecordings)
            }
            
            // 创建RecordingListItem添加到列表
            let newRecording = RecordingListItem(
                url: permanentURL,
                createdAt: Date(),
                duration: elapsedTime
            )
            
            DispatchQueue.main.async {
                recordings.append(newRecording)
                onSave?(recording)
                
                // 显示保存成功提示
                alertMessage = "录音已成功保存！"
                showAlert = true
            }
            
        } catch {
            print("保存录音失败: \(error.localizedDescription)")
            
            DispatchQueue.main.async {
                alertMessage = "保存录音失败: \(error.localizedDescription)"
                showAlert = true
            }
        }
    }
    
    private func requestPermissions() {
        // 请求语音识别权限
        SFSpeechRecognizer.requestAuthorization { status in
            DispatchQueue.main.async {
                var message = ""
                switch status {
                case .authorized:
                    message = "语音识别权限已授权"
                case .denied:
                    message = "用户拒绝了语音识别权限"
                case .restricted:
                    message = "语音识别在此设备上受到限制"
                case .notDetermined:
                    message = "语音识别权限未确定"
                @unknown default:
                    message = "未知的语音识别权限状态"
                }
                print("语音识别权限状态: \(message)")
            }
        }
        
        // 请求录音权限
        AVAudioSession.sharedInstance().requestRecordPermission { granted in
            DispatchQueue.main.async {
                print("录音权限\(granted ? "已授权" : "被拒绝")")
            }
        }
    }
}

// 对话气泡视图 - 重命名以避免冲突
struct RecordingConversationBubbleView: View {
    let segment: ConversationSegment
    
    var body: some View {
        HStack(alignment: .top) {
            // 如果是医生，显示在左侧
            if segment.speaker == "医生" {
                // 头像
                Image(systemName: "person.circle.fill")
                    .font(.system(size: 36))
                    .foregroundColor(.blue)
                
                VStack(alignment: .leading, spacing: 2) {
                    // 说话者和时间
                    HStack {
                        Text(segment.speaker)
                            .font(.subheadline)
                            .foregroundColor(.gray)
                        
                        // 格式化时间为 HH:mm
                        Text(formatTime(segment.timestamp))
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                    
                    // 对话内容
                    Text(segment.content)
                        .padding(8)
                        .background(Color(.systemGray6))
                        .cornerRadius(10)
                }
                
                Spacer()
            } else {
                // 如果是患者，显示在右侧
                Spacer()
                
                VStack(alignment: .trailing, spacing: 2) {
                    // 说话者和时间
                    HStack {
                        // 格式化时间为 HH:mm
                        Text(formatTime(segment.timestamp))
                            .font(.caption)
                            .foregroundColor(.gray)
                        
                        Text(segment.speaker)
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }
                    
                    // 对话内容
                    Text(segment.content)
                        .padding(8)
                        .background(Color(UIColor(red: 0.9, green: 1.0, blue: 0.9, alpha: 1.0)))
                        .cornerRadius(10)
                }
                
                // 头像
                Image(systemName: "person.circle.fill")
                    .font(.system(size: 36))
                    .foregroundColor(.green)
            }
        }
        .padding(.vertical, 3)
    }
    
    // 格式化时间为 HH:mm
    private func formatTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        return formatter.string(from: date)
    }
}

// 录音列表项
struct RecordingListItem: Identifiable {
    let id = UUID()
    let url: URL
    let createdAt: Date
    let duration: Double
}

class AudioRecorder: ObservableObject {
    @Published var isRecording = false
    @Published var transcribedText: [ConversationSegment] = []
    @Published var currentAudioLevel: CGFloat = 0.0 // 当前音频音量级别，范围0.0-1.0
    
    // 音量监测相关
    private var audioLevelTimer: Timer?
    private let audioLevelUpdateInterval: TimeInterval = 0.05 // 更新频率，50毫秒
    
    private var audioEngine = AVAudioEngine()
    private var audioFile: AVAudioFile?
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private var speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "zh-CN"))
    private var lastSpeechTime = Date()
    private var lastTranscription = ""
    private var currentSpeaker = "患者"
    private var recordingURL: URL?
    private var lastParsedSentence = "" // 记录上一次已处理的句子，避免重复
    
    // 扩展医生关键词列表
    private let doctorKeywords = ["请问", "症状", "治疗", "检查", "诊断", "建议", "药物", "用量", "副作用", "定期复查", "注意事项", "医嘱", "处方", "病情", "医生建议", "医生说", "需要", "应该", "考虑", "建议您", "建议你", "我建议", "医生", "用药", "服用", "治疗方案", "手术", "复诊", "随访"]
    
    // 扩展患者关键词列表
    private let patientKeywords = ["疼痛", "不舒服", "感觉", "我感觉", "我的", "我有", "想问", "咨询", "谢谢医生", "吃药", "按时", "好的", "明白", "遵医嘱", "我", "我们", "我是", "谢谢", "难受", "头痛", "咳嗽", "发烧", "我想", "患者", "家属", "疼", "痛", "家里", "孩子", "父母"]
    
    private var currentSegment: String = ""
    private var processingTimer: Timer?
    private var sentenceQueue: [String] = [] // 句子队列，用于存储待处理的句子
    
    // 用于暂停和继续录音
    private var isPaused = false
    private var audioBuffer = [AVAudioPCMBuffer]()
    
    // 添加一个标志来控制是否使用语音识别
    private var useVoiceRecognition = false
    
    // 添加AVAudioRecorder实例
    private var avAudioRecorder: AVAudioRecorder?
    
    private func getDocumentsDirectory() -> URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }
    
    func startRecording() {
        // 检查语音识别器是否可用
        if let recognizer = speechRecognizer, recognizer.isAvailable {
            useVoiceRecognition = true
        } else {
            useVoiceRecognition = false
            print("语音识别不可用，将只进行录音而不进行转写")
        }
        
        // 创建新的录音文件URL - 使用m4a格式
        let fileName = "\(Date().timeIntervalSince1970).m4a"
        recordingURL = getDocumentsDirectory().appendingPathComponent(fileName)
        
        do {
            let audioSession = AVAudioSession.sharedInstance()
            try audioSession.setCategory(.playAndRecord, 
                                       mode: .default,
                                       options: [.defaultToSpeaker, .allowBluetooth])
            try audioSession.setActive(true)
            
            // 使用系统原生的AVAudioRecorder进行录音
            guard let recordingURL = recordingURL else { return }
            print("开始录音到文件: \(recordingURL.path)")
            
            // 设置录音参数
            let settings: [String: Any] = [
                AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
                AVSampleRateKey: 44100.0,
                AVNumberOfChannelsKey: 1,
                AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue,
                AVEncoderBitRateKey: 128000,
                AVEncoderBitDepthHintKey: 16,
                AVLinearPCMIsFloatKey: false
            ]
            
            // 创建AVAudioRecorder实例
            avAudioRecorder = try AVAudioRecorder(url: recordingURL, settings: settings)
            avAudioRecorder?.prepareToRecord()
            avAudioRecorder?.isMeteringEnabled = true // 启用音量测量
            
            // 开始录音
            if avAudioRecorder?.record() == true {
                isRecording = true
                isPaused = false
                print("AVAudioRecorder开始录音")
                
                // 启动音量监测
                startAudioLevelMonitoring()
                
                // 如果启用了语音识别，设置语音识别
                if useVoiceRecognition {
                    setupSpeechRecognition()
                } else {
                    // 如果没有语音识别，添加一个默认的对话段落
                    DispatchQueue.main.async {
                        let segment = ConversationSegment(
                            speaker: self.currentSpeaker,
                            content: "录音中...(语音识别不可用)",
                            timestamp: Date(),
                            audioURL: self.recordingURL
                        )
                        self.transcribedText.append(segment)
                    }
                }
            } else {
                print("AVAudioRecorder启动失败")
            }
            
        } catch {
            print("录音初始化失败: \(error.localizedDescription)")
        }
    }
    
    private func setupSpeechRecognition() {
        guard let recognizer = speechRecognizer, recognizer.isAvailable else {
            print("语音识别不可用")
            return
        }
        
        // 启动音频引擎进行语音识别
        audioEngine = AVAudioEngine()
        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        guard let recognitionRequest = recognitionRequest else { return }
        
        recognitionRequest.shouldReportPartialResults = true
        // 启用持续识别
        recognitionRequest.taskHint = .dictation
        
        // 添加错误处理和重试逻辑
        var retryCount = 0
        let maxRetries = 3
        
        func startRecognitionTask() {
            recognitionTask = recognizer.recognitionTask(with: recognitionRequest) { [weak self] result, error in
                guard let self = self else { return }
                
                if let error = error {
                    print("语音识别错误: \(error.localizedDescription)")
                    
                    // 检查是否是可恢复的错误
                    let nsError = error as NSError
                    if nsError.domain == "kAFAssistantErrorDomain" && nsError.code == 1101 && retryCount < maxRetries {
                        retryCount += 1
                        print("尝试重新启动语音识别任务 (尝试 \(retryCount)/\(maxRetries))")
                        
                        // 取消当前任务并重新开始
                        self.recognitionTask?.cancel()
                        self.recognitionTask = nil
                        
                        // 延迟一秒后重试
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                            startRecognitionTask()
                        }
                        return
                    } else if retryCount >= maxRetries {
                        print("达到最大重试次数，停止语音识别")
                        self.useVoiceRecognition = false
                        
                        // 添加一个提示消息
                        DispatchQueue.main.async {
                            let segment = ConversationSegment(
                                speaker: self.currentSpeaker,
                                content: "录音继续中...(语音识别服务不可用)",
                                timestamp: Date(),
                                audioURL: self.recordingURL
                            )
                            self.transcribedText.append(segment)
                        }
                    }
                    return
                }
                
                if let result = result {
                    let transcription = result.bestTranscription.formattedString
                    
                    // 如果结果已经是最终结果，可能任务会结束，需要重新启动任务
                    if result.isFinal {
                        print("收到最终结果，处理并准备重新启动任务")
                        self.processTranscription(transcription)
                        
                        // 创建新的识别请求
                        self.recognitionTask?.cancel()
                        self.recognitionTask = nil
                        // 创建新的请求
                        self.recognitionRequest?.endAudio()
                        self.recognitionRequest = nil
                        
                        // 停止音频引擎（准备重新开始）
                        self.audioEngine.stop()
                        self.audioEngine.inputNode.removeTap(onBus: 0)
                        
                        // 重新设置语音识别
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                            self.setupSpeechRecognition()
                        }
                        return
                    }
                    
                    // 重置处理计时器
                    self.processingTimer?.invalidate()
                    // 使用更短的延迟时间以获得更快的响应
                    self.processingTimer = Timer.scheduledTimer(withTimeInterval: 0.8, repeats: false) { [weak self] _ in
                        guard let self = self else { return }
                        self.processTranscription(transcription)
                    }
                }
            }
        }
        
        // 设置音频输入
        let inputNode = audioEngine.inputNode
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { [weak self] buffer, _ in
            guard let self = self, !self.isPaused else { return }
            self.recognitionRequest?.append(buffer)
        }
        
        audioEngine.prepare()
        
        do {
            try audioEngine.start()
            print("音频引擎已启动")
        } catch {
            print("启动音频引擎失败: \(error.localizedDescription)")
            return
        }
        
        // 开始第一次识别任务
        startRecognitionTask()
    }
    
    // 提取为单独方法处理转录文本
    private func processTranscription(_ transcription: String) {
        print("处理转录文本: \(transcription)")
        
        // 跟踪每一轮的转录结果，避免重复处理相同的文本
        if transcription == lastTranscription && !transcription.isEmpty {
            print("收到重复的转录文本，跳过处理")
            return
        }
        
        // 检测到新的完整句子
        let newSentences = self.extractNewSentences(from: transcription)
        print("提取到 \(newSentences.count) 个新句子")
        
        // 如果没有新句子，但转录文本有变化且足够长，尝试直接作为一个句子处理
        if newSentences.isEmpty && transcription != lastTranscription && transcription.count > 5 {
            let speaker = self.determineSpeakerByContent(sentence: transcription)
            DispatchQueue.main.async {
                let segment = ConversationSegment(
                    id: UUID(),
                    speaker: speaker,
                    content: transcription,
                    timestamp: Date(),
                    audioURL: self.recordingURL
                )
                self.transcribedText.append(segment)
                self.lastParsedSentence = transcription
            }
            lastTranscription = transcription
            return
        }
        
        for newSentence in newSentences {
            if !self.isDuplicateSentence(newSentence) {
                // 每次都重新检测关键词并确定说话者
                let speaker = self.determineSpeakerByContent(sentence: newSentence)
                print("句子内容: \"\(newSentence)\"")
                print("确定的说话者: \(speaker)")
                
                DispatchQueue.main.async {
                    // 创建新的对话段落
                    let segment = ConversationSegment(
                        id: UUID(), // 确保每个段落有唯一ID
                        speaker: speaker,
                        content: newSentence,
                        timestamp: Date(),
                        audioURL: self.recordingURL
                    )
                    self.transcribedText.append(segment)
                    
                    // 记录此句子为已处理
                    self.lastParsedSentence = newSentence
                }
            } else {
                print("跳过重复句子: \(newSentence)")
            }
        }
        
        // 更新最后处理的转录文本
        lastTranscription = transcription
    }
    
    // 检查句子是否已经处理过
    private func isDuplicateSentence(_ sentence: String) -> Bool {
        // 简单检查是否与上一次处理的句子相同
        if sentence == lastParsedSentence {
            return true
        }
        
        // 检查是否与已有对话内容重复 (允许短句重复)
        for segment in transcribedText {
            // 如果新句子完全包含在现有内容中，则认为是重复
            if segment.content.contains(sentence) {
                // 只有当句子长度超过一定值时才判断为重复
                if sentence.count > 5 {
                    return true
                }
            }
            
            // 如果现有内容完全包含在新句子中，且新句子长度差不多，也认为是重复
            if sentence.contains(segment.content) {
                // 长度相差不多时才判断为重复（避免新的长句被过滤）
                let lengthDifference = sentence.count - segment.content.count
                if lengthDifference < 10 && segment.content.count > 5 {
                    return true
                }
            }
        }
        
        return false
    }
    
    // 提取多个句子
    private func extractNewSentences(from transcription: String) -> [String] {
        print("原始转录文本: \"\(transcription)\"")
        
        // 使用标点符号作为分隔符
        let separators = CharacterSet(charactersIn: "。，,.!?！？;；")
        var sentences = transcription.components(separatedBy: separators)
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty && $0.count > 2 } // 过滤掉太短的句子
        
        print("分割后的句子数量: \(sentences.count)")
        
        // 如果分割后没有有效句子，但整段文本有效，则将整段作为一个句子
        if sentences.isEmpty && !transcription.isEmpty && transcription.count > 5 {
            sentences = [transcription]
            print("无法分割句子，使用整段文本作为一个句子")
        }
        
        // 如果转录文本与上次完全不同，则将其作为新句子
        if !transcription.isEmpty && transcription != lastTranscription && transcription.count > 5 {
            // 更新最后的转录文本记录
            lastTranscription = transcription
            
            // 如果没有检测到句子分隔，但有足够长的文本，将其作为一个句子
            if sentences.isEmpty {
                sentences = [transcription]
                print("使用完整转录文本作为新句子")
            }
        }
        
        // 更新当前段落
        if let lastSentence = sentences.last, !lastSentence.isEmpty {
            currentSegment = lastSentence
        }
        
        return sentences
    }
    
    // 修改方法，使其每次都重新检测关键词
    private func determineSpeakerByContent(sentence: String) -> String {
        // 检查是否包含医生关键词
        let doctorKeywordsFound = doctorKeywords.filter { keyword in
            sentence.contains(keyword)
        }
        
        // 检查是否包含患者关键词
        let patientKeywordsFound = patientKeywords.filter { keyword in
            sentence.contains(keyword)
        }
        
        // 打印找到的关键词，便于调试
        if !doctorKeywordsFound.isEmpty {
            print("找到医生关键词: \(doctorKeywordsFound)")
        }
        
        if !patientKeywordsFound.isEmpty {
            print("找到患者关键词: \(patientKeywordsFound)")
        }
        
        // 计算权重 - 调整权重计算方式，使分类更加准确
        // 医生关键词权重更高，患者关键词权重稍低
        let doctorWeight = doctorKeywordsFound.count * 3
        let patientWeight = patientKeywordsFound.count * 2
        
        print("医生关键词权重: \(doctorWeight), 患者关键词权重: \(patientWeight)")
        
        // 对特殊关键词额外加权
        let strongDoctorKeywords = ["医生建议", "医嘱", "处方", "需要检查", "治疗方案"]
        let strongPatientKeywords = ["我感觉", "我的", "我有", "疼痛", "不舒服"]
        
        for keyword in doctorKeywordsFound {
            if strongDoctorKeywords.contains(keyword) {
                print("发现强医生关键词: \(keyword)")
                return "医生"  // 直接返回医生
            }
        }
        
        for keyword in patientKeywordsFound {
            if strongPatientKeywords.contains(keyword) {
                print("发现强患者关键词: \(keyword)")
                return "患者"  // 直接返回患者
            }
        }
        
        // 根据关键词权重判断说话者
        if doctorWeight > patientWeight {
            // 如果医生关键词权重高，说话者是医生
            let oldSpeaker = currentSpeaker
            currentSpeaker = "医生"
            
            if oldSpeaker != currentSpeaker {
                print("根据关键词切换说话者为: 医生，检测到关键词: \(doctorKeywordsFound)")
            }
            return "医生"
        } else if patientWeight > 0 {
            // 如果有患者关键词，说话者是患者
            let oldSpeaker = currentSpeaker
            currentSpeaker = "患者"
            
            if oldSpeaker != currentSpeaker {
                print("根据关键词切换说话者为: 患者，检测到关键词: \(patientKeywordsFound)")
            }
            return "患者"
        } else {
            // 基于上下文和句式特征推断
            // 判断句式特征
            if sentence.hasPrefix("我") || sentence.hasPrefix("谢谢") || sentence.contains("我想") || sentence.contains("请问") {
                currentSpeaker = "患者"
                print("基于句式推断为患者: 句子以'我'或'谢谢'开头，或包含'我想'或'请问'")
                return "患者"
            } 
            
            if sentence.contains("应该") || sentence.contains("建议") || sentence.hasSuffix("吗") || sentence.hasSuffix("吧") {
                currentSpeaker = "医生"
                print("基于句式推断为医生: 句子包含'应该'或'建议'，或以'吗'或'吧'结尾")
                return "医生"
            }
            
            // 如果上述方法都不能确定，保持当前说话者
            print("未检测到明确特征，保持当前说话者: \(currentSpeaker)")
            return currentSpeaker
        }
    }
    
    func pauseRecording() {
        isPaused = true
        avAudioRecorder?.pause()
        audioEngine.pause()
        stopAudioLevelMonitoring()
    }
    
    func resumeRecording() {
        isPaused = false
        avAudioRecorder?.record()
        try? audioEngine.start()
        startAudioLevelMonitoring()
    }
    
    func stopRecording() -> URL? {
        defer {
            // 停止录音后重置音频会话
            do {
                try AVAudioSession.sharedInstance().setActive(false)
            } catch {
                print("停止音频会话失败: \(error)")
            }
        }
        
        // 停止音量监测
        stopAudioLevelMonitoring()
        
        // 停止AVAudioRecorder
        avAudioRecorder?.stop()
        
        // 停止语音识别
        processingTimer?.invalidate()
        processingTimer = nil
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)
        recognitionRequest?.endAudio()
        recognitionTask?.cancel()
        
        // 清理资源
        recognitionRequest = nil
        recognitionTask = nil
        
        isRecording = false
        isPaused = false
        audioBuffer.removeAll()
        
        // 确保录音文件已经完成写入
        print("录音已停止，文件路径: \(recordingURL?.path ?? "未知")")
        
        // 验证文件是否存在
        if let url = recordingURL, FileManager.default.fileExists(atPath: url.path) {
            if let attributes = try? FileManager.default.attributesOfItem(atPath: url.path) {
                let fileSize = attributes[.size] as? UInt64 ?? 0
                print("录音文件大小: \(fileSize) bytes")
            }
        }
        
        return recordingURL
    }
    
    // MARK: - 音量监测
    
    private func startAudioLevelMonitoring() {
        // 停止可能存在的计时器
        stopAudioLevelMonitoring()
        
        // 创建新的计时器监测音量
        audioLevelTimer = Timer.scheduledTimer(withTimeInterval: audioLevelUpdateInterval, repeats: true) { [weak self] _ in
            guard let self = self, !self.isPaused, let recorder = self.avAudioRecorder else { return }
            
            recorder.updateMeters() // 更新音量计量
            
            // 获取平均功率级别（以分贝为单位，通常为负值，静音时约为-160dB）
            let power = recorder.averagePower(forChannel: 0)
            
            // 将分贝转换为0-1的线性值
            // 分贝是对数刻度，转换为线性值
            // 将-160dB到0dB映射到0.0到1.0
            let minDb: Float = -80.0 // 设置最小分贝值
            let normPower = max(0.0, min(1.0, (power - minDb) / abs(minDb)))
            
            // 应用平滑函数使波形更平滑
            let smoothingFactor: Float = 0.2
            let newLevel = CGFloat(normPower)
            let smoothedLevel = CGFloat(smoothingFactor) * newLevel + (1 - CGFloat(smoothingFactor)) * self.currentAudioLevel
            
            // 发布更新
            DispatchQueue.main.async {
                self.currentAudioLevel = smoothedLevel
            }
        }
    }
    
    private func stopAudioLevelMonitoring() {
        audioLevelTimer?.invalidate()
        audioLevelTimer = nil
        
        // 重置音量级别
        DispatchQueue.main.async {
            self.currentAudioLevel = 0.0
        }
    }
}

// 修改AudioPlayer类，使用系统原生的AVPlayer
class AudioPlayer: NSObject, ObservableObject {
    @Published var isPlaying = false
    @Published var currentTime: TimeInterval = 0
    @Published var duration: TimeInterval = 0
    private var avPlayer: AVPlayer?
    private var playerItem: AVPlayerItem?
    private var timeObserver: Any?
    
    func play(url: URL) {
        do {
            // 配置音频会话
            let audioSession = AVAudioSession.sharedInstance()
            try audioSession.setCategory(.playback, mode: .default)
            try audioSession.setActive(true)
            
            // 检查文件是否存在
            print("准备播放音频文件: \(url.path)")
            
            // 创建AVPlayerItem和AVPlayer
            playerItem = AVPlayerItem(url: url)
            avPlayer = AVPlayer(playerItem: playerItem)
            
            // 获取音频时长
            if let duration = playerItem?.asset.duration.seconds, !duration.isNaN {
                self.duration = duration
                print("音频时长: \(duration)秒")
            } else {
                self.duration = 0
                print("无法获取音频时长，使用默认值0")
            }
            
            // 添加时间观察器
            addPeriodicTimeObserver()
            
            // 添加播放完成通知
            NotificationCenter.default.addObserver(
                self,
                selector: #selector(playerDidFinishPlaying),
                name: .AVPlayerItemDidPlayToEndTime,
                object: playerItem
            )
            
            // 开始播放
            avPlayer?.play()
            isPlaying = true
            print("开始播放音频")
            
        } catch {
            print("音频播放初始化失败: \(error.localizedDescription)")
        }
    }
    
    private func addPeriodicTimeObserver() {
        // 每0.1秒更新一次当前时间
        let interval = CMTime(seconds: 0.1, preferredTimescale: CMTimeScale(NSEC_PER_SEC))
        timeObserver = avPlayer?.addPeriodicTimeObserver(forInterval: interval, queue: .main) { [weak self] time in
            self?.currentTime = time.seconds
        }
    }
    
    @objc func playerDidFinishPlaying(notification: Notification) {
        DispatchQueue.main.async {
            self.isPlaying = false
            self.currentTime = 0
        }
    }
    
    func pause() {
        avPlayer?.pause()
        isPlaying = false
    }
    
    func resume() {
        avPlayer?.play()
        isPlaying = true
    }
    
    func stop() {
        avPlayer?.pause()
        avPlayer?.seek(to: CMTime.zero)
        isPlaying = false
        currentTime = 0
        
        // 清理资源
        if let timeObserver = timeObserver {
            avPlayer?.removeTimeObserver(timeObserver)
            self.timeObserver = nil
        }
        
        NotificationCenter.default.removeObserver(self, name: .AVPlayerItemDidPlayToEndTime, object: playerItem)
        
        do {
            try AVAudioSession.sharedInstance().setActive(false)
        } catch {
            print("停止音频会话失败: \(error)")
        }
    }
    
    func seek(to time: TimeInterval) {
        let cmTime = CMTime(seconds: time, preferredTimescale: CMTimeScale(NSEC_PER_SEC))
        avPlayer?.seek(to: cmTime)
        currentTime = time
    }
    
    deinit {
        if let timeObserver = timeObserver {
            avPlayer?.removeTimeObserver(timeObserver)
        }
        NotificationCenter.default.removeObserver(self)
    }
}

#Preview {
    NavigationView {
        RecordingsView(recordId: UUID()) // 添加测试用的 UUID
    }
}
