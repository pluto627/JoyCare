import SwiftUI
import Vision
import VisionKit
import PhotosUI

struct MedicalReportsView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var reportType = ""
    @State private var reportDate = Date()
    @State private var selectedImages: [UIImage] = []
    @State private var showImagePicker = false
    @State private var showAlert = false
    @State private var alertTitle = ""
    @State private var alertMessage = ""
    let recordId: UUID
    let onSave: (MedicalReport) -> Void
    @EnvironmentObject private var languageManager: LanguageManager
    @State private var isProcessingImage = false
    @State private var isAnalyzingReport = false
    @State private var extractedText: String? = nil
    @State private var interpretation: String? = nil
    @State private var activeTaskId: UUID? = nil
    @State private var canDismissWithPendingTask = false
    
    // 添加报告类型关键词字典
    private let reportKeywords: [String: Set<String>] = [
        "血常规": ["血常规", "血液", "血红蛋白", "白细胞", "血小板", "WBC", "RBC", "HGB"],
        "尿常规": ["尿常规", "尿液", "尿糖", "尿蛋白", "尿潜血"],
        "B超": ["B超", "超声", "声像图", "超声检查"],
        "CT": ["CT", "计算机断层", "断层扫描"],
        "核磁共振": ["核磁", "MRI", "磁共振"],
        "心电图": ["心电图", "ECG", "EKG", "心律"]
    ]
    
    // 添加报告类型列表计算属性
    private var reportTypes: [String] {
        return Array(reportKeywords.keys).sorted()
    }
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("报告信息")) {
                    Picker("报告类型", selection: $reportType) {
                        ForEach(reportTypes, id: \.self) { type in
                            Text(type).tag(type)
                        }
                    }
                    DatePicker("检查日期", selection: $reportDate, displayedComponents: .date)
                }
                
                Section(header: Text("报告图片")) {
                    if !selectedImages.isEmpty {
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 10) {
                                ForEach(selectedImages.indices, id: \.self) { index in
                                    Image(uiImage: selectedImages[index])
                                        .resizable()
                                        .scaledToFill()
                                        .frame(width: 200, height: 200)
                                        .clipShape(RoundedRectangle(cornerRadius: 10))
                                        .overlay(
                                            Button(action: {
                                                selectedImages.remove(at: index)
                                            }) {
                                                Image(systemName: "xmark.circle.fill")
                                                    .foregroundColor(.red)
                                                    .padding(8)
                                            }
                                            .offset(x: 8, y: -8),
                                            alignment: .topTrailing
                                        )
                                }
                            }
                            .padding(.vertical)
                        }
                    }
                    
                    Button(action: {
                        showImagePicker = true
                    }) {
                        HStack {
                            Image(systemName: "photo")
                            Text(selectedImages.isEmpty ? "添加报告图片" : "添加更多图片")
                        }
                    }
                    
                    if isProcessingImage {
                        ProgressView("正在识别报告类型...")
                    }
                    
                    if isAnalyzingReport {
                        ProgressView("正在分析报告内容...")
                    }
                }
                
                if extractedText != nil || interpretation != nil {
                    Section(header: Text("报告分析结果")) {
                        if let analysis = interpretation {
                            DisclosureGroup("AI解读结果") {
                                Text(analysis)
                                    .font(.body)
                                    .padding(.vertical, 8)
                            }
                        }
                    }
                }
                
                Section {
                    if activeTaskId != nil {
                        Button(action: {
                            saveAndLeave()
                        }) {
                            Text("后台继续分析")
                                .frame(maxWidth: .infinity)
                                .foregroundColor(.white)
                        }
                        .listRowBackground(Color.blue)
                    } else {
                        Button(action: saveReport) {
                            Text("保存报告")
                                .frame(maxWidth: .infinity)
                                .foregroundColor(.white)
                        }
                        .listRowBackground(Color.blue)
                        .disabled(isAnalyzingReport || selectedImages.isEmpty)
                    }
                }
            }
            .navigationTitle(NSLocalizedString("upload_report", comment: ""))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    if activeTaskId != nil {
                        Button("后台分析") {
                            saveAndLeave()
                        }
                    } else {
                        Button("保存") {
                            saveReport()
                        }
                        .disabled(isAnalyzingReport || selectedImages.isEmpty)
                    }
                }
            }
            .alert(isPresented: $showAlert) {
                Alert(
                    title: Text(alertTitle),
                    message: Text(alertMessage),
                    dismissButton: .default(Text(NSLocalizedString("ok", comment: ""))) {
                        if alertTitle == NSLocalizedString("save_success", comment: "") || canDismissWithPendingTask {
                            dismiss()
                        }
                    }
                )
            }
            .sheet(isPresented: $showImagePicker) {
                ImagePicker(selectedImages: $selectedImages, sourceType: .photoLibrary)
                    .onDisappear {
                        if let lastImage = selectedImages.last {
                            processImage(lastImage)
                        }
                    }
            }
            .localized()
            .id(languageManager.refreshToken)
            .onAppear {
                // 添加通知观察者
                setupNotificationObservers()
            }
            .onDisappear {
                // 移除通知观察者
                removeNotificationObservers()
            }
        }
    }
    
    private func setupNotificationObservers() {
        NotificationCenter.default.addObserver(
            forName: .reportAnalysisCompleted,
            object: nil,
            queue: .main
        ) { notification in
            guard let taskId = notification.userInfo?["taskId"] as? UUID,
                  let reportId = notification.userInfo?["reportId"] as? UUID,
                  taskId == activeTaskId else {
                return
            }
            
            // 处理报告分析完成通知
            let reports = ReportStorage.shared.loadReports()
            if let report = reports.first(where: { $0.id == reportId }) {
                DispatchQueue.main.async {
                    // 调用回调
                    onSave(report)
                }
            }
        }
        
        NotificationCenter.default.addObserver(
            forName: .reportAnalysisFailed,
            object: nil,
            queue: .main
        ) { notification in
            guard let taskId = notification.userInfo?["taskId"] as? UUID,
                  taskId == activeTaskId else {
                return
            }
            
            // 处理报告分析失败通知
            if let errorMessage = notification.userInfo?["error"] as? String {
                print("分析失败: \(errorMessage)")
            }
        }
    }
    
    private func removeNotificationObservers() {
        NotificationCenter.default.removeObserver(self, name: .reportAnalysisCompleted, object: nil)
        NotificationCenter.default.removeObserver(self, name: .reportAnalysisFailed, object: nil)
    }
    
    private func saveAndLeave() {
        // 后台继续分析并离开界面
        alertTitle = "报告处理中"
        alertMessage = "您的报告正在后台分析中，完成后将通知您"
        canDismissWithPendingTask = true
        showAlert = true
    }
    
    private func saveReport() {
        guard !selectedImages.isEmpty else {
            alertTitle = "错误"
            alertMessage = "请先添加报告图片"
            showAlert = true
            return
        }
        
        guard !reportType.isEmpty else {
            alertTitle = "错误"
            alertMessage = "请选择报告类型"
            showAlert = true
            return
        }
        
        // 如果已经有结果，直接保存
        if let extractedText = extractedText, let interpretation = interpretation {
            let report = MedicalReport(
                recordId: recordId,
                type: reportType,
                date: reportDate,
                images: selectedImages,
                extractedText: extractedText,
                interpretation: interpretation
            )
            
            onSave(report)
            // 保存到本地存储
            var savedReports = ReportStorage.shared.loadReports()
            // 确保不重复添加
            if !savedReports.contains(where: { $0.id == report.id }) {
                savedReports.append(report)
                ReportStorage.shared.saveReports(savedReports)
            }
            
            alertTitle = NSLocalizedString("save_success", comment: "")
            alertMessage = ""
            showAlert = true
        } else {
            // 提交后台分析
            isAnalyzingReport = true
            activeTaskId = ReportAnalysisService.shared.submitReportForAnalysis(
                recordId: recordId,
                type: reportType,
                date: reportDate,
                images: selectedImages
            )
            
            alertTitle = "报告提交成功"
            alertMessage = "您的报告已开始分析，您可以选择等待或后台处理"
            showAlert = true
        }
    }
    
    private func processImage(_ image: UIImage) {
        isProcessingImage = true
        
        guard let cgImage = image.cgImage else {
            isProcessingImage = false
            return
        }
        
        let requestHandler = VNImageRequestHandler(cgImage: cgImage)
        let request = VNRecognizeTextRequest { request, error in
            guard let observations = request.results as? [VNRecognizedTextObservation],
                  error == nil else {
                isProcessingImage = false
                return
            }
            
            let recognizedText = observations.compactMap { observation in
                observation.topCandidates(1).first?.string
            }.joined(separator: " ")
            
            // 根据识别出的文本判断报告类型
            for (type, keywords) in reportKeywords {
                for keyword in keywords {
                    if recognizedText.lowercased().contains(keyword.lowercased()) {
                        DispatchQueue.main.async {
                            self.reportType = type
                            self.isProcessingImage = false
                        }
                        return
                    }
                }
            }
            
            isProcessingImage = false
        }
        
        request.recognitionLanguages = ["zh-Hans", "en"]
        
        do {
            try requestHandler.perform([request])
        } catch {
            print("文字识别失败: \(error)")
            isProcessingImage = false
        }
    }
    
    // 旧的分析方法，保留但不再直接使用
    private func analyzeReport(_ image: UIImage) {
        isAnalyzingReport = true
        
        ReportAnalysisService.shared.analyzeReport(image: image) { result in
            DispatchQueue.main.async {
                isAnalyzingReport = false
                
                switch result {
                case .success(let analysisResult):
                    self.extractedText = analysisResult.extractedText
                    self.interpretation = analysisResult.interpretation
                    
                case .failure(let error):
                    print("报告分析失败: \(error.localizedDescription)")
                    self.alertTitle = "报告分析失败"
                    self.alertMessage = error.localizedDescription
                    self.showAlert = true
                }
            }
        }
    }
}

#Preview {
    MedicalReportsView(recordId: UUID()) { _ in }
}
