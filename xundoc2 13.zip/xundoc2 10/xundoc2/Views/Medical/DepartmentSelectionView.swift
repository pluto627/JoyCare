import SwiftUI

struct DepartmentSelectionView: View {
    @Environment(\.dismiss) private var dismiss
    @Binding var selectedDepartment: String
    @State private var searchText = ""
    @EnvironmentObject private var languageManager: LanguageManager
    
    // 科室信息结构体
    struct DepartmentInfo {
        let name: String
        let description: String
    }
    
    // 将科室按类别组织，包含描述
    private let departmentsByCategory: [(String, [DepartmentInfo])] = [
        (NSLocalizedString("department_internal", comment: ""), [
            DepartmentInfo(
                name: NSLocalizedString("cardiovascular", comment: ""),
                description: NSLocalizedString("cardiovascular_desc", comment: "")
            ),
            DepartmentInfo(
                name: NSLocalizedString("neurology", comment: ""),
                description: NSLocalizedString("neurology_desc", comment: "")
            ),
            DepartmentInfo(
                name: NSLocalizedString("internal_medicine", comment: ""),
                description: ""
            ),
            DepartmentInfo(
                name: NSLocalizedString("respiratory", comment: ""),
                description: ""
            ),
            DepartmentInfo(
                name: NSLocalizedString("digestive", comment: ""),
                description: ""
            ),
            DepartmentInfo(
                name: NSLocalizedString("endocrinology", comment: ""),
                description: ""
            ),
            DepartmentInfo(
                name: NSLocalizedString("hematology", comment: ""),
                description: ""
            )
        ]),
        (NSLocalizedString("department_surgery", comment: ""), [
            DepartmentInfo(
                name: NSLocalizedString("general_surgery", comment: ""),
                description: NSLocalizedString("general_surgery_desc", comment: "")
            ),
            DepartmentInfo(
                name: NSLocalizedString("orthopedics", comment: ""),
                description: NSLocalizedString("orthopedics_desc", comment: "")
            ),
            DepartmentInfo(
                name: NSLocalizedString("neurosurgery", comment: ""),
                description: ""
            ),
            DepartmentInfo(
                name: NSLocalizedString("cardiothoracic", comment: ""),
                description: ""
            ),
            DepartmentInfo(
                name: NSLocalizedString("plastic_surgery", comment: ""),
                description: ""
            )
        ]),
        (NSLocalizedString("department_specialized", comment: ""), [
            DepartmentInfo(
                name: NSLocalizedString("ophthalmology", comment: ""),
                description: NSLocalizedString("ophthalmology_desc", comment: "")
            ),
            DepartmentInfo(
                name: NSLocalizedString("ent", comment: ""),
                description: NSLocalizedString("ent_desc", comment: "")
            ),
            DepartmentInfo(
                name: NSLocalizedString("dermatology", comment: ""),
                description: NSLocalizedString("dermatology_desc", comment: "")
            ),
            DepartmentInfo(
                name: NSLocalizedString("stomatology", comment: ""),
                description: ""
            ),
            DepartmentInfo(
                name: NSLocalizedString("gynecology", comment: ""),
                description: ""
            ),
            DepartmentInfo(
                name: NSLocalizedString("pediatrics", comment: ""),
                description: ""
            ),
            DepartmentInfo(
                name: NSLocalizedString("oncology", comment: ""),
                description: ""
            ),
            DepartmentInfo(
                name: NSLocalizedString("psychiatry", comment: ""),
                description: ""
            ),
            DepartmentInfo(
                name: NSLocalizedString("rehabilitation", comment: ""),
                description: ""
            ),
            DepartmentInfo(
                name: NSLocalizedString("nutrition", comment: ""),
                description: ""
            ),
            DepartmentInfo(
                name: NSLocalizedString("emergency", comment: ""),
                description: ""
            )
        ])
    ]
    
    var filteredDepartments: [(String, [DepartmentInfo])] {
        if searchText.isEmpty {
            return departmentsByCategory
        } else {
            return departmentsByCategory.map { category, departments in
                (category, departments.filter { 
                    $0.name.localizedCaseInsensitiveContains(searchText) ||
                    $0.description.localizedCaseInsensitiveContains(searchText)
                })
            }.filter { !$0.1.isEmpty }
        }
    }
    
    var body: some View {
        List {
            ForEach(filteredDepartments, id: \.0) { category, departments in
                Section(header: Text(category)) {
                    ForEach(departments, id: \.name) { department in
                        Button(action: {
                            selectedDepartment = department.name
                            dismiss()
                        }) {
                            VStack(alignment: .leading, spacing: 4) {
                                HStack {
                                    Text(department.name)
                                        .foregroundColor(.primary)
                                    Spacer()
                                    if department.name == selectedDepartment {
                                        Image(systemName: "checkmark")
                                            .foregroundColor(.blue)
                                    }
                                }
                                
                                Text(department.description)
                                    .font(.caption)
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                }
            }
        }
        .navigationTitle(NSLocalizedString("select_department", comment: ""))
        .navigationBarTitleDisplayMode(.inline)
        .searchable(text: $searchText, prompt: NSLocalizedString("search_department", comment: ""))
        .toolbar {
            // ... existing code ...
        }
        .localized()
        .id(languageManager.refreshToken)
    }
}

#Preview {
    NavigationView {
        DepartmentSelectionView(selectedDepartment: .constant(""))
    }
}

