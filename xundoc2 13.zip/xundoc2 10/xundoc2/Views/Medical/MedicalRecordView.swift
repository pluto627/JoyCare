import SwiftUI
import MapKit
import CoreLocation

// 添加这一行，如果MedicalRecord模型在不同的模块中
// import YourModuleName

struct AddMedicalRecordView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) private var colorScheme
    @Binding var medicalRecords: [MedicalRecord]
    @State private var hospital: String = ""
    @State private var department: String = ""
    @State private var symptoms: String = ""
    @State private var hospitalAddress: String = ""
    @State private var showingHospitalPicker = false
    @State private var showAlert = false
    @EnvironmentObject private var languageManager: LanguageManager
    
    private var backgroundColor: Color {
        colorScheme == .dark ? Color.black : Color.white
    }
    
    private var placeholderColor: Color {
        colorScheme == .dark ? Color.gray.opacity(0.7) : Color.gray.opacity(0.5)
    }
    
    private var borderColor: Color {
        colorScheme == .dark ? Color.gray.opacity(0.5) : Color.gray.opacity(0.3)
    }
    
    private var textColor: Color {
        colorScheme == .dark ? Color.white : Color.black
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                backgroundColor.ignoresSafeArea()
                
                VStack(spacing: 20) {
                    // Hospital Input and Selection in single container
                    HStack(spacing: 0) {
                        TextField("输入就诊医院", text: $hospital)
                            .padding()
                            .foregroundColor(textColor)
                        
                        Button(action: {
                            showingHospitalPicker = true
                        }) {
                            Text("选择")
                                .foregroundColor(.blue)
                                .padding(.horizontal, 15)
                                .padding(.vertical, 12)
                        }
                        .frame(width: 70)
                    }
                    .background(colorScheme == .dark ? Color.white.opacity(0.05) : Color.white)
                    .cornerRadius(8)
                    .overlay(
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(borderColor, lineWidth: 1)
                    )
                    
                    // Rest of the view remains the same...
                    // Department Selection
                    NavigationLink(destination: DepartmentSelectionView(selectedDepartment: $department)) {
                        HStack {
                            Text(department.isEmpty ? "选择就诊科室" : department)
                                .foregroundColor(department.isEmpty ? placeholderColor : textColor)
                            Spacer()
                            Image(systemName: "chevron.right")
                                .foregroundColor(placeholderColor)
                        }
                        .padding()
                        .background(colorScheme == .dark ? Color.white.opacity(0.05) : Color.white)
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .stroke(borderColor, lineWidth: 1)
                        )
                    }
                    
                    // Symptoms TextEditor
                    ZStack(alignment: .topLeading) {
                        TextEditor(text: $symptoms)
                            .frame(height: 100)
                            .padding()
                            .foregroundColor(textColor)
                        
                        if symptoms.isEmpty {
                            Text("症状描述")
                                .foregroundColor(placeholderColor)
                                .padding(.leading, 20)
                                .padding(.top, 20)
                        }
                    }
                    .background(colorScheme == .dark ? Color.white.opacity(0.05) : Color.white)
                    .overlay(
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(borderColor, lineWidth: 1)
                    )
                    
                    Spacer()
                    
                    // Save Button
                    Button(action: {
                        saveRecord()
                        dismiss()
                    }) {
                        Text("保存")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(8)
                    }
                }
                .padding()
            }
            .navigationBarTitleDisplayMode(.inline)
            .navigationTitle(NSLocalizedString("add_medical_record", comment: ""))
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("取消") {
                        dismiss()
                    }
                }
            }
            .sheet(isPresented: $showingHospitalPicker) {
                HospitalPickerView(selectedHospital: $hospital, selectedAddress: $hospitalAddress)
            }
            .alert(isPresented: $showAlert) {
                Alert(
                    title: Text(NSLocalizedString("save_success", comment: "")),
                    message: Text(""),
                    dismissButton: .default(Text(NSLocalizedString("ok", comment: ""))) {
                        dismiss()
                    }
                )
            }
            .localized()
            .id(languageManager.refreshToken)
        }
    }
    
    private func saveRecord() {
        let newRecord = MedicalRecord(
            date: Date(),
            hospital: hospital,
            department: department,
            symptoms: symptoms,
            hospitalAddress: hospitalAddress
        )
        medicalRecords.append(newRecord)
        
        // 保存到存储
        MedicalRecordStorage.shared.saveRecords(medicalRecords)
        
        // 显示保存成功提示并关闭页面
        showAlert = true
    }
}// 新增 HospitalPickerView
struct HospitalPickerView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var hospitalStore = HospitalStore()
    @Binding var selectedHospital: String
    @Binding var selectedAddress: String
    @State private var searchText = ""
    
    var filteredHospitals: [Hospital1] {
        if searchText.isEmpty {
            return hospitalStore.hospitals
        } else {
            return hospitalStore.hospitals.filter { $0.name.contains(searchText) }
        }
    }
    
    var body: some View {
        NavigationView {
            VStack {
                SearchBar(text: $searchText)
                    .padding()
                
                List {
                    ForEach(filteredHospitals) { hospital in
                        Button(action: {
                            selectedHospital = hospital.name
                            selectedAddress = hospital.address
                            dismiss()
                        }) {
                            VStack(alignment: .leading, spacing: 8) {
                                Text(hospital.name)
                                    .font(.headline)
                                    .foregroundColor(.primary)
                                
                                Text(hospital.address)
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                            }
                            .padding(.vertical, 8)
                        }
                    }
                }
            }
            .navigationTitle("选择医院")
            .navigationBarItems(trailing: Button("取消") {
                dismiss()
            })
        }
    }
}

struct AddMedicalRecordWithMap_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            AddMedicalRecordView(medicalRecords: .constant([]))
                .preferredColorScheme(.light)
            
            AddMedicalRecordView(medicalRecords: .constant([]))
                .preferredColorScheme(.dark)
        }
    }
}
