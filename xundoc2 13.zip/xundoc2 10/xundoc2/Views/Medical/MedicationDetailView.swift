import SwiftUI

struct MedicationDetailView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) private var colorScheme
    @ObservedObject var reminderManager: ReminderManager
    let records: [Reminder]
    @EnvironmentObject private var languageManager: LanguageManager
    
    // 编辑状态的属性
    @State private var isEditing = false
    @State private var showingDeleteAlert = false
    
    // 编辑字段
    @State private var medicationName: String = ""
    @State private var dosage: String = ""
    @State private var frequency: Int = 1
    @State private var selectedTimes: [Date] = []
    @State private var beforeOrAfterMeal: String = NSLocalizedString("before_meal", comment: "")
    
    // 颜色适配深色模式
    private var backgroundColor: Color {
        colorScheme == .dark ? Color.black : Color(UIColor.systemGray6)
    }
    
    private var textColor: Color {
        colorScheme == .dark ? Color.white : Color.primary
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                backgroundColor
                    .ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 20) {
                        // 药品名称卡片
                        CardView(title: NSLocalizedString("medication_name", comment: ""), colorScheme: colorScheme) {
                            if isEditing {
                                TextField(NSLocalizedString("enter_medication_name", comment: ""), text: $medicationName)
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                    .foregroundColor(textColor)
                            } else {
                                Text(records.first?.title ?? "")
                                    .foregroundColor(textColor)
                            }
                        }
                        
                        // 服用时间卡片
                        CardView(title: NSLocalizedString("medication_time", comment: ""), colorScheme: colorScheme) {
                            VStack(alignment: .leading, spacing: 16) {
                                if isEditing {
                                    // 每日服用次数
                                    HStack {
                                        Text(NSLocalizedString("daily_frequency", comment: ""))
                                            .foregroundColor(textColor)
                                        Spacer()
                                        HStack(spacing: 20) {
                                            Button(action: { if frequency > 1 { frequency -= 1 } }) {
                                                Image(systemName: "minus.circle.fill")
                                                    .foregroundColor(.blue)
                                            }
                                            Text("\(frequency)")
                                                .foregroundColor(textColor)
                                                .frame(minWidth: 30)
                                            Button(action: { if frequency < 10 { frequency += 1 } }) {
                                                Image(systemName: "plus.circle.fill")
                                                    .foregroundColor(.blue)
                                            }
                                        }
                                    }
                                    .onChange(of: frequency) { newValue in
                                        adjustSelectedTimes(to: newValue)
                                    }
                                    
                                    // 具体时间选择
                                    ForEach(selectedTimes.indices, id: \.self) { index in
                                        DatePicker(
                                            NSLocalizedString("time", comment: "") + " \(index + 1)",
                                            selection: Binding(
                                                get: { selectedTimes[index] },
                                                set: { selectedTimes[index] = $0 }
                                            ),
                                            displayedComponents: .hourAndMinute
                                        )
                                        .colorScheme(colorScheme) // 确保DatePicker适应当前颜色模式
                                    }
                                    
                                    // 饭前饭后选择
                                    Picker(NSLocalizedString("meal_timing", comment: ""), selection: $beforeOrAfterMeal) {
                                        Text(NSLocalizedString("before_meal", comment: "")).tag(NSLocalizedString("before_meal", comment: ""))
                                        Text(NSLocalizedString("after_meal", comment: "")).tag(NSLocalizedString("after_meal", comment: ""))
                                    }
                                    .pickerStyle(SegmentedPickerStyle())
                                } else {
                                    ForEach(records) { record in
                                        HStack {
                                            Text(formatTime(record.date))
                                                .foregroundColor(textColor)
                                            Spacer()
                                            Text(record.beforeOrAfterMeal ?? "")
                                                .foregroundColor(.gray)
                                        }
                                    }
                                }
                            }
                        }
                        
                        // 用药剂量卡片
                        CardView(title: NSLocalizedString("dosage", comment: ""), colorScheme: colorScheme) {
                            if isEditing {
                                TextField(NSLocalizedString("enter_dosage", comment: ""), text: $dosage)
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                    .foregroundColor(textColor)
                            } else {
                                if let description = records.first?.description {
                                    Text(description)
                                        .foregroundColor(textColor)
                                }
                            }
                        }
                    }
                    .padding()
                }
            }
            .navigationTitle(NSLocalizedString("medication_details", comment: ""))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(NSLocalizedString("close", comment: "")) {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    if !isEditing {
                        Button(NSLocalizedString("edit", comment: "")) {
                            startEditing()
                        }
                    } else {
                        Button(NSLocalizedString("save", comment: "")) {
                            saveChanges()
                        }
                    }
                }
            }
            .alert(NSLocalizedString("confirm_delete", comment: ""), isPresented: $showingDeleteAlert) {
                Button(NSLocalizedString("cancel", comment: ""), role: .cancel) { }
                Button(NSLocalizedString("delete", comment: ""), role: .destructive) {
                    deleteRecords()
                    dismiss()
                }
            } message: {
                Text(NSLocalizedString("delete_medication_confirmation", comment: ""))
            }
            .localized()
        }
        .id(languageManager.refreshToken)
    }
    
    // MARK: - Helper Views
    
    private func binding(for index: Int) -> Binding<Date> {
        Binding(
            get: {
                if index < selectedTimes.count {
                    return selectedTimes[index]
                }
                return Date()
            },
            set: { newValue in
                while selectedTimes.count <= index {
                    selectedTimes.append(Date())
                }
                selectedTimes[index] = newValue
            }
        )
    }
}

// MARK: - Supporting Views

struct CardView<Content: View>: View {
    let title: String
    let content: Content
    let colorScheme: ColorScheme
    
    init(title: String, colorScheme: ColorScheme, @ViewBuilder content: () -> Content) {
        self.title = title
        self.colorScheme = colorScheme
        self.content = content()
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title)
                .font(.headline)
                .foregroundColor(.gray)
            
            content
                .padding()
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(colorScheme == .dark ? Color.black.opacity(0.3) : Color.white)
                .cornerRadius(10)
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(colorScheme == .dark ? Color.gray.opacity(0.3) : Color.gray.opacity(0.1), lineWidth: 0.5)
                )
        }
    }
}

struct TimePicker: View {
    let title: String
    @Binding var selection: Date
    
    var body: some View {
        HStack {
            Text(title)
            Spacer()
            DatePicker(
                "",
                selection: $selection,
                displayedComponents: .hourAndMinute
            )
            .labelsHidden()
        }
    }
}

// MARK: - Helper Methods Extension
extension MedicationDetailView {
    private func initializeEditingFields() {
        if let firstRecord = records.first {
            medicationName = firstRecord.title
            
            // 解析描述信息中的剂量和频次
            if let description = firstRecord.description {
                let components = description.components(separatedBy: "，")
                if components.count >= 2 {
                    // 提取剂量数字
                    let dosageComponent = components[0].components(separatedBy: "每次")
                    if dosageComponent.count > 1 {
                        let dosageStr = dosageComponent[1].components(separatedBy: "片")[0]
                        dosage = dosageStr.trimmingCharacters(in: .whitespaces)
                    }
                    
                    // 提取频次数字
                    let freqComponent = components[1].components(separatedBy: "每日")
                    if freqComponent.count > 1 {
                        let freqStr = freqComponent[1].components(separatedBy: "次")[0]
                        frequency = Int(freqStr.trimmingCharacters(in: .whitespaces)) ?? 1
                    }
                } else {
                    dosage = "1"
                    frequency = 1
                }
            }
            
            beforeOrAfterMeal = firstRecord.beforeOrAfterMeal ?? "饭前"
            selectedTimes = records.map { $0.date }.sorted()
        }
    }
    
    private func resetEditingFields() {
        medicationName = ""
        dosage = ""
        frequency = 1
        selectedTimes = []
        beforeOrAfterMeal = "饭前"
    }
    
    private func adjustSelectedTimes(to newFrequency: Int) {
        if newFrequency > selectedTimes.count {
            while selectedTimes.count < newFrequency {
                selectedTimes.append(Date())
            }
        } else if newFrequency < selectedTimes.count {
            selectedTimes = Array(selectedTimes.prefix(newFrequency))
        }
    }
    
    private func formatTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        return formatter.string(from: date)
    }
    
    private func saveChanges() {
        // 删除原有的提醒
        for record in records {
            reminderManager.reminders.removeAll { $0.id == record.id }
        }
        
        // 构建完整的描述信息
        let fullDescription = "每次\(dosage)片，每日\(frequency)次"
        
        // 创建新的提醒
        for time in selectedTimes {
            let newReminder = Reminder(
                title: medicationName,
                date: time,
                description: fullDescription,  // 使用完整的描述信息
                type: "用药提醒",
                beforeOrAfterMeal: beforeOrAfterMeal
            )
            reminderManager.addReminder(newReminder)
        }
        
        isEditing = false
        dismiss()
    }
    
    private func startEditing() {
        initializeEditingFields()
        isEditing = true
    }
    
    private func deleteRecords() {
        // 实现删除记录的逻辑
    }
} 

