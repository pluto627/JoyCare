import SwiftUI
import AVFoundation
import AVKit

struct RecordingDetailView: View {
    let recording: Recording
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject private var languageManager: LanguageManager
    
    @StateObject private var audioPlayer = AudioPlayerViewModel()
    @State private var showErrorAlert = false
    @State private var errorMessage = ""
    
    var body: some View {
        VStack(spacing: 0) {
            // 顶部导航栏
            HStack {
                Button(action: {
                    presentationMode.wrappedValue.dismiss()
                }) {
                    Image(systemName: "chevron.left")
                        .font(.system(size: 20))
                        .foregroundColor(.black)
                }
                
                Spacer()
                
                Text("录音详情")
                    .font(.headline)
                    .foregroundColor(.black)
                
                Spacer()
                
                Button(action: {
                    // 更多选项菜单
                }) {
                    Image(systemName: "ellipsis")
                        .font(.system(size: 20))
                        .foregroundColor(.black)
                }
            }
            .padding()
            
            Divider()
            
            // 播放控制区域
            VStack(spacing: 8) {
                // 日期显示
                Text(formatDate(recording.date))
                    .font(.subheadline)
                    .foregroundColor(.gray)
                
                // 播放按钮和进度条
                HStack {
                    // 播放/暂停按钮
                    Button(action: {
                        if audioPlayer.isPlaying {
                            audioPlayer.pause()
                        } else {
                            audioPlayer.play()
                        }
                    }) {
                        Circle()
                            .fill(Color.blue)
                            .frame(width: 40, height: 40)
                            .overlay(
                                Image(systemName: audioPlayer.isPlaying ? "pause.fill" : "play.fill")
                                    .font(.system(size: 16))
                                    .foregroundColor(.white)
                            )
                    }
                    
                    // 进度条
                    VStack(alignment: .leading, spacing: 4) {
                        // 进度条
                        GeometryReader { geometry in
                            ZStack(alignment: .leading) {
                                // 背景条
                                Rectangle()
                                    .fill(Color(.systemGray5))
                                    .frame(height: 4)
                                    .cornerRadius(2)
                                
                                // 进度条
                                Rectangle()
                                    .fill(Color.blue)
                                    .frame(width: geometry.size.width * CGFloat(audioPlayer.currentTime / max(audioPlayer.duration, 1)), height: 4)
                                    .cornerRadius(2)
                            }
                            .gesture(
                                DragGesture(minimumDistance: 0)
                                    .onChanged { value in
                                        let percentage = min(max(0, value.location.x / geometry.size.width), 1)
                                        audioPlayer.seek(to: audioPlayer.duration * Double(percentage))
                                    }
                            )
                        }
                        .frame(height: 4)
                        
                        // 时间显示
                        HStack {
                            Text(formatTime(audioPlayer.currentTime))
                                .font(.caption)
                                .foregroundColor(.gray)
                            
                            Spacer()
                            
                            Text(formatTime(audioPlayer.duration))
                                .font(.caption)
                                .foregroundColor(.gray)
                        }
                    }
                }
                .padding(.horizontal)
            }
            .padding(.vertical)
            
            Divider()
            
            // 对话内容区域
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 16) {
                    ForEach(Array(filteredConversation.enumerated()), id: \.element.id) { index, segment in
                        ConversationBubbleView(
                            segment: segment,
                            isPlayed: false
                        )
                        .padding(.horizontal)
                        .id(index) // 用于滚动到当前高亮段落
                    }
                }
                .padding(.vertical)
            }
        }
        .navigationTitle(recording.name)
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            loadAudio()
        }
        .onDisappear {
            audioPlayer.stop()
        }
        .alert(isPresented: $showErrorAlert) {
            Alert(
                title: Text("播放错误"),
                message: Text(errorMessage),
                dismissButton: .default(Text("确定"))
            )
        }
        .localized()
        .id(languageManager.refreshToken)
    }
    
    // 加载音频文件
    private func loadAudio() {
        // 检查文件是否存在
        let fileManager = FileManager.default
        if fileManager.fileExists(atPath: recording.audioURL.path) {
            print("音频文件存在: \(recording.audioURL.path)")
            audioPlayer.load(url: recording.audioURL) { error in
                if let error = error {
                    errorMessage = "无法播放录音: \(error.localizedDescription)"
                    showErrorAlert = true
                }
            }
        } else {
            print("音频文件不存在: \(recording.audioURL.path)")
            errorMessage = "录音文件不存在"
            showErrorAlert = true
        }
    }
    
    // 根据过滤器筛选对话内容
    private var filteredConversation: [ConversationSegment] {
        recording.conversation.sorted { $0.timestamp < $1.timestamp }
    }
    
    // 格式化日期为 yyyy-MM-dd HH:mm
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm"
        return formatter.string(from: date)
    }
    
    // 格式化时间为 mm:ss
    private func formatTime(_ time: TimeInterval) -> String {
        let minutes = Int(time) / 60
        let seconds = Int(time) % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }
}

// 对话气泡视图
struct ConversationBubbleView: View {
    let segment: ConversationSegment
    let isPlayed: Bool
    
    var body: some View {
        HStack(alignment: .top) {
            // 如果是医生，显示在左侧
            if segment.speaker == "医生" {
                // 头像
                Circle()
                    .fill(Color(.systemGray4))
                    .frame(width: 40, height: 40)
                    .overlay(
                        Image(systemName: "person.fill")
                            .foregroundColor(.gray)
                    )
                
                VStack(alignment: .leading, spacing: 4) {
                    // 说话者和时间
                    HStack {
                        Text(segment.speaker)
                            .font(.caption)
                            .foregroundColor(.gray)
                        
                        Text(formatTime(segment.timestamp))
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                    
                    // 对话内容
                    Text(segment.content)
                        .padding(10)
                        .background(Color(.systemGray6))
                        .cornerRadius(12)
                }
                
                Spacer()
            } else {
                // 如果是患者，显示在右侧
                Spacer()
                
                VStack(alignment: .trailing, spacing: 4) {
                    // 说话者和时间
                    HStack {
                        Text(formatTime(segment.timestamp))
                            .font(.caption)
                            .foregroundColor(.gray)
                        
                        Text(segment.speaker)
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                    
                    // 对话内容
                    Text(segment.content)
                        .padding(10)
                        .background(Color(.systemBlue).opacity(0.1))
                        .cornerRadius(12)
                }
                
                // 头像
                Circle()
                    .fill(Color(.systemGray4))
                    .frame(width: 40, height: 40)
                    .overlay(
                        Image(systemName: "person.fill")
                            .foregroundColor(.gray)
                    )
            }
        }
    }
    
    // 格式化时间为 HH:mm
    private func formatTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        return formatter.string(from: date)
    }
}

// 音频播放器视图模型 - 使用 AVAudioPlayer
class AudioPlayerViewModel: NSObject, ObservableObject, AVAudioPlayerDelegate {
    @Published var isPlaying = false
    @Published var currentTime: TimeInterval = 0
    @Published var duration: TimeInterval = 0
    
    private var audioPlayer: AVAudioPlayer?
    private var timer: Timer?
    private var avPlayer: AVPlayer?
    
    // 添加标志以避免重复错误和重试
    private var hasTriedRepair = false
    private var audioSessionError = false
    
    override init() {
        super.init()
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(handleStopAllPlayers),
            name: .stopAllAudioPlayers,
            object: nil
        )
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
        stopTimer()
        
        // 确保停止时释放音频会话
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }
    
    @objc private func handleStopAllPlayers(notification: Notification) {
        if notification.object as? AudioPlayerViewModel != self {
            stop()
        }
    }
    
    func load(url: URL, completion: @escaping (Error?) -> Void) {
        // 检查文件是否存在
        let fileManager = FileManager.default
        guard fileManager.fileExists(atPath: url.path) else {
            print("主播放器 - 音频文件不存在: \(url.path)")
            completion(NSError(domain: "AudioPlayerError", code: 404, userInfo: [NSLocalizedDescriptionKey: "文件不存在"]))
            return
        }
        
        print("源音频文件是否存在: true")
        print("源音频文件路径: \(url.path)")
        
        // 检查文件大小
        var fileSize: UInt64 = 0
        if let attributes = try? fileManager.attributesOfItem(atPath: url.path) {
            fileSize = attributes[.size] as? UInt64 ?? 0
            print("源音频文件大小: \(fileSize) bytes")
            
            // 如果文件大小为0，则返回错误
            if fileSize == 0 {
                print("主播放器 - 音频文件大小为0")
                completion(NSError(domain: "AudioPlayerError", code: 405, userInfo: [NSLocalizedDescriptionKey: "文件大小为0"]))
                return
            }
        }
        
        // 先尝试直接播放
        tryDirectPlayback(url: url) { [weak self] success, directError in
            guard let self = self else { return }
            
            if success {
                print("直接播放成功")
                completion(nil)
                return
            }
            
            // 如果直接播放失败，尝试转换格式
            print("直接播放失败，尝试转换格式")
            
            self.tryRepairAudioFile(url: url, fileSize: fileSize) { [weak self] convertedURL, convertError in
                guard let self = self else { return }
                
                if let convertedURL = convertedURL {
                    print("使用转换后的文件尝试播放")
                    
                    // 尝试使用转换后的文件
                    self.tryDirectPlayback(url: convertedURL) { success, playError in
                        if success {
                            print("使用转换后的文件播放成功")
                            completion(nil)
                        } else {
                            print("使用转换后的文件仍然失败，最后尝试AVPlayer")
                            
                            // 无论如何尝试使用AVPlayer
                            self.setupAVPlayerOnly(url: url) { success in
                                if success {
                                    print("最终使用AVPlayer成功")
                                    completion(nil)
                                } else {
                                    print("所有方法都失败")
                                    completion(NSError(domain: "AudioPlayerError", code: 500, userInfo: [NSLocalizedDescriptionKey: "无法播放音频文件"]))
                                }
                            }
                        }
                    }
                } else {
                    print("转换失败，最后尝试AVPlayer")
                    
                    // 无论如何尝试使用AVPlayer
                    self.setupAVPlayerOnly(url: url) { success in
                        if success {
                            print("最终使用AVPlayer成功")
                            completion(nil)
                        } else {
                            print("所有方法都失败")
                            completion(directError ?? convertError ?? NSError(domain: "AudioPlayerError", code: 500, userInfo: [NSLocalizedDescriptionKey: "无法播放音频文件"]))
                        }
                    }
                }
            }
        }
    }
    
    // 简化直接播放逻辑
    private func tryDirectPlayback(url: URL, completion: @escaping (Bool, Error?) -> Void) {
        // 先尝试使用AVPlayer播放
        print("尝试使用AVPlayer直接播放: \(url.path)")
        
        tryAVPlayer(url: url) { [weak self] success, error in
            guard let self = self else { return }
            
            if success {
                print("AVPlayer播放成功")
                completion(true, nil)
                return
            }
            
            // 如果AVPlayer失败，尝试使用AVAudioPlayer
            print("AVPlayer失败，尝试使用AVAudioPlayer")
            
            do {
                // 配置音频会话
                try? self.configureAudioSession()
                
                // 尝试直接播放URL
                let player = try AVAudioPlayer(contentsOf: url)
                self.audioPlayer = player
                self.audioPlayer?.delegate = self
                player.prepareToPlay()
                
                // 获取时长
                let audioDuration = player.duration
                print("AVAudioPlayer音频时长: \(audioDuration) 秒")
                
                if audioDuration > 0 {
                    self.duration = audioDuration
                    completion(true, nil)
                    return
                } else {
                    print("AVAudioPlayer音频时长为0")
                }
            } catch {
                print("AVAudioPlayer初始化失败: \(error.localizedDescription)")
                
                // 如果直接播放URL失败，尝试读取数据再播放
                do {
                    let data = try Data(contentsOf: url)
                    print("成功读取音频数据: \(data.count) bytes")
                    
                    let player = try AVAudioPlayer(data: data)
                    self.audioPlayer = player
                    self.audioPlayer?.delegate = self
                    player.prepareToPlay()
                    
                    let audioDuration = player.duration
                    if audioDuration > 0 {
                        self.duration = audioDuration
                        completion(true, nil)
                        return
                    }
                } catch {
                    print("通过数据创建AVAudioPlayer失败: \(error.localizedDescription)")
                }
            }
            
            // 所有尝试都失败
            completion(false, error)
        }
    }
    
    // 配置音频会话
    private func configureAudioSession() throws {
        // 已有错误则跳过
        if audioSessionError {
            return
        }
        
        do {
            let audioSession = AVAudioSession.sharedInstance()
            
            // 先尝试停用
            try? audioSession.setActive(false, options: .notifyOthersOnDeactivation)
            
            // 然后使用playback模式
            try audioSession.setCategory(.playback, mode: .default, options: [.allowBluetooth, .allowAirPlay])
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
        } catch {
            print("配置音频会话失败: \(error.localizedDescription)")
            audioSessionError = true
            // 不抛出错误，让播放继续
        }
    }
    
    // 尝试使用AVPlayer
    private func tryAVPlayer(url: URL, completion: @escaping (Bool, Error?) -> Void) {
        // 创建AVPlayer，不依赖音频会话
        let playerItem = AVPlayerItem(url: url)
        avPlayer = AVPlayer(playerItem: playerItem)
        
        // 监听播放状态
        var observation: NSKeyValueObservation?
        observation = avPlayer?.currentItem?.observe(\.status, options: [.new]) { [weak self] item, change in
            guard let self = self else { 
                observation?.invalidate()
                return 
            }
            
            if item.status == .readyToPlay {
                print("AVPlayer准备就绪")
                
                // 获取时长
                let seconds = CMTimeGetSeconds(item.duration)
                if !seconds.isNaN && seconds > 0 {
                    self.duration = seconds
                    print("AVPlayer音频时长: \(seconds) 秒")
                    observation?.invalidate()
                    completion(true, nil)
                } else {
                    print("AVPlayer无法获取有效时长")
                    observation?.invalidate()
                    completion(false, NSError(domain: "AudioPlayerError", code: 407, userInfo: [NSLocalizedDescriptionKey: "无法获取有效时长"]))
                }
            } else if item.status == .failed {
                print("AVPlayer加载失败: \(String(describing: item.error))")
                observation?.invalidate()
                completion(false, item.error)
            }
        }
        
        // 设置超时
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            if observation != nil {
                print("AVPlayer加载超时")
                observation?.invalidate()
                completion(false, NSError(domain: "AudioPlayerError", code: 408, userInfo: [NSLocalizedDescriptionKey: "AVPlayer加载超时"]))
            }
        }
    }
    
    // 尝试修复音频文件
    private func tryRepairAudioFile(url: URL, fileSize: UInt64, completion: @escaping (URL?, Error?) -> Void) {
        print("开始尝试转换音频文件格式")
        
        // 先检查文件扩展名是否为m4a
        let fileExtension = url.pathExtension.lowercased()
        if fileExtension != "m4a" && fileExtension != "wav" {
            print("不支持的文件格式: \(fileExtension)")
            completion(nil, NSError(domain: "AudioPlayerError", code: 410, userInfo: [NSLocalizedDescriptionKey: "不支持的文件格式"])) 
            return
        }
        
        // 创建转换后的文件URL
        let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let convertedFileName = "converted_\(UUID().uuidString).m4a"
        let convertedURL = documentsPath.appendingPathComponent(convertedFileName)
        
        // 使用AVAsset进行音频转换
        let asset = AVAsset(url: url)
        
        // 创建导出会话
        guard let exportSession = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetAppleM4A) else {
            print("无法创建导出会话")
            completion(nil, NSError(domain: "AudioPlayerError", code: 411, userInfo: [NSLocalizedDescriptionKey: "无法创建导出会话"]))
            return
        }
        
        // 配置导出会话
        exportSession.outputURL = convertedURL
        exportSession.outputFileType = .m4a
        exportSession.shouldOptimizeForNetworkUse = true
        
        print("开始导出音频: \(convertedURL.path)")
        
        // 开始导出
        exportSession.exportAsynchronously {
            DispatchQueue.main.async {
                if exportSession.status == .completed {
                    print("音频转换成功: \(convertedURL.path)")
                    
                    // 检查转换后的文件大小
                    if let attributes = try? FileManager.default.attributesOfItem(atPath: convertedURL.path),
                       let fileSize = attributes[.size] as? UInt64 {
                        print("转换后的文件大小: \(fileSize) bytes")
                    }
                    
                    completion(convertedURL, nil)
                } else {
                    print("音频转换失败: \(exportSession.error?.localizedDescription ?? "未知错误")")
                    completion(nil, exportSession.error)
                }
            }
        }
    }
    
    // 只使用AVPlayer的最后尝试
    private func setupAVPlayerOnly(url: URL, completion: @escaping (Bool) -> Void) {
        print("最后尝试：创建AVPlayer")
        
        // 直接创建
        let asset = AVAsset(url: url)
        let playerItem = AVPlayerItem(asset: asset)
        
        avPlayer = AVPlayer(playerItem: playerItem)
        avPlayer?.automaticallyWaitsToMinimizeStalling = false
        
        // 监听是否准备好
        var timeObserver: Any?
        timeObserver = avPlayer?.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.5, preferredTimescale: 600), queue: DispatchQueue.main) { [weak self] _ in
            guard let self = self, let player = self.avPlayer, player.status == .readyToPlay else { return }
            
            // 只要能获取到任何时长都认为成功
            let duration = CMTimeGetSeconds(player.currentItem?.asset.duration ?? .zero)
            if !duration.isNaN {
                self.duration = max(duration, 1)
                completion(true)
            } else {
                // 手动设置一个时长，即使不准确
                self.duration = 60.0 // 假设1分钟
                completion(true)
            }
            
            // 移除观察者
            if let observer = timeObserver {
                player.removeTimeObserver(observer)
            }
        }
        
        // 设置超时
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            if let observer = timeObserver, let player = self.avPlayer {
                player.removeTimeObserver(observer)
                
                // 超时也认为成功，设置一个默认时长
                if self.duration <= 0 {
                    self.duration = 60.0
                    completion(true)
                } else {
                    completion(false)
                }
            }
        }
    }
    
    func play() {
        // 停止所有其他播放器
        NotificationCenter.default.post(name: .stopAllAudioPlayers, object: self)
        
        if let player = audioPlayer {
            let success = player.play()
            if success {
                isPlaying = true
                startTimer()
                print("主播放器 - 开始播放成功 (AVAudioPlayer)")
            } else {
                print("主播放器 - AVAudioPlayer播放失败")
                tryPlayWithAVPlayer()
            }
        } else if let player = avPlayer {
            player.play()
            isPlaying = true
            startAVPlayerTimer()
            print("主播放器 - 开始播放成功 (AVPlayer)")
        } else {
            print("主播放器 - 播放器未初始化")
        }
    }
    
    // 当AVAudioPlayer失败时尝试用AVPlayer播放
    private func tryPlayWithAVPlayer() {
        if let player = avPlayer {
            player.play()
            isPlaying = true
            startAVPlayerTimer()
            print("主播放器 - 切换到AVPlayer播放")
        }
    }
    
    func pause() {
        audioPlayer?.pause()
        avPlayer?.pause()
        isPlaying = false
        stopTimer()
    }
    
    func stop() {
        audioPlayer?.stop()
        audioPlayer?.currentTime = 0
        avPlayer?.pause()
        avPlayer?.seek(to: CMTime.zero)
        isPlaying = false
        currentTime = 0
        stopTimer()
    }
    
    func seek(to time: TimeInterval) {
        audioPlayer?.currentTime = time
        avPlayer?.seek(to: CMTime(seconds: time, preferredTimescale: 1000))
        currentTime = time
    }
    
    private func startTimer() {
        stopTimer()
        timer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            
            if let player = self.audioPlayer {
                if player.isPlaying {
                    self.currentTime = player.currentTime
                } else if self.isPlaying {
                    // AVAudioPlayer可能在播放中断止，尝试切换到AVPlayer
                    self.tryPlayWithAVPlayer()
                }
            } else if let player = self.avPlayer {
                let currentTime = CMTimeGetSeconds(player.currentTime())
                if !currentTime.isNaN {
                    self.currentTime = currentTime
                }
            }
        }
    }
    
    private func startAVPlayerTimer() {
        stopTimer()
        timer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { [weak self] _ in
            guard let self = self, let player = self.avPlayer else { return }
            let currentTime = CMTimeGetSeconds(player.currentTime())
            if !currentTime.isNaN {
                self.currentTime = currentTime
            }
        }
    }
    
    private func stopTimer() {
        timer?.invalidate()
        timer = nil
    }
    
    // AVAudioPlayerDelegate
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        DispatchQueue.main.async {
            self.isPlaying = false
            self.currentTime = 0
            self.stopTimer()
        }
    }
}

// 添加通知名称扩展
extension Notification.Name {
    static let stopAllAudioPlayers = Notification.Name("stopAllAudioPlayers")
} 