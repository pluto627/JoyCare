import SwiftUI
import AVFoundation
import CoreML
import Speech

struct MedicalRecordDetailView: View {
    let record: MedicalRecord
    @State private var showingEditSheet = false
    @State private var showFloatingMenu = false
    @State private var reports: [MedicalReport] = []
    @State private var recordings: [Recording] = []
    @State private var orders: [DoctorOrder] = []
    @State private var updatedRecord: MedicalRecord
    @State private var refreshView = false
    @Environment(\.colorScheme) var colorScheme
    @EnvironmentObject private var languageManager: LanguageManager
    
    init(record: MedicalRecord) {
        self.record = record
        self._updatedRecord = State(initialValue: record)
    }
    
    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                // 顶部医院信息卡片
                HospitalInfoCard(record: updatedRecord)
                
                // 症状详情
                DetailCard(
                    title: "症状详情",
                    icon: "lungs.fill",
                    iconColor: .purple
                ) {
                    VStack(alignment: .leading, spacing: 8) {
                        Text(updatedRecord.symptoms)
                            .lineSpacing(6)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
                
                // 主要信息部分
                VStack(spacing: 16) {
                    // 就诊录音
                    if !recordings.isEmpty {
                        DetailCard(
                            title: "就诊录音",
                            icon: "waveform",
                            iconColor: .orange
                        ) {
                            ForEach(recordings.sorted(by: { $0.date > $1.date })) { recording in
                                RecordingRow(recording: recording) {
                                    deleteRecording(recording)
                                }
                            }
                        }
                    }
                    
                    // 检查报告
                    if !reports.isEmpty {
                        DetailCard(
                            title: "检查报告",
                            icon: "doc.text.fill",
                            iconColor: .green
                        ) {
                            ForEach(reports) { report in
                                ReportRow(report: report) {
                                    deleteReport(report)
                                }
                            }
                        }
                    }
                    
                    // 添加医嘱卡片
                    if !orders.isEmpty {
                        DetailCard(
                            title: "医生医嘱",
                            icon: "list.clipboard.fill",
                            iconColor: .blue
                        ) {
                            ForEach(orders) { order in
                                OrderRow(order: order) {
                                    deleteOrder(order)
                                }
                            }
                        }
                    }
                }
            }
            .padding()
        }
        .id(refreshView)
        .navigationTitle(NSLocalizedString("record_details", comment: ""))
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                EditButton(showingEditSheet: $showingEditSheet, record: updatedRecord)
            }
        }
        .sheet(isPresented: $showingEditSheet) {
            EditMedicalRecordView(record: updatedRecord, onSave: { newRecord in
                updatedRecord = newRecord
                refreshView.toggle()
            })
        }
        .overlay(
            FloatingButton(
                recordId: record.id,
                showMenu: $showFloatingMenu,
                reports: $reports,
                recordings: $recordings,
                orders: $orders
            )
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomTrailing)
        )
        .onAppear {
            // 加载数据
            loadData()
            
            // 添加通知观察者
            setupNotificationObservers()
        }
        .onDisappear {
            // 移除通知观察者
            removeNotificationObservers()
        }
        .localized()
        .id(languageManager.refreshToken)
    }
    
    // 添加加载数据的方法
    private func loadData() {
        orders = DoctorOrderStorage.shared.loadOrders(for: record.id)
        reports = ReportStorage.shared.loadReports(for: record.id)
        recordings = RecordingStorage.shared.loadRecordings(for: record.id)
    }
    
    // 添加通知观察者方法
    private func setupNotificationObservers() {
        // 观察报告分析完成通知
        NotificationCenter.default.addObserver(
            forName: .reportAnalysisCompleted,
            object: nil,
            queue: .main
        ) { notification in
            // 报告分析完成后，重新加载数据
            loadData()
            // 触发视图刷新
            refreshView.toggle()
        }
    }
    
    // 移除通知观察者方法
    private func removeNotificationObservers() {
        NotificationCenter.default.removeObserver(self, name: .reportAnalysisCompleted, object: nil)
    }
    
    // 添加删除方法
    private func deleteReport(_ report: MedicalReport) {
        if let index = reports.firstIndex(where: { $0.id == report.id }) {
            reports.remove(at: index)
            ReportStorage.shared.saveReports(reports)
        }
    }
    
    private func deleteRecording(_ recording: Recording) {
        if let index = recordings.firstIndex(where: { $0.id == recording.id }) {
            recordings.remove(at: index)
            RecordingStorage.shared.deleteRecording(recording)
        }
    }
    
    private func deleteOrder(_ order: DoctorOrder) {
        if let index = orders.firstIndex(where: { $0.id == order.id }) {
            orders.remove(at: index)
            var savedOrders = DoctorOrderStorage.shared.loadOrders()
            savedOrders.removeAll { $0.id == order.id }
            DoctorOrderStorage.shared.saveOrders(savedOrders)
        }
    }
}

// MARK: - 子视图组件

struct DetailCard<Content: View>: View {
    let title: String
    let icon: String
    let iconColor: Color
    let content: Content
    @Environment(\.colorScheme) private var colorScheme
    
    init(
        title: String,
        icon: String,
        iconColor: Color,
        @ViewBuilder content: () -> Content
    ) {
        self.title = title
        self.icon = icon
        self.iconColor = iconColor
        self.content = content()
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Image(systemName: icon)
                    .foregroundColor(iconColor)
                Text(title)
                    .font(.headline)
            }
            
            content
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(colorScheme == .dark ? Color.black.opacity(0.3) : Color(hex: "FAFAFA"))
        .cornerRadius(16)
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(colorScheme == .dark ? Color.gray.opacity(0.3) : Color(UIColor.systemGray4), lineWidth: 0.5)
        )
    }
}

struct HospitalInfoCard: View {
    let record: MedicalRecord
    @Environment(\.colorScheme) private var colorScheme
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text(record.hospital)
                    .font(.title3)
            }
            
            HStack(spacing: 12) {
                TagView(text: record.department, icon: "cross.case.fill")
                    .font(.subheadline)
                
                HStack(spacing: 4) {
                    Image(systemName: "calendar")
                        .foregroundColor(.gray)
                        .font(.subheadline)
                    Text(formatDate(record.date))
                        .foregroundColor(.gray)
                        .font(.subheadline)
                }
            }
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(colorScheme == .dark ? Color.black.opacity(0.3) : Color(hex: "FAFAFA"))
        .cornerRadius(16)
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(colorScheme == .dark ? Color.gray.opacity(0.3) : Color(UIColor.systemGray4), lineWidth: 0.5)
        )
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy年MM月dd日 HH:mm:ss"
        return formatter.string(from: date)
    }
}

struct TagView: View {
    let text: String
    let icon: String
    @Environment(\.colorScheme) private var colorScheme
    
    var body: some View {
        HStack(spacing: 4) {
            Image(systemName: icon)
                .foregroundColor(Color.purple)
            Text(text)
                .foregroundColor(Color.purple)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 6)
        .background(colorScheme == .dark ? Color.purple.opacity(0.2) : Color.purple.opacity(0.1))
        .cornerRadius(8)
    }
}

struct DiagnosisRow: View {
    let title: String
    let content: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.subheadline)
                .foregroundColor(.gray)
            Text(content)
                .fixedSize(horizontal: false, vertical: true)
        }
    }
}

struct PrescriptionRow: View {
    let prescription: Prescription
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(prescription.name)
                .font(.system(.body, design: .rounded))
                .fontWeight(.medium)
            
            HStack {
                Text("用法：\(prescription.usage)")
                Spacer()
                Text("数量：\(prescription.quantity)")
            }
            .font(.subheadline)
            .foregroundColor(.gray)
            
            Divider()
        }
    }
}

struct EditButton: View {
    @Binding var showingEditSheet: Bool
    let record: MedicalRecord
    
    var body: some View {
        Button(action: {
            showingEditSheet = true
        }) {
            Text("修改")
                .foregroundColor(Color.purple)
        }
    }
}

// MARK: - 浮动按钮菜单
struct FloatingButton: View {
    let recordId: UUID
    @Binding var showMenu: Bool
    @Binding var reports: [MedicalReport]
    @Binding var recordings: [Recording]
    @Binding var orders: [DoctorOrder]
    
    @State private var navigateToOrders = false
    @State private var navigateToRecordings = false
    @State private var navigateToReports = false
    
    var body: some View {
        ZStack(alignment: .bottomTrailing) {
            // 菜单背景
            if showMenu {
                Color.black.opacity(0.2)
                    .ignoresSafeArea()
                    .onTapGesture {
                        withAnimation(.easeOut(duration: 0.2)) {
                            showMenu = false
                        }
                    }
            }
            
            VStack(alignment: .trailing, spacing: 10) {
                // 菜单选项
                if showMenu {
                    
                    MenuButton(
                        title: "添加就诊录音",
                        icon: "microphone",
                        color: .orange,
                        action: { navigateToRecordings = true }
                    )
                    
                    MenuButton(
                        title: "添加检查报告",
                        icon: "doc.text.fill",
                        color: .purple,
                        action: { navigateToReports = true }
                    )
                    
                    MenuButton(
                        title: "添加医生处方",
                        icon: "doc.text.below.ecg",
                        color: .blue,
                        action: { navigateToOrders = true }
                    )
                    
                }
                
                    

                
                // 主按钮 - 保持固定
                Button(action: {
                    withAnimation(.easeInOut(duration: 0.2)) {
                        showMenu.toggle()
                    }
                }) {
                    Image(systemName: "plus")
                        .font(.system(size: 24, weight: .semibold))
                        .foregroundColor(.white)
                        .frame(width: 56, height: 56)
                        .background(Color.purple)
                        .clipShape(Circle())
                        .shadow(color: .black.opacity(0.2), radius: 4)
                }
            }
            .padding()
        }
        NavigationLink(isActive: $navigateToOrders) {
            DoctorOrdersView(recordId: recordId) { newOrder in
                // 添加到本地状态
                orders.append(newOrder)
                
                // 保存到存储系统，但只保存一次
                var savedOrders = DoctorOrderStorage.shared.loadOrders()
                // 确保不重复添加
                if !savedOrders.contains(where: { $0.id == newOrder.id }) {
                    savedOrders.append(newOrder)
                    DoctorOrderStorage.shared.saveOrders(savedOrders)
                }
            }
        } label: { EmptyView() }

        NavigationLink(isActive: $navigateToRecordings) {
            RecordingsView(recordId: recordId) { newRecording in
                // 创建带有病历ID的新录音
                let recordingWithId = Recording(
                    id: newRecording.id,
                    recordId: recordId,  // 添加病历ID
                    name: newRecording.name,
                    date: newRecording.date,
                    audioURL: newRecording.audioURL,
                    conversation: newRecording.conversation
                )
                
                // 添加到本地状态
                recordings.append(recordingWithId)
                
                // 保存到存储系统，但只保存一次
                var savedRecordings = RecordingStorage.shared.loadRecordings()
                // 确保不重复添加
                if !savedRecordings.contains(where: { $0.id == recordingWithId.id }) {
                    savedRecordings.append(recordingWithId)
                    RecordingStorage.shared.saveRecordings(savedRecordings)
                }
            }
        } label: { EmptyView() }

        NavigationLink(isActive: $navigateToReports) {
            MedicalReportsView(recordId: recordId) { newReport in
                // 先添加到本地状态
                reports.append(newReport)
                
                // 保存到存储系统，但只保存一次
                // 获取所有现有报告
                var savedReports = ReportStorage.shared.loadReports()
                // 确保不重复添加
                if !savedReports.contains(where: { $0.id == newReport.id }) {
                    savedReports.append(newReport)
                    ReportStorage.shared.saveReports(savedReports)
                }
            }
        } label: { EmptyView() }
    }
}

struct MenuButton: View {
    let title: String
    let icon: String
    let color: Color
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Text(title)
                    .font(.system(size: 16, weight: .medium))
                Image(systemName: icon)
                    .font(.system(size: 16, weight: .medium))
            }
            .foregroundColor(.white)
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .background(color)
            .cornerRadius(25)
            .shadow(color: color.opacity(0.3), radius: 4)
        }
        .transition(.opacity.combined(with: .move(edge: .trailing)))
    }
}

// MARK: - 功能页面

// MARK: - 数据模型扩展

struct Prescription {
    let name: String
    let usage: String
    let quantity: String
}

struct MedicalReport: Codable, Identifiable {
    let id: UUID
    let recordId: UUID  // 添加关联的病历ID
    let type: String
    let date: Date
    let imageData: [Data]
    var extractedText: String?
    var interpretation: String?
    
    var images: [UIImage] {
        imageData.compactMap { UIImage(data: $0) }
    }
    
    init(id: UUID = UUID(), recordId: UUID, type: String, date: Date, images: [UIImage], extractedText: String? = nil, interpretation: String? = nil) {
        self.id = id
        self.recordId = recordId
        self.type = type
        self.date = date
        self.imageData = images.compactMap { $0.jpegData(compressionQuality: 0.7) }
        self.extractedText = extractedText
        self.interpretation = interpretation
    }
}

class ReportStorage {
    static let shared = ReportStorage()
    private let defaults = UserDefaults.standard
    private let key = "savedMedicalReports"
    
    func saveReports(_ reports: [MedicalReport]) {
        // 去重处理
        let uniqueIds = Set(reports.map { $0.id })
        var uniqueReports: [MedicalReport] = []
        
        // 确保每个ID只保留一个报告
        for id in uniqueIds {
            if let report = reports.first(where: { $0.id == id }) {
                uniqueReports.append(report)
            }
        }
        
        // 保存去重后的数据
        if let encoded = try? JSONEncoder().encode(uniqueReports) {
            defaults.set(encoded, forKey: key)
        }
    }
    
    func loadReports() -> [MedicalReport] {
        if let data = defaults.data(forKey: key),
           let decoded = try? JSONDecoder().decode([MedicalReport].self, from: data) {
            return decoded
        }
        return []
    }
    
    func loadReports(for recordId: UUID) -> [MedicalReport] {
        let allReports = loadReports()
        
        // 过滤并去重
        let filteredReports = allReports.filter { $0.recordId == recordId }
        let uniqueIds = Set(filteredReports.map { $0.id })
        
        // 确保每个ID只保留一个报告
        var uniqueReports: [MedicalReport] = []
        for id in uniqueIds {
            if let report = filteredReports.first(where: { $0.id == id }) {
                uniqueReports.append(report)
            }
        }
        
        return uniqueReports
    }
}

extension MedicalRecord {
    var diagnosis: String? { nil }  // 示例数据，实际应从模型中获取
    var suggestion: String? { nil }
    var prescriptions: [Prescription]? { nil }
    var notes: String? { nil }
    var reports: [MedicalReport]? { nil }
    
    var shareText: String {
        """
        医院：\(hospital)
        科室：\(department)
        就诊时间：\(formatDate(date))
        症状：\(symptoms)
        """
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy年MM月dd日 HH:mm:ss"
        return formatter.string(from: date)
    }
}

// MARK: - 预览


// 添加 ReportRow 视图组件
struct ReportRow: View {
    let report: MedicalReport
    let onDelete: () -> Void
    @State private var showingDeleteAlert = false
    @State private var selectedImage: UIImage?
    @State private var showingFullScreenImage = false
    @State private var showingReportDetail = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            ForEach(report.images.indices, id: \.self) { index in
                HStack(spacing: 12) {
                    // 修改图片大小为 70x70
                    Image(uiImage: report.images[index])
                        .resizable()
                        .scaledToFill()
                        .frame(width: 70, height: 70)  // 修改为70x70
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                    
                    // 报告信息
                    VStack(alignment: .leading, spacing: 8) {
                        Text(report.type)
                            .font(.headline)
                        Text(formatDate(report.date))
                            .font(.subheadline)
                            .foregroundColor(.gray)
                        
                        if report.interpretation != nil {
                            Text("AI解读")
                                .font(.caption)
                                .foregroundColor(.green)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 2)
                                .background(Color.green.opacity(0.1))
                                .cornerRadius(4)
                        }
                    }
                    
                    Spacer()
                    
                    Image(systemName: "chevron.right")
                        .foregroundColor(.gray)
                        .font(.system(size: 14))
                }
            }
        }
        .contentShape(Rectangle())
        .onTapGesture {
            // 点击整行时显示报告详情
            showingReportDetail = true
        }
        .onLongPressGesture {
            showingDeleteAlert = true
        }
        .alert(isPresented: $showingDeleteAlert) {
            Alert(
                title: Text("删除报告"),
                message: Text("确定要删除这份报告吗？"),
                primaryButton: .destructive(Text("删除")) {
                    onDelete()
                },
                secondaryButton: .cancel()
            )
        }
        .sheet(isPresented: $showingFullScreenImage) {
            if let image = selectedImage {
                ZStack {
                    Color.black.edgesIgnoringSafeArea(.all)
                    
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                    
                    VStack {
                        HStack {
                            Spacer()
                            Button(action: {
                                showingFullScreenImage = false
                            }) {
                                Image(systemName: "xmark.circle.fill")
                                    .font(.title)
                                    .foregroundColor(.white)
                                    .padding()
                            }
                        }
                        Spacer()
                    }
                }
                .edgesIgnoringSafeArea(.all)
            }
        }
        .sheet(isPresented: $showingReportDetail) {
            ReportDetailView(report: report)
        }
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy年MM月dd日"
        return formatter.string(from: date)
    }
}

// 添加报告详情视图
struct ReportDetailView: View {
    let report: MedicalReport
    @Environment(\.dismiss) private var dismiss
    @State private var selectedImageIndex = 0
    
    // 判断是否为血液或尿液报告
    private var isLabReport: Bool {
        let type = report.type.lowercased()
        return type.contains("血") || type.contains("尿") || 
               type.contains("血液") || type.contains("尿液") ||
               type.contains("血常规") || type.contains("尿常规") ||
               type.contains("生化") || type.contains("检验")
    }
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    // 报告基本信息
                    VStack(alignment: .leading, spacing: 10) {
                        Text("报告类型：\(report.type)")
                            .font(.headline)
                        Text("检查日期：\(formatDate(report.date))")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }
                    .padding(.horizontal)
                    
                    // 报告图片
                    if !report.images.isEmpty {
                        VStack(alignment: .leading, spacing: 10) {
                            Text("报告图片")
                                .font(.headline)
                                .padding(.horizontal)
                            
                            TabView(selection: $selectedImageIndex) {
                                ForEach(report.images.indices, id: \.self) { index in
                                    Image(uiImage: report.images[index])
                                        .resizable()
                                        .scaledToFit()
                                        .tag(index)
                                }
                            }
                            .tabViewStyle(PageTabViewStyle())
                            .frame(height: 300)
                        }
                    }
                    
                    // AI解读结果
                    if let interpretation = report.interpretation {
                        VStack(alignment: .leading, spacing: 16) {
                            Text("AI解读结果")
                                .font(.headline)
                                .padding(.horizontal)
                            
                            // 只有在血液或尿液报告时显示关键指标表格
                            if isLabReport {
                                // 解析并显示关键指标
                                let keyIndicators = extractKeyIndicators(from: interpretation)
                                if !keyIndicators.isEmpty {
                                    VStack(alignment: .leading, spacing: 8) {
                                        Text("关键指标")
                                            .font(.subheadline)
                                            .fontWeight(.semibold)
                                            .padding(.horizontal)
                                        
                                        // 表格形式显示关键指标
                                        VStack(spacing: 0) {
                                            // 表头
                                            HStack {
                                                Text("指标名称")
                                                    .font(.caption)
                                                    .fontWeight(.bold)
                                                    .frame(maxWidth: .infinity, alignment: .leading)
                                                    .padding(.vertical, 8)
                                                    .padding(.horizontal, 10)
                                                    .background(Color.gray.opacity(0.2))
                                                
                                                Text("检测值")
                                                    .font(.caption)
                                                    .fontWeight(.bold)
                                                    .frame(width: 80, alignment: .center)
                                                    .padding(.vertical, 8)
                                                    .background(Color.gray.opacity(0.2))
                                                
                                                Text("参考范围")
                                                    .font(.caption)
                                                    .fontWeight(.bold)
                                                    .frame(width: 100, alignment: .center)
                                                    .padding(.vertical, 8)
                                                    .padding(.horizontal, 10)
                                                    .background(Color.gray.opacity(0.2))
                                            }
                                            
                                            // 表格内容
                                            ForEach(keyIndicators, id: \.name) { indicator in
                                                HStack {
                                                    Text(indicator.name)
                                                        .font(.caption)
                                                        .frame(maxWidth: .infinity, alignment: .leading)
                                                        .padding(.vertical, 8)
                                                        .padding(.horizontal, 10)
                                                        .background(Color.white.opacity(0.05))
                                                    
                                                    Text(indicator.value)
                                                        .font(.caption)
                                                        .foregroundColor(indicator.isAbnormal ? .red : .primary)
                                                        .fontWeight(indicator.isAbnormal ? .bold : .regular)
                                                        .frame(width: 80, alignment: .center)
                                                        .padding(.vertical, 8)
                                                        .background(Color.white.opacity(0.05))
                                                    
                                                    Text(indicator.range)
                                                        .font(.caption)
                                                        .frame(width: 100, alignment: .center)
                                                        .padding(.vertical, 8)
                                                        .padding(.horizontal, 10)
                                                        .background(Color.white.opacity(0.05))
                                                }
                                                Divider()
                                            }
                                        }
                                        .background(Color.blue.opacity(0.1))
                                        .cornerRadius(8)
                                        .padding(.horizontal)
                                    }
                                }
                            }
                            
                            // 完整解读
                            VStack(alignment: .leading, spacing: 8) {
                                Text("完整解读")
                                    .font(.subheadline)
                                    .fontWeight(.semibold)
                                    .padding(.horizontal)
                                
                                // 格式化解读文本，处理 ## 标记
                                FormattedInterpretationText(interpretation: interpretation)
                                    .padding()
                                    .background(Color.blue.opacity(0.1))
                                    .cornerRadius(8)
                                    .padding(.horizontal)
                            }
                        }
                    }
                }
                .padding(.vertical)
            }
            .navigationTitle("检查报告详情")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("关闭") {
                        dismiss()
                    }
                }
            }
        }
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy年MM月dd日 HH:mm:ss"
        return formatter.string(from: date)
    }
    
    // 从解读文本中提取关键指标
    private func extractKeyIndicators(from text: String) -> [KeyIndicator] {
        var indicators: [KeyIndicator] = []
        
        // 尝试查找常见的指标模式
        // 例如：血红蛋白(HGB): 120 g/L (参考范围: 110-160 g/L)
        let patterns = [
            // 匹配格式：指标名称: 数值 单位 (参考范围: 下限-上限 单位)
            #"([^:：\n]+)[：:]\s*([0-9.]+)\s*([^\s\(（]*)\s*[\(（]?参考范围?[：:]?\s*([0-9.-]+)\s*([^\)）]*)[\)）]?"#,
            // 匹配格式：指标名称 数值 单位 (参考范围: 下限-上限)
            #"([^0-9\n]+)\s+([0-9.]+)\s*([^\s\(（]*)\s*[\(（]?参考范围?[：:]?\s*([0-9.-]+)\s*([^\)）]*)[\)）]?"#,
            // 匹配格式：指标名称: 数值 (参考范围: 下限-上限)
            #"([^:：\n]+)[：:]\s*([0-9.]+)\s*[\(（]?参考范围?[：:]?\s*([0-9.-]+)[\)）]?"#
        ]
        
        for pattern in patterns {
            if let regex = try? NSRegularExpression(pattern: pattern, options: []) {
                let nsString = text as NSString
                let matches = regex.matches(in: text, options: [], range: NSRange(location: 0, length: nsString.length))
                
                for match in matches {
                    if match.numberOfRanges >= 4 {
                        let nameRange = match.range(at: 1)
                        let valueRange = match.range(at: 2)
                        
                        if nameRange.location != NSNotFound && valueRange.location != NSNotFound {
                            let name = nsString.substring(with: nameRange).trimmingCharacters(in: .whitespacesAndNewlines)
                            let value = nsString.substring(with: valueRange).trimmingCharacters(in: .whitespacesAndNewlines)
                            
                            var unit = ""
                            var range = ""
                            var isAbnormal = false
                            
                            // 提取单位（如果有）
                            if match.numberOfRanges > 3 && match.range(at: 3).location != NSNotFound {
                                unit = nsString.substring(with: match.range(at: 3)).trimmingCharacters(in: .whitespacesAndNewlines)
                            }
                            
                            // 提取参考范围（如果有）
                            if match.numberOfRanges > 4 && match.range(at: 4).location != NSNotFound {
                                let rangeValue = nsString.substring(with: match.range(at: 4)).trimmingCharacters(in: .whitespacesAndNewlines)
                                range = rangeValue
                                
                                // 判断是否异常（简单判断，可能需要更复杂的逻辑）
                                if let numValue = Double(value), rangeValue.contains("-") {
                                    let components = rangeValue.components(separatedBy: "-")
                                    if components.count == 2,
                                       let lower = Double(components[0].trimmingCharacters(in: .whitespacesAndNewlines)),
                                       let upper = Double(components[1].trimmingCharacters(in: .whitespacesAndNewlines)) {
                                        isAbnormal = numValue < lower || numValue > upper
                                    }
                                }
                            }
                            
                            let displayValue = unit.isEmpty ? value : "\(value) \(unit)"
                            indicators.append(KeyIndicator(name: name, value: displayValue, range: range, isAbnormal: isAbnormal))
                        }
                    }
                }
            }
        }
        
        // 如果没有找到指标，尝试查找"关键指标"或"异常指标"部分
        if indicators.isEmpty {
            let sections = text.components(separatedBy: "\n\n")
            for section in sections {
                if section.contains("关键指标") || section.contains("异常指标") {
                    let lines = section.components(separatedBy: "\n")
                    for line in lines {
                        if line.contains(":") || line.contains("：") {
                            let parts = line.components(separatedBy: CharacterSet(charactersIn: ":："))
                            if parts.count >= 2 {
                                let name = parts[0].trimmingCharacters(in: .whitespacesAndNewlines)
                                let valueAndRange = parts[1].trimmingCharacters(in: .whitespacesAndNewlines)
                                
                                // 简单处理，实际可能需要更复杂的解析
                                indicators.append(KeyIndicator(name: name, value: valueAndRange, range: "", isAbnormal: valueAndRange.contains("异常") || valueAndRange.contains("偏高") || valueAndRange.contains("偏低")))
                            }
                        }
                    }
                }
            }
        }
        
        return indicators
    }
}

// 创建格式化解读文本的组件
struct FormattedInterpretationText: View {
    let interpretation: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            ForEach(parseInterpretation(), id: \.self) { segment in
                if segment.isHeading {
                    // 显示为标题
                    Text(segment.content)
                        .font(.headline)
                        .foregroundColor(.primary)
                        .padding(.top, 8)
                } else if segment.isEmphasized {
                    // 强调文本，使用加粗而非放大
                    Text(segment.content)
                        .font(.body)
                        .fontWeight(.bold)
                        .foregroundColor(.primary)
                } else {
                    // 显示为正文
                    Text(segment.content)
                        .font(.body)
                        .foregroundColor(.primary)
                }
            }
        }
    }
    
    // 解析解读文本，识别 ## 格式的标题和 **强调** 格式
    private func parseInterpretation() -> [InterpretationSegment] {
        // 预处理文本，处理强调标记 **text**
        let processedText = processEmphasisMarkers(interpretation)
        
        let lines = processedText.components(separatedBy: "\n")
        var segments: [InterpretationSegment] = []
        var currentParagraph = ""
        
        for line in lines {
            if line.hasPrefix("##") {
                // 如果当前段落不为空，先添加到结果中
                if !currentParagraph.isEmpty {
                    segments.append(InterpretationSegment(content: currentParagraph, isHeading: false, isEmphasized: false))
                    currentParagraph = ""
                }
                
                // 添加标题，去掉前面的 ##
                let headingContent = line.replacingOccurrences(of: "##", with: "").trimmingCharacters(in: .whitespaces)
                segments.append(InterpretationSegment(content: headingContent, isHeading: true, isEmphasized: false))
            } else if line.contains("**EMPHASIS_START**") && line.contains("**EMPHASIS_END**") {
                // 如果当前段落不为空，先添加到结果中
                if !currentParagraph.isEmpty {
                    segments.append(InterpretationSegment(content: currentParagraph, isHeading: false, isEmphasized: false))
                    currentParagraph = ""
                }
                
                // 处理带有强调标记的行
                let parts = line.components(separatedBy: "**EMPHASIS_START**")
                
                if parts.count > 1 {
                    // 添加前部分（如果不为空）
                    let beforePart = parts[0].trimmingCharacters(in: .whitespaces)
                    if !beforePart.isEmpty {
                        segments.append(InterpretationSegment(content: beforePart, isHeading: false, isEmphasized: false))
                    }
                    
                    // 处理强调部分和后续部分
                    for i in 1..<parts.count {
                        let subParts = parts[i].components(separatedBy: "**EMPHASIS_END**")
                        if subParts.count > 1 {
                            // 强调部分
                            let emphasizedText = subParts[0].trimmingCharacters(in: .whitespaces)
                            if !emphasizedText.isEmpty {
                                segments.append(InterpretationSegment(content: emphasizedText, isHeading: false, isEmphasized: true))
                            }
                            
                            // 后续部分
                            let afterPart = subParts[1].trimmingCharacters(in: .whitespaces)
                            if !afterPart.isEmpty {
                                segments.append(InterpretationSegment(content: afterPart, isHeading: false, isEmphasized: false))
                            }
                        } else {
                            // 格式不完整，直接添加
                            if !parts[i].isEmpty {
                                segments.append(InterpretationSegment(content: parts[i], isHeading: false, isEmphasized: false))
                            }
                        }
                    }
                }
            } else if line.trimmingCharacters(in: .whitespaces).isEmpty {
                // 空行，结束当前段落
                if !currentParagraph.isEmpty {
                    segments.append(InterpretationSegment(content: currentParagraph, isHeading: false, isEmphasized: false))
                    currentParagraph = ""
                }
            } else {
                // 普通文本行
                if currentParagraph.isEmpty {
                    currentParagraph = line
                } else {
                    currentParagraph += "\n" + line
                }
            }
        }
        
        // 处理最后一个段落
        if !currentParagraph.isEmpty {
            segments.append(InterpretationSegment(content: currentParagraph, isHeading: false, isEmphasized: false))
        }
        
        return segments
    }
    
    // 处理强调标记 **text**，替换为特殊标记以便后续处理
    private func processEmphasisMarkers(_ text: String) -> String {
        var processedText = text
        
        // 使用正则表达式匹配 **text** 模式
        let pattern = "\\*\\*(.*?)\\*\\*"
        let regex = try? NSRegularExpression(pattern: pattern, options: [])
        let nsString = text as NSString
        let matches = regex?.matches(in: text, options: [], range: NSRange(location: 0, length: nsString.length))
        
        // 由于要替换文本，我们需要从后向前替换以避免位置变化
        matches?.reversed().forEach { match in
            if match.numberOfRanges > 1 {
                let range = match.range(at: 0) // 完整匹配（包括**）
                let contentRange = match.range(at: 1) // 内容（不包括**）
                
                if range.location != NSNotFound && contentRange.location != NSNotFound {
                    let matchedText = nsString.substring(with: range)
                    let content = nsString.substring(with: contentRange)
                    
                    // 替换为我们的特殊标记
                    let replacement = "**EMPHASIS_START**\(content)**EMPHASIS_END**"
                    processedText = processedText.replacingOccurrences(of: matchedText, with: replacement)
                }
            }
        }
        
        return processedText
    }
}

// 解读文本段落结构
struct InterpretationSegment: Hashable {
    let content: String
    let isHeading: Bool
    let isEmphasized: Bool
}

// 关键指标模型
struct KeyIndicator {
    let name: String
    let value: String
    let range: String
    let isAbnormal: Bool
}

struct RecordingRow: View {
    let recording: Recording
    let onDelete: () -> Void
    @State private var showingDeleteAlert = false
    @State private var navigateToDetail = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(recording.name)
                    .font(.headline)
                Spacer()
                
                Text(formatDate(recording.date))
                    .font(.subheadline)
                    .foregroundColor(.gray)
                
                // 移动箭头到日期右边
                Image(systemName: "chevron.right")
                    .foregroundColor(.gray)
            }
            
            Divider()
        }
        .padding(.vertical, 8)
        .contentShape(Rectangle())
        .onTapGesture {
            navigateToDetail = true
        }
        .onLongPressGesture {
            showingDeleteAlert = true
        }
        .alert("删除录音", isPresented: $showingDeleteAlert) {
            Button("删除", role: .destructive) {
                onDelete()
            }
            Button("取消", role: .cancel) { }
        } message: {
            Text("确定要删除这条录音记录吗？此操作不可撤销。")
        }
        .background(
            NavigationLink(
                destination: RecordingDetailView(recording: recording),
                isActive: $navigateToDetail
            ) {
                EmptyView()
            }
            .opacity(0)
        )
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy年MM月dd日 HH:mm:ss"
        return formatter.string(from: date)
    }
}

class AudioPlayerDelegate: NSObject, AVAudioPlayerDelegate {
    let onFinish: () -> Void
    
    init(onFinish: @escaping () -> Void) {
        self.onFinish = onFinish
        super.init()
    }
    
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        DispatchQueue.main.async {
            self.onFinish()
        }
    }
    
    func audioPlayerDecodeErrorDidOccur(_ player: AVAudioPlayer, error: Error?) {
        if let error = error {
            print("音频解码错误: \(error.localizedDescription)")
        }
    }
}



struct Recording: Codable, Identifiable, Hashable {
    let id: UUID
    let recordId: UUID  // 添加关联的病历ID
    let name: String
    let date: Date
    let audioURL: URL
    let conversation: [ConversationSegment]
    
    // 添加 Hashable 协议实现
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    static func == (lhs: Recording, rhs: Recording) -> Bool {
        lhs.id == rhs.id
    }
}

class RecordingStorage {
    static let shared = RecordingStorage()
    private let defaults = UserDefaults.standard
    private let key = "savedRecordings"
    
    func saveRecordings(_ recordings: [Recording]) {
        // 确保录音ID唯一
        let uniqueIds = Set(recordings.map { $0.id })
        var uniqueRecordings: [Recording] = []
        
        // 确保每个ID只保留一个录音
        for id in uniqueIds {
            if let recording = recordings.first(where: { $0.id == id }) {
                uniqueRecordings.append(recording)
            }
        }
        
        let recordingsToSave = uniqueRecordings.map { recording -> [String: Any] in
            [
                "id": recording.id.uuidString,
                "recordId": recording.recordId.uuidString,
                "name": recording.name,
                "date": recording.date,
                "audioURL": recording.audioURL.lastPathComponent,
                "conversation": recording.conversation.map { segment in
                    [
                        "speaker": segment.speaker,
                        "content": segment.content,
                        "timestamp": segment.timestamp
                    ]
                }
            ]
        }
        
        defaults.set(recordingsToSave, forKey: key)
    }
    
    func loadRecordings() -> [Recording] {
        guard let savedData = defaults.object(forKey: key) as? [[String: Any]] else {
            return []
        }
        
        return savedData.compactMap { data -> Recording? in
            guard
                let idString = data["id"] as? String,
                let id = UUID(uuidString: idString),
                let recordIdString = data["recordId"] as? String,
                let recordId = UUID(uuidString: recordIdString),
                let name = data["name"] as? String,
                let date = data["date"] as? Date,
                let audioFileName = data["audioURL"] as? String,
                let conversationData = data["conversation"] as? [[String: Any]]
            else {
                return nil
            }
            
            let audioURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
                .appendingPathComponent(audioFileName)
            
            let conversation = conversationData.compactMap { segmentData -> ConversationSegment? in
                guard
                    let speaker = segmentData["speaker"] as? String,
                    let content = segmentData["content"] as? String,
                    let timestamp = segmentData["timestamp"] as? Date
                else {
                    return nil
                }
                
                return ConversationSegment(
                    speaker: speaker,
                    content: content,
                    timestamp: timestamp
                )
            }
            
            return Recording(
                id: id,
                recordId: recordId,
                name: name,
                date: date,
                audioURL: audioURL,
                conversation: conversation
            )
        }
    }
    
    func deleteRecording(_ recording: Recording) {
        // 删除音频文件
        try? FileManager.default.removeItem(at: recording.audioURL)
        
        // 删除元数据
        var recordings = loadRecordings()
        recordings.removeAll { $0.id == recording.id }
        saveRecordings(recordings)
    }
    
    // 添加按病历ID加载录音的方法
    func loadRecordings(for recordId: UUID) -> [Recording] {
        let allRecordings = loadRecordings()
        
        // 过滤并去重
        let filteredRecordings = allRecordings.filter { $0.recordId == recordId }
        let uniqueIds = Set(filteredRecordings.map { $0.id })
        
        // 确保每个ID只保留一个录音
        var uniqueRecordings: [Recording] = []
        for id in uniqueIds {
            if let recording = filteredRecordings.first(where: { $0.id == id }) {
                uniqueRecordings.append(recording)
            }
        }
        
        return uniqueRecordings
    }
}

// 添加 OrderRow 视图组件
struct OrderRow: View {
    let order: DoctorOrder
    let onDelete: () -> Void
    @State private var showingDeleteAlert = false
    @State private var showingFullScreenImage = false
    @State private var showingOrderDetail = false
    
    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            // 修改图片大小为 70x70
            if let imageData = order.imageData,
               let uiImage = UIImage(data: imageData) {
                Image(uiImage: uiImage)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 70, height: 70)  // 修改为70x70
                    .clipShape(RoundedRectangle(cornerRadius: 8))
                    .overlay(
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(Color.gray.opacity(0.2), lineWidth: 1)
                    )
            }
            
            VStack(alignment: .leading, spacing: 4) {
                // 只显示前20个字符，超出部分显示省略号
                Text(order.content.count > 20 ? String(order.content.prefix(20)) + "..." : order.content)
                    .lineLimit(1)
                
                Text(formatDate(order.date))
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
            
            Spacer()
            
            Image(systemName: "chevron.right")
                .foregroundColor(.gray)
                .font(.system(size: 14))
        }
        .padding(.vertical, 8)
        .contentShape(Rectangle())
        .onTapGesture {
            // 点击整行时显示医嘱详情
            showingOrderDetail = true
        }
        .onLongPressGesture {
            showingDeleteAlert = true
        }
        .alert("删除医嘱", isPresented: $showingDeleteAlert) {
            Button("删除", role: .destructive) {
                onDelete()
            }
            Button("取消", role: .cancel) { }
        } message: {
            Text("确定要删除这条医嘱吗？此操作不可撤销。")
        }
        .fullScreenCover(isPresented: $showingFullScreenImage) {
            if let imageData = order.imageData,
               let uiImage = UIImage(data: imageData) {
                ZStack {
                    Color.black.ignoresSafeArea()
                    
                    Image(uiImage: uiImage)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                    
                    VStack {
                        HStack {
                            Spacer()
                            Button(action: {
                                showingFullScreenImage = false
                            }) {
                                Image(systemName: "xmark.circle.fill")
                                    .font(.title)
                                    .foregroundColor(.white)
                                    .padding()
                            }
                        }
                        Spacer()
                    }
                }
                .statusBar(hidden: true)
            }
        }
        .sheet(isPresented: $showingOrderDetail) {
            OrderDetailView(order: order)
        }
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy年MM月dd日 HH:mm:ss"
        return formatter.string(from: date)
    }
}

// 修改编辑视图
struct EditMedicalRecordView: View {
    let record: MedicalRecord
    @Environment(\.dismiss) private var dismiss
    @State private var hospital: String
    @State private var department: String
    @State private var symptoms: String
    @State private var hospitalAddress: String
    @State private var medicationTimes: [String]
    @State private var dailyDoses: Int
    let onSave: (MedicalRecord) -> Void
    
    // 初始化器，使用现有记录的值
    init(record: MedicalRecord, onSave: @escaping (MedicalRecord) -> Void) {
        self.record = record
        _hospital = State(initialValue: record.hospital)
        _department = State(initialValue: record.department)
        _symptoms = State(initialValue: record.symptoms)
        _hospitalAddress = State(initialValue: record.hospitalAddress)
        _medicationTimes = State(initialValue: record.medicationTimes)
        _dailyDoses = State(initialValue: record.dailyDoses)
        self.onSave = onSave
    }
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("基本信息")) {
                    TextField("医院", text: $hospital)
                    TextField("科室", text: $department)
                    Text("就诊时间：\(formatDate(record.date))")
                }
                
                Section(header: Text("症状描述")) {
                    TextEditor(text: $symptoms)
                        .frame(minHeight: 100)
                }
            }
            .navigationTitle("编辑病例")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("取消") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("保存") {
                        saveMedicalRecord()
                        dismiss()
                    }
                }
            }
        }
    }
    
    private func saveMedicalRecord() {
        // 创建新的病历记录
        let updatedRecord = MedicalRecord(
            id: record.id,
            date: record.date,
            hospital: hospital,
            department: department,
            symptoms: symptoms,
            hospitalAddress: hospitalAddress,
            medicationTimes: medicationTimes,
            dailyDoses: dailyDoses
        )
        
        // 更新存储
        var records = MedicalRecordStorage.shared.loadRecords()
        if let index = records.firstIndex(where: { $0.id == updatedRecord.id }) {
            records[index] = updatedRecord
            MedicalRecordStorage.shared.saveRecords(records)
        }
        
        // 调用保存回调
        onSave(updatedRecord)
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy年MM月dd日 HH:mm:ss"
        return formatter.string(from: date)
    }
}

// 添加 TextEditor 的占位符扩展
extension View {
    func placeholder<Content: View>(
        when shouldShow: Bool,
        alignment: Alignment = .leading,
        @ViewBuilder placeholder: () -> Content) -> some View {
        
        ZStack(alignment: alignment) {
            placeholder().opacity(shouldShow ? 1 : 0)
            self
        }
    }
}

// 添加 OrderDetailView 组件
struct OrderDetailView: View {
    let order: DoctorOrder
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    // 如果有图片，显示图片
                    if let imageData = order.imageData,
                       let uiImage = UIImage(data: imageData) {
                        Image(uiImage: uiImage)
                            .resizable()
                            .scaledToFit()
                            .frame(maxWidth: .infinity)
                            .cornerRadius(12)
                            .padding(.bottom, 10)
                    }
                    
                    // 医嘱内容
                    VStack(alignment: .leading, spacing: 15) {
                        Text("医嘱内容")
                            .font(.headline)
                            .foregroundColor(.gray)
                        
                        Text(order.content)
                            .font(.body)
                            .fixedSize(horizontal: false, vertical: true)
                            .padding()
                            .background(Color.gray.opacity(0.1))
                            .cornerRadius(8)
                    }
                    
                    // 诊断信息（如果有）
                    if let diagnosis = order.diagnosis {
                        VStack(alignment: .leading, spacing: 15) {
                            Text("诊断")
                                .font(.headline)
                                .foregroundColor(.gray)
                            
                            Text(diagnosis)
                                .font(.body)
                                .padding()
                                .background(Color.gray.opacity(0.1))
                                .cornerRadius(8)
                        }
                    }
                    
                    // 医嘱建议（如果有）
                    if let recommendations = order.recommendations {
                        VStack(alignment: .leading, spacing: 15) {
                            Text("医生建议")
                                .font(.headline)
                                .foregroundColor(.gray)
                            
                            Text(recommendations)
                                .font(.body)
                                .padding()
                                .background(Color.gray.opacity(0.1))
                                .cornerRadius(8)
                        }
                    }
                    
                    // 时间信息
                    VStack(alignment: .leading, spacing: 15) {
                        Text("开具时间")
                            .font(.headline)
                            .foregroundColor(.gray)
                        
                        Text(formatDate(order.date))
                            .font(.body)
                            .padding()
                            .background(Color.gray.opacity(0.1))
                            .cornerRadius(8)
                    }
                }
                .padding()
            }
            .navigationTitle("医嘱详情")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("关闭") {
                        dismiss()
                    }
                }
            }
        }
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy年MM月dd日 HH:mm:ss"
        return formatter.string(from: date)
    }
}

