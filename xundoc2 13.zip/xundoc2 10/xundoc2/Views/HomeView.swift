import SwiftUI

struct DateHeaderView: View {
    @State private var currentDate = Date()
    @EnvironmentObject private var languageManager: LanguageManager
    
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(weekdayString)
                .fontWeight(.bold)
                .font(.system(size: 40, weight: .medium))
            Text(dateString)
                .fontWeight(.bold)
                .font(.system(size: 25))
        }
        .localized()
    }
    
    private var weekdayString: String {
        let weekday = Calendar.current.component(.weekday, from: currentDate)
        let weekdayKey: String
        
        switch weekday {
        case 1: weekdayKey = "sunday"
        case 2: weekdayKey = "monday"
        case 3: weekdayKey = "tuesday"
        case 4: weekdayKey = "wednesday"
        case 5: weekdayKey = "thursday"
        case 6: weekdayKey = "friday"
        case 7: weekdayKey = "saturday"
        default: weekdayKey = "monday"
        }
        
        return NSLocalizedString(weekdayKey, comment: "")
    }
    
    private var dateString: String {
        let formatter = DateFormatter()
        formatter.dateFormat = NSLocalizedString("date_format", comment: "")
        return formatter.string(from: currentDate)
    }
}

struct HomeView: View {
    @ObservedObject var reminderManager: ReminderManager
    @EnvironmentObject private var languageManager: LanguageManager
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    // 顶部布局
                    HStack {
                        DateHeaderView()
                        Spacer()
                    }
                    .padding(.horizontal)
                    
                    // 健康数据卡片
                    HealthDataCard()
                        .padding(.horizontal)
                    
                    // 今日提醒部分
                    Group {
                        if !uncompletedTodayReminders.isEmpty {
                            ReminderSection(reminderManager: reminderManager)
                                .padding(.horizontal)
                        } else {
                            EmptyStateView()
                                .padding(.horizontal)
                        }
                    }
                    
                    // 常用功能部分
                    // 这里可以添加其他功能模块
                }
                .padding(.top)
            }
            .navigationBarHidden(true)
            .localized()
        }
        .id(languageManager.refreshToken)
    }
    
    // 新增计算属性：获取今天未完成的提醒
    private var uncompletedTodayReminders: [Reminder] {
        let calendar = Calendar.current
        let today = calendar.startOfDay(for: Date())
        let tomorrow = calendar.date(byAdding: .day, value: 1, to: today)!
        
        return reminderManager.reminders.filter { reminder in
            if let reminderDate = calendar.date(from: calendar.dateComponents([.year, .month, .day], from: reminder.date)) {
                return reminderDate >= today && 
                       reminderDate < tomorrow && 
                       !reminder.isCompleted  // 只显示未完成的提醒
            }
            return false
        }
    }
}

// 空状态视图
struct EmptyStateView: View {
    @State private var isNightTime: Bool = {
        let hour = Calendar.current.component(.hour, from: Date())
        return hour < 6 || hour >= 18
    }()
    @EnvironmentObject private var languageManager: LanguageManager
    
    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: isNightTime ? "moon.stars.fill" : "sun.max.fill")
                .font(.system(size: 40))
                .foregroundColor(.primary)
            
            Text(NSLocalizedString("no_reminders_today", comment: ""))
                .font(.system(size: 14))
                .foregroundColor(.gray)
        }
        .padding(.vertical, 30)
        .localized()
    }
}

// 提醒部分组件

#Preview {
    HomeView(reminderManager: ReminderManager())
}
