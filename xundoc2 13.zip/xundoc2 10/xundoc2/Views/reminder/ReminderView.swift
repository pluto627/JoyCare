import SwiftUI

struct ReminderView: View {
    @StateObject var reminderManager: ReminderManager
    @State private var showingAddView = false
    @Environment(\.colorScheme) private var colorScheme
    @EnvironmentObject private var languageManager: LanguageManager
    
    // 添加一个计算属性来对提醒进行分组
    private var groupedReminders: [String: [Reminder]] {
        // 首先按照时间倒序排序所有提醒
        let sortedReminders = reminderManager.reminders.sorted(by: { $0.date > $1.date })
        
        // 然后进行分组
        return Dictionary(grouping: sortedReminders) { reminder in
            if reminder.type == "用药提醒" {
                // 用药提醒按药品名称分组
                return reminder.title
            } else {
                // 其他类型的提醒保持独立
                return reminder.id.uuidString
            }
        }
    }
    
    var body: some View {
        NavigationView {
            ZStack(alignment: .top) {
                Color(UIColor.systemGray6)
                    .ignoresSafeArea()
                
                VStack(spacing: -60) {
                    // 标题栏背景延伸到顶部
                    Color(red: 0.4, green: 0.3, blue: 0.9)
                        .frame(height: 135)
                        .ignoresSafeArea(edges: .top)
                    
                    ScrollView {
                        VStack(spacing: 20) {
                            // 如果没有提醒，显示添加提醒的引导
                            if reminderManager.reminders.isEmpty {
                                VStack(spacing: 20) {
                                    VStack(spacing: 10) {
                                        ForEach(0..<9) { _ in
                                            Text("")
                                                .foregroundColor(.gray)
                                        }
                                        Text(NSLocalizedString("add_event", comment: ""))
                                            .foregroundColor(.gray)
                                        Text(NSLocalizedString("set_reminder_time", comment: ""))
                                            .foregroundColor(.gray)
                                    }
                                    
                                    Button(action: {
                                        showingAddView = true
                                    }) {
                                        HStack {
                                            Image(systemName: "plus")
                                            Text(NSLocalizedString("add_event", comment: ""))
                                        }
                                        .font(.system(size: 17))
                                        .foregroundColor(.white)
                                        .frame(maxWidth: .infinity)
                                        .frame(height: 56)
                                        .background(Color(white: 0.2))
                                        .cornerRadius(16)
                                        .padding(.horizontal, 20)
                                    }
                                }
                                .padding(.top, 30)
                            } else {
                                // 修改提醒列表的显示逻辑
                                VStack(spacing: 16) {
                                    // 使用groupedReminders.keys按照第一个提醒的时间进行排序
                                    ForEach(Array(groupedReminders.keys).sorted(by: {
                                        let date1 = groupedReminders[$0]?.first?.date ?? Date.distantPast
                                        let date2 = groupedReminders[$1]?.first?.date ?? Date.distantPast
                                        return date1 > date2 // 倒序排序
                                    }), id: \.self) { key in
                                        if let reminders = groupedReminders[key] {
                                            if reminders[0].type == "用药提醒" {
                                                // 用药提醒显示合并后的视图，内部也按时间倒序排列
                                                ReminderViewItem(
                                                    reminder: reminders[0],
                                                    allReminders: reminders.sorted(by: { $0.date > $1.date }), // 倒序排序
                                                    reminderManager: reminderManager
                                                )
                                            } else {
                                                // 其他类型的提醒正常显示
                                                ReminderViewItem(
                                                    reminder: reminders[0],
                                                    allReminders: [reminders[0]],
                                                    reminderManager: reminderManager
                                                )
                                            }
                                        }
                                    }
                                }
                                .padding(.horizontal, 16)
                                .padding(.top, 20)
                                .animation(.default, value: reminderManager.reminders)
                            }
                        }
                    }
                }
                
                // 顶部导航栏 - 使用VStack分离加号按钮和健康提醒文本
                VStack(alignment: .leading, spacing: 0) {
                    // 加号按钮，放在顶部
                    HStack {
                        Spacer()
                        Button(action: {
                            showingAddView = true
                        }) {
                            Image(systemName: "plus")
                                .font(.system(size: 25))
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                        }
                    }
                    .padding(.top, 12)
                    .padding(.trailing)
                    
                    // 健康提醒文本，放在加号下方，靠左对齐
                    Text(NSLocalizedString("health_reminders", comment: ""))
                        .font(.title)
                        .bold()
                        .foregroundColor(.white)
                        .padding(.leading)
                        .padding(.top, -1)
                }
            }
            .navigationBarHidden(true)
            .sheet(isPresented: $showingAddView) {
                SelectReminderTypeView(reminderManager: reminderManager)
                    .presentationDetents([.medium])
                    .presentationDragIndicator(.visible)
            }
            .localized()
            .onAppear {
                // 每次出现时请求通知权限
                UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { _, _ in }
            }
        }
        .id(languageManager.refreshToken)
    }
}

#Preview {
    ReminderView(reminderManager: ReminderManager())
}
