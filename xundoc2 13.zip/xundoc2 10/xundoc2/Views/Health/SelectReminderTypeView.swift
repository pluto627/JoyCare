import SwiftUI

struct SelectReminderTypeView: View {
    @Environment(\.dismiss) var dismiss
    @ObservedObject var reminderManager: ReminderManager
    @State private var selectedType: String?
    @State private var showAddReminderView = false
    
    let reminderTypes = [
        (NSLocalizedString("medication", comment: ""), "pill", NSLocalizedString("medication_reminder", comment: ""), Color.blue),
        (NSLocalizedString("exercise", comment: ""), "figure.walk", NSLocalizedString("exercise_reminder", comment: ""), Color.green),
        (NSLocalizedString("water", comment: ""), "drop.fill", NSLocalizedString("water_reminder", comment: ""), Color.blue),
        (NSLocalizedString("sleep", comment: ""), "moon.zzz.fill", NSLocalizedString("sleep_reminder", comment: ""), Color.purple),
        (NSLocalizedString("posture", comment: ""), "person.fill", NSLocalizedString("posture_reminder", comment: ""), Color.orange),
        (NSLocalizedString("eye_care", comment: ""), "eye.fill", NSLocalizedString("eye_care_reminder", comment: ""), Color.blue),
        (NSLocalizedString("oral_care", comment: ""), "mouth.fill", NSLocalizedString("oral_care_reminder", comment: ""), Color.red),
        (NSLocalizedString("skin_care", comment: ""), "hand.raised.fill", NSLocalizedString("skin_care_reminder", comment: ""), Color.gray),
        (NSLocalizedString("follow_up", comment: ""), "cross.case.fill", NSLocalizedString("follow_up_reminder", comment: ""), Color.red),
        (NSLocalizedString("custom", comment: ""), "plus", NSLocalizedString("custom_reminder", comment: ""), Color.purple)
    ]
    
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    // 添加一个计算属性来处理视图选择
    @ViewBuilder
    private var destinationView: some View {
        if let type = selectedType {
            switch type {
            case NSLocalizedString("medication_reminder", comment: ""):
                AddMedicineReminderView(reminderManager: reminderManager)
            case NSLocalizedString("exercise_reminder", comment: ""):
                AddExerciseReminderView(reminderManager: reminderManager)
            case NSLocalizedString("water_reminder", comment: ""):
                AddWaterReminderView(reminderManager: reminderManager)
            case NSLocalizedString("sleep_reminder", comment: ""):
                AddSleepReminderView(reminderManager: reminderManager)
            case NSLocalizedString("posture_reminder", comment: ""), 
                 NSLocalizedString("eye_care_reminder", comment: ""),
                 NSLocalizedString("oral_care_reminder", comment: ""), 
                 NSLocalizedString("skin_care_reminder", comment: ""):
                AddPersonalCareReminderView(reminderManager: reminderManager, reminderType: type)
            case NSLocalizedString("follow_up_reminder", comment: ""):
                AddFollowUpReminderView(reminderManager: reminderManager)
            case NSLocalizedString("custom_reminder", comment: ""):
                AddCustomReminderView(reminderManager: reminderManager)
            default:
                AddCustomReminderView(reminderManager: reminderManager)
            }
        } else {
            EmptyView()
        }
    }
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text(NSLocalizedString("select_reminder_type", comment: ""))
                    .font(.title2)
                    .fontWeight(.bold)
                
                LazyVGrid(columns: columns, spacing: 20) {
                    ForEach(reminderTypes, id: \.0) { type in
                        ReminderTypeButton(
                            title: type.0,
                            icon: type.1,
                            color: type.3,
                            isSelected: selectedType == type.2
                        ) {
                            selectedType = type.2
                            showAddReminderView = true
                        }
                    }
                }
                .padding()
                
                Spacer()
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(NSLocalizedString("cancel", comment: "")) {
                        dismiss()
                    }
                }
            }
            .fullScreenCover(isPresented: $showAddReminderView) {
                destinationView
            }
        }
    }
}

struct ReminderTypeButton: View {
    let title: String
    let icon: String
    let color: Color
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack {
                ZStack {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(color.opacity(0.15))
                        .frame(width: 60, height: 60)
                    
                    Image(systemName: icon)
                        .font(.system(size: 24))
                        .foregroundColor(color)
                }
                
                Text(title)
                    .font(.system(size: 12))
                    .foregroundColor(.primary)
            }
        }
        .padding(4)
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(isSelected ? color.opacity(0.1) : Color.clear)
        )
    }
}
