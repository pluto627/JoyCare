import SwiftUI
import Foundation

struct AddPersonalCareReminderView: View {
    @Environment(\.dismiss) var dismiss
    @ObservedObject var reminderManager: ReminderManager
    
    let reminderType: String
    
    // 基本信息
    @State private var reminderTitle = ""
    @State private var selectedTime = Date()
    @State private var selectedFrequency = "每天"
    @State private var customDays = 1
    @State private var customHours = 1
    @State private var intervalHours = 2 // 默认2小时提醒一次
    
    // 提醒详情
    @State private var duration = 5 // 默认5分钟
    @State private var careDetails = ""
    @State private var repeatTimes = 1 // 默认每天提醒次数
    @State private var startTime = Calendar.current.date(bySettingHour: 9, minute: 0, second: 0, of: Date()) ?? Date()
    @State private var endTime = Calendar.current.date(bySettingHour: 18, minute: 0, second: 0, of: Date()) ?? Date()
    
    let frequencyOptions = ["每天", "每小时", "每隔几小时", "自定义"]
    let durationOptions = [1, 2, 3, 5, 10, 15, 20]
    
    // 设置提醒类型标题和默认值
    init(reminderManager: ReminderManager, reminderType: String) {
        self.reminderManager = reminderManager
        self.reminderType = reminderType
        
        // 根据不同类型设置默认标题
        let title: String
        switch reminderType {
        case NSLocalizedString("posture_reminder", comment: ""):
            title = "坐姿提醒"
        case NSLocalizedString("eye_care_reminder", comment: ""):
            title = "护眼提醒"
        case NSLocalizedString("oral_care_reminder", comment: ""):
            title = "口腔护理提醒"
        case NSLocalizedString("skin_care_reminder", comment: ""):
            title = "皮肤护理提醒"
        default:
            title = "个人护理提醒"
        }
        
        // 使用 _变量名 来设置 @State 的初始值
        _reminderTitle = State(initialValue: title)
    }
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("基本信息")) {
                    TextField("提醒标题", text: $reminderTitle)
                    
                    if selectedFrequency == "每天" {
                        DatePicker("提醒时间", selection: $selectedTime, displayedComponents: .hourAndMinute)
                    } else if selectedFrequency == "每小时" || selectedFrequency == "每隔几小时" {
                        DatePicker("开始时间", selection: $startTime, displayedComponents: .hourAndMinute)
                        DatePicker("结束时间", selection: $endTime, displayedComponents: .hourAndMinute)
                        
                        if selectedFrequency == "每隔几小时" {
                            Stepper("每\(intervalHours)小时", value: $intervalHours, in: 1...12)
                        }
                    }
                }
                
                Section(header: Text("护理详情")) {
                    Picker("持续时间", selection: $duration) {
                        ForEach(durationOptions, id: \.self) { time in
                            Text("\(time)分钟").tag(time)
                        }
                    }
                    
                    if reminderType == NSLocalizedString("posture_reminder", comment: "") {
                        Text("提醒纠正坐姿，保持颈椎和脊椎健康")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    } else if reminderType == NSLocalizedString("eye_care_reminder", comment: "") {
                        Text("提醒休息眼睛，远眺放松")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    } else if reminderType == NSLocalizedString("oral_care_reminder", comment: "") {
                        Text("提醒刷牙、漱口或使用牙线")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    } else if reminderType == NSLocalizedString("skin_care_reminder", comment: "") {
                        Text("提醒护肤步骤和时间")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    
                    TextEditor(text: $careDetails)
                        .frame(minHeight: 100)
                        .placeholder(when: careDetails.isEmpty) {
                            Text("添加护理详情...")
                                .foregroundColor(.gray)
                                .padding(.top, 8)
                                .padding(.leading, 5)
                        }
                }
                
                Section(header: Text("提醒频率")) {
                    Picker("重复", selection: $selectedFrequency) {
                        ForEach(frequencyOptions, id: \.self) { option in
                            Text(option).tag(option)
                        }
                    }
                    
                    if selectedFrequency == "自定义" {
                        Stepper("每\(customDays)天", value: $customDays, in: 1...30)
                    }
                }
            }
            .navigationTitle(getTypeTitle())
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("取消") {
                        dismiss()
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("保存") {
                        saveReminder()
                    }
                    .disabled(reminderTitle.isEmpty)
                }
            }
        }
    }
    
    private func getTypeTitle() -> String {
        switch reminderType {
        case NSLocalizedString("posture_reminder", comment: ""):
            return "添加坐姿提醒"
        case NSLocalizedString("eye_care_reminder", comment: ""):
            return "添加护眼提醒"
        case NSLocalizedString("oral_care_reminder", comment: ""):
            return "添加口腔护理提醒"
        case NSLocalizedString("skin_care_reminder", comment: ""):
            return "添加皮肤护理提醒"
        default:
            return "添加个人护理提醒"
        }
    }
    
    private func getTypeDescription() -> String {
        switch reminderType {
        case NSLocalizedString("posture_reminder", comment: ""):
            return "保持良好坐姿，避免颈椎和腰椎问题"
        case NSLocalizedString("eye_care_reminder", comment: ""):
            return "保护眼睛，避免疲劳和干涩"
        case NSLocalizedString("oral_care_reminder", comment: ""):
            return "保持口腔卫生，预防牙龈问题"
        case NSLocalizedString("skin_care_reminder", comment: ""):
            return "护理皮肤，保持健康与活力"
        default:
            return "定期自我护理，保持身体健康"
        }
    }
    
    private func formatTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        return formatter.string(from: date)
    }
    
    private func saveReminder() {
        // 构建详细描述字符串
        var description = "持续时间：\(duration)分钟\n类型：\(getTypeTitle().replacingOccurrences(of: "添加", with: ""))"
        
        if !careDetails.isEmpty {
            description += "\n详情：\(careDetails)"
        } else {
            description += "\n建议：\(getTypeDescription())"
        }
        
        // 确定重复模式
        let repeatPattern: String?
        switch selectedFrequency {
        case "每天":
            repeatPattern = "daily"
            // 创建单次提醒
            createSingleReminder(at: selectedTime, with: description, and: repeatPattern)
        case "每小时":
            // 创建每小时提醒
            createHourlyReminders(with: description)
        case "每隔几小时":
            // 创建每隔几小时的提醒
            createIntervalReminders(with: description, interval: intervalHours)
        case "自定义":
            repeatPattern = "custom_\(customDays)"
            // 创建单次提醒，自定义重复天数
            createSingleReminder(at: selectedTime, with: description, and: repeatPattern)
        default:
            repeatPattern = nil
            // 创建单次提醒，不重复
            createSingleReminder(at: selectedTime, with: description, and: repeatPattern)
        }
        
        // 关闭视图
        dismiss()
    }
    
    private func createSingleReminder(at time: Date, with description: String, and repeatPattern: String?) {
        let reminder = Reminder(
            title: reminderTitle,
            date: time,
            description: description,
            type: reminderType,
            repeatPattern: repeatPattern
        )
        
        reminderManager.addReminder(reminder)
    }
    
    private func createHourlyReminders(with description: String) {
        let calendar = Calendar.current
        let startComponents = calendar.dateComponents([.hour, .minute], from: startTime)
        let endComponents = calendar.dateComponents([.hour, .minute], from: endTime)
        
        guard let startHour = startComponents.hour,
              let startMinute = startComponents.minute,
              let endHour = endComponents.hour,
              let endMinute = endComponents.minute else {
            return
        }
        
        let startTimeInMinutes = startHour * 60 + startMinute
        let endTimeInMinutes = endHour * 60 + endMinute
        
        // 如果结束时间早于或等于开始时间，则不创建提醒
        if endTimeInMinutes <= startTimeInMinutes {
            return
        }
        
        // 创建整点提醒
        var currentHour = startHour
        while currentHour <= endHour {
            let minute = (currentHour == startHour) ? startMinute : 0
            let endMinuteForHour = (currentHour == endHour) ? endMinute : 59
            
            if minute <= endMinuteForHour {
                if let reminderDate = calendar.date(bySettingHour: currentHour, minute: minute, second: 0, of: Date()) {
                    createSingleReminder(at: reminderDate, with: description, and: "daily")
                }
            }
            
            currentHour += 1
        }
    }
    
    private func createIntervalReminders(with description: String, interval: Int) {
        let calendar = Calendar.current
        let startComponents = calendar.dateComponents([.hour, .minute], from: startTime)
        let endComponents = calendar.dateComponents([.hour, .minute], from: endTime)
        
        guard let startHour = startComponents.hour,
              let startMinute = startComponents.minute,
              let endHour = endComponents.hour,
              let endMinute = endComponents.minute else {
            return
        }
        
        let startTimeInMinutes = startHour * 60 + startMinute
        let endTimeInMinutes = endHour * 60 + endMinute
        
        // 如果结束时间早于或等于开始时间，则不创建提醒
        if endTimeInMinutes <= startTimeInMinutes {
            return
        }
        
        // 在指定的时间范围内创建提醒
        var currentTimeInMinutes = startTimeInMinutes
        while currentTimeInMinutes < endTimeInMinutes {
            let hour = currentTimeInMinutes / 60
            let minute = currentTimeInMinutes % 60
            
            if let reminderDate = calendar.date(bySettingHour: hour, minute: minute, second: 0, of: Date()) {
                createSingleReminder(at: reminderDate, with: description, and: "daily")
            }
            
            // 增加时间间隔
            currentTimeInMinutes += interval * 60
        }
    }
}

