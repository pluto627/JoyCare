import SwiftUI

struct AddExerciseReminderView: View {
    @Environment(\.dismiss) var dismiss
    @ObservedObject var reminderManager: ReminderManager
    
    // 基本信息
    @State private var exerciseName = ""
    @State private var selectedTime = Date()
    @State private var selectedDuration = 30 // 默认30分钟
    @State private var selectedFrequency = "每天"
    @State private var customDays = 1
    
    // 运动详情
    @State private var exerciseType = "有氧运动"
    @State private var exerciseIntensity = "中等"
    @State private var calorieGoal = ""
    @State private var exerciseNotes = ""
    
    let exerciseTypes = ["有氧运动", "力量训练", "柔韧性训练", "平衡训练", "瑜伽", "其他"]
    let intensityLevels = ["低", "中等", "高"]
    let frequencyOptions = ["每天", "隔天", "每周", "自定义"]
    let durationOptions = Array(5...180).filter { $0 % 5 == 0 } // 5到180分钟，步长为5
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("基本信息")) {
                    TextField("运动名称", text: $exerciseName)
                    DatePicker("提醒时间", selection: $selectedTime, displayedComponents: .hourAndMinute)
                }
                
                Section(header: Text("运动详情")) {
                    Picker("运动类型", selection: $exerciseType) {
                        ForEach(exerciseTypes, id: \.self) { type in
                            Text(type).tag(type)
                        }
                    }
                    
                    Picker("运动强度", selection: $exerciseIntensity) {
                        ForEach(intensityLevels, id: \.self) { level in
                            Text(level).tag(level)
                        }
                    }
                    
                    Picker("持续时间", selection: $selectedDuration) {
                        ForEach(durationOptions, id: \.self) { duration in
                            Text("\(duration)分钟").tag(duration)
                        }
                    }
                    
                    TextField("卡路里目标 (可选)", text: $calorieGoal)
                        .keyboardType(.numberPad)
                }
                
                Section(header: Text("提醒频率")) {
                    Picker("重复", selection: $selectedFrequency) {
                        ForEach(frequencyOptions, id: \.self) { option in
                            Text(option).tag(option)
                        }
                    }
                    
                    if selectedFrequency == "自定义" {
                        Stepper("每\(customDays)天", value: $customDays, in: 1...30)
                    }
                }
                
                Section(header: Text("备注")) {
                    TextEditor(text: $exerciseNotes)
                        .frame(minHeight: 100)
                }
            }
            .navigationTitle("添加运动提醒")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("取消") {
                        dismiss()
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("保存") {
                        saveReminder()
                    }
                    .disabled(exerciseName.isEmpty)
                }
            }
        }
    }
    
    private func saveReminder() {
        // 构建详细描述字符串
        var description = "类型：\(exerciseType)\n强度：\(exerciseIntensity)\n时长：\(selectedDuration)分钟"
        
        if !calorieGoal.isEmpty {
            description += "\n卡路里目标：\(calorieGoal)"
        }
        
        if !exerciseNotes.isEmpty {
            description += "\n备注：\(exerciseNotes)"
        }
        
        // 确定重复模式
        let repeatPattern: String?
        switch selectedFrequency {
        case "每天":
            repeatPattern = "daily"
        case "隔天":
            repeatPattern = "alternate"
        case "每周":
            repeatPattern = "weekly"
        case "自定义":
            repeatPattern = "custom_\(customDays)"
        default:
            repeatPattern = nil
        }
        
        // 创建提醒
        let reminder = Reminder(
            title: exerciseName,
            date: selectedTime,
            description: description,
            type: NSLocalizedString("exercise_reminder", comment: ""),
            repeatPattern: repeatPattern
        )
        
        // 保存提醒
        reminderManager.addReminder(reminder)
        
        // 关闭视图
        dismiss()
    }
} 