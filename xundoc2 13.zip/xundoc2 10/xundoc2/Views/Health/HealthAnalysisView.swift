import SwiftUI
import HealthKit

struct HealthAnalysisView: View {
    @Environment(\.colorScheme) private var colorScheme
    @State private var selectedTimeRange: TimeRange = .today
    @State private var healthData: [TimeRange: HealthData] = [:]
    private let healthStore = HKHealthStore()
    
    @AppStorage("userHeight") private var userHeight: Double = 170.0
    @AppStorage("userWeight") private var userWeight: Double = 65.0
    @AppStorage("userBirthday") private var userBirthday = Date()
    @AppStorage("userGender") private var userGender: String = "male"
    
    enum TimeRange: String, CaseIterable {
        case today = "today"
        case yesterday = "yesterday"
        case lastWeek = "last_7_days"
        
        var localizedString: String {
            return NSLocalizedString(self.rawValue, comment: "")
        }
    }
    
    var body: some View {
        ScrollView {
            VStack(spacing: 30) {
                Picker(NSLocalizedString("time_range", comment: ""), selection: $selectedTimeRange) {
                    ForEach(TimeRange.allCases, id: \.self) { range in
                        Text(range.localizedString).tag(range)
                    }
                }
                .pickerStyle(.segmented)
                .padding(.horizontal)
                .padding(.top)
                
                if let data = healthData[selectedTimeRange] {
                    if selectedTimeRange == .lastWeek {
                        WeeklyStatsView(data: data)
                    } else {
                        ActivityRingsView(data: data)
                            .frame(height: 200)
                            .padding(.vertical)
                        
                        LazyVGrid(columns: [
                            GridItem(.flexible(), spacing: 16),
                            GridItem(.flexible(), spacing: 16)
                        ], spacing: 12) {
                            DataCard(
                                title: NSLocalizedString("steps", comment: ""),
                                value: "\(data.steps)",
                                unit: NSLocalizedString("steps", comment: "")
                            )
                            
                            DataCard(
                                title: NSLocalizedString("sleep", comment: ""),
                                value: String(format: "%.1f", data.sleepHours),
                                unit: NSLocalizedString("hours", comment: "")
                            )
                            
                            DataCard(
                                title: NSLocalizedString("exercise_tasks", comment: ""),
                                value: "\(data.completedTasks)",
                                unit: "/ \(data.totalTasks)项"
                            )
                            
                            DataCard(
                                title: NSLocalizedString("calorie_goal", comment: ""),
                                value: "\(data.dailyCalorieGoal)",
                                unit: "千卡"
                            )
                        }
                        .padding(12)
                        
                        VStack(alignment: .leading, spacing: 16) {
                                                    Text(NSLocalizedString("suggestions", comment: ""))
                                .font(.title2)
                                .fontWeight(.bold)
                                .padding(.horizontal)
                                                    VStack(spacing: 12) {
                                                        ForEach(getHealthSuggestions(for: data), id: \.title) { suggestion in
                                                            SuggestionCard(suggestion: suggestion)
                                                        }
                                                    }
                                                    .padding(.horizontal)
                                                }
                    }
                }
            }
        }
        .navigationTitle(NSLocalizedString("health_analysis", comment: ""))
        .onAppear {
            requestHealthKitAuthorization()
        }
    }
    
    private func requestHealthKitAuthorization() {
        let typesToRead: Set<HKSampleType> = [
            HKObjectType.quantityType(forIdentifier: .stepCount)!,
            HKObjectType.categoryType(forIdentifier: .sleepAnalysis)!
        ]
        
        healthStore.requestAuthorization(toShare: nil, read: typesToRead) { success, error in
            if success {
                print("HealthKit authorization granted")
                self.loadHealthData()
            } else if let error = error {
                print("HealthKit authorization failed: \(error.localizedDescription)")
            }
        }
    }
    
    private func loadHealthData() {
        loadDataForTimeRange(.today)
        loadDataForTimeRange(.yesterday)
        loadDataForTimeRange(.lastWeek)
    }
    
    private func loadDataForTimeRange(_ timeRange: TimeRange) {
        let calendar = Calendar.current
        let now = Date()
        let startDate: Date
        let endDate: Date
        
        switch timeRange {
        case .today:
            startDate = calendar.startOfDay(for: now)
            endDate = now
        case .yesterday:
            startDate = calendar.date(byAdding: .day, value: -1, to: calendar.startOfDay(for: now))!
            endDate = calendar.startOfDay(for: now)
        case .lastWeek:
            startDate = calendar.date(byAdding: .day, value: -7, to: calendar.startOfDay(for: now))!
            endDate = now
        }
        
        getSteps(from: startDate, to: endDate) { steps in
            getSleepHours(from: startDate, to: endDate) { sleepHours in
                let (completed, total) = getTasksCount(for: timeRange)
                let calorieGoal = calculateDailyCalorieGoal()
                
                DispatchQueue.main.async {
                    self.healthData[timeRange] = HealthData(
                        steps: steps,
                        sleepHours: sleepHours,
                        completedTasks: completed,
                        totalTasks: total,
                        dailyCalorieGoal: calorieGoal
                    )
                }
            }
        }
    }
    
    private func getSteps(from startDate: Date, to endDate: Date, completion: @escaping (Int) -> Void) {
        guard let stepType = HKQuantityType.quantityType(forIdentifier: .stepCount) else {
            completion(0)
            return
        }
        
        let predicate = HKQuery.predicateForSamples(withStart: startDate, end: endDate, options: .strictStartDate)
        let query = HKStatisticsQuery(
            quantityType: stepType,
            quantitySamplePredicate: predicate,
            options: .cumulativeSum
        ) { _, result, error in
            guard let result = result,
                  let sum = result.sumQuantity() else {
                completion(0)
                return
            }
            
            let steps = Int(sum.doubleValue(for: HKUnit.count()))
            completion(steps)
        }
        
        healthStore.execute(query)
    }
    
    private func getSleepHours(from startDate: Date, to endDate: Date, completion: @escaping (Double) -> Void) {
        guard let sleepType = HKObjectType.categoryType(forIdentifier: .sleepAnalysis) else {
            completion(0)
            return
        }
        
        let predicate = HKQuery.predicateForSamples(withStart: startDate, end: endDate, options: .strictStartDate)
        let sortDescriptor = NSSortDescriptor(key: HKSampleSortIdentifierStartDate, ascending: true)
        
        let query = HKSampleQuery(
            sampleType: sleepType,
            predicate: predicate,
            limit: HKObjectQueryNoLimit,
            sortDescriptors: [sortDescriptor]
        ) { _, samples, error in
            guard let samples = samples as? [HKCategorySample],
                  error == nil else {
                print("Error fetching sleep data: \(String(describing: error))")
                completion(0)
                return
            }
            
            var totalSleepTime = 0.0
            
            for sample in samples {
                if sample.value == HKCategoryValueSleepAnalysis.asleep.rawValue {
                    let sleepTime = sample.endDate.timeIntervalSince(sample.startDate)
                    totalSleepTime += sleepTime
                }
            }
            
            let sleepHours = totalSleepTime / 3600.0
            completion(sleepHours)
        }
        
        healthStore.execute(query)
    }
    
    private func getTasksCount(for timeRange: TimeRange) -> (completed: Int, total: Int) {
        switch timeRange {
        case .today:
            return (3, 5)
        case .yesterday:
            return (5, 5)
        case .lastWeek:
            return (28, 35)
        }
    }
    
    private func calculateBMR() -> Double {
        let age = Calendar.current.dateComponents([.year], from: userBirthday, to: Date()).year ?? 25
        
        if userGender == "male" {
            return 66.5 + (13.75 * userWeight) + (5.003 * userHeight) - (6.75 * Double(age))
        } else {
            return 655.1 + (9.563 * userWeight) + (1.850 * userHeight) - (4.676 * Double(age))
        }
    }
    
    private func calculateDailyCalorieGoal() -> Int {
        let bmr = calculateBMR()
        let dailyCalories = bmr * 1.375
        return Int(dailyCalories)
    }
    
    private func getHealthSuggestions(for data: HealthData) -> [HealthSuggestion] {
        
        var suggestions: [HealthSuggestion] = []
        
        if data.steps < 8000 {
            suggestions.append(HealthSuggestion(
                title: NSLocalizedString("increase_activity", comment: ""),
                description: String(format: NSLocalizedString("steps_suggestion", comment: ""), 8000 - data.steps),
                icon: "figure.walk",
                color: .green
            ))
        }
        
        if data.sleepHours < 7 {
            suggestions.append(HealthSuggestion(
                title: NSLocalizedString("improve_sleep", comment: ""),
                description: NSLocalizedString("sleep_suggestion", comment: ""),
                icon: "bed.double.fill",
                color: .blue
            ))
        }
        
        if data.completedTasks < data.totalTasks {
            suggestions.append(HealthSuggestion(
                title: NSLocalizedString("exercise_goal", comment: ""),
                description: String(format: NSLocalizedString("exercise_suggestion", comment: ""), data.totalTasks - data.completedTasks),
                icon: "checkmark.circle.fill",
                color: .purple
            ))
        }
        
        suggestions.append(HealthSuggestion(
            title: NSLocalizedString("daily_energy_goal", comment: ""),
            description: String(format: NSLocalizedString("calorie_suggestion", comment: ""), data.dailyCalorieGoal),
            icon: "flame.fill",
            color: .orange
        ))
        
        if suggestions.isEmpty {
            suggestions.append(HealthSuggestion(
                title: NSLocalizedString("good_status", comment: ""),
                description: NSLocalizedString("keep_going", comment: ""),
                icon: "star.fill",
                color: .orange
            ))
        }
        
        return suggestions
    }
}

struct HealthData {
    let steps: Int
    let sleepHours: Double
    let completedTasks: Int
    let totalTasks: Int
    let dailyCalorieGoal: Int
}

struct ActivityRingsView: View {
    let data: HealthData
    
    var body: some View {
        VStack(spacing: 40) {
            ZStack {
                ActivityRing(
                    progress: min(Double(data.steps) / 8000.0, 1.0),
                    color: .green,
                    thickness: 20
                )
                .frame(width: 180, height: 180)
                
                ActivityRing(
                    progress: min(data.sleepHours / 8.0, 1.0),
                    color: .blue,
                    thickness: 20
                )
                .frame(width: 140, height: 140)
                
                ActivityRing(
                    progress: Double(data.completedTasks) / Double(data.totalTasks),
                    color: .purple,
                    thickness: 20
                )
                .frame(width: 100, height: 100)
            }
            .padding(.top, 20)
            
            HStack(spacing: 16) {
                LegendItem(color: .green, text: "\(NSLocalizedString("steps", comment: "")): \(data.steps)/8000")
                LegendItem(color: .blue, text: "\(NSLocalizedString("sleep", comment: "")): \(String(format: "%.1f", data.sleepHours))/8小时")
                LegendItem(color: .purple, text: "\(NSLocalizedString("exercise_tasks", comment: "")): \(data.completedTasks)/\(data.totalTasks)")
            }
            .padding(.bottom, 10)
        }
    }
}

struct ActivityRing: View {
    let progress: Double
    let color: Color
    let thickness: CGFloat
    
    var body: some View {
        ZStack {
            Circle()
                .stroke(color.opacity(0.2), lineWidth: thickness)
            
            Circle()
                .trim(from: 0, to: CGFloat(progress))
                .stroke(color, style: StrokeStyle(
                    lineWidth: thickness,
                    lineCap: .round
                ))
                .rotationEffect(.degrees(-90))
                .animation(.easeInOut, value: progress)
        }
    }
}

struct HealthSuggestion {
    let title: String
    let description: String
    let icon: String
    let color: Color
}

struct SuggestionCard: View {
    let suggestion: HealthSuggestion
    @Environment(\.colorScheme) private var colorScheme
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: suggestion.icon)
                    .font(.title2)
                    .foregroundColor(suggestion.color)
                Text(suggestion.title)
                    .font(.headline)
            }
            
            Text(suggestion.description)
                .font(.subheadline)
                .foregroundColor(.gray)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(colorScheme == .dark ? Color.black.opacity(0.3) : Color(hex: "FAFAFA"))
        .cornerRadius(8)
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(colorScheme == .dark ? Color.gray.opacity(0.3) : Color(hex: "E5E5E5"), lineWidth: 0.5)
        )
        .padding(.top, 10)
    }
}

struct DataCard: View {
    let title: String
    let value: String
    let unit: String
    @Environment(\.colorScheme) private var colorScheme
    
    var body: some View {
        VStack(spacing: 8) {
            Text(title)
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            Text(value)
                .font(.system(size: 24, weight: .bold))
            
            Text(unit)
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(12)
        .background(colorScheme == .dark ? Color.black.opacity(0.3) : Color(hex: "FAFAFA"))
        .cornerRadius(8)
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(colorScheme == .dark ? Color.gray.opacity(0.3) : Color(hex: "E6E6E6"), lineWidth: 0.5)
        )
        .padding(.top, 10)
    }
}

// 添加图例项组件
struct LegendItem: View {
    let color: Color
    let text: String
    
    var body: some View {
        HStack(spacing: 4) {
            Circle()
                .fill(color)
                .frame(width: 8, height: 8)
            Text(text)
                .font(.caption)
                .foregroundColor(.secondary)
        }
    }
}

struct WeeklyStatsView: View {
    let data: HealthData
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text(NSLocalizedString("weekly_trends", comment: ""))
                .font(.headline)
                .padding(.horizontal)
            
            VStack(spacing: 30) {
                // 步数趋势
                ChartSection(
                    title: NSLocalizedString("steps", comment: ""),
                    color: .green,
                    data: mockWeeklySteps(),
                    unit: NSLocalizedString("steps", comment: "")
                )
                
                // 睡眠趋势
                ChartSection(
                    title: NSLocalizedString("sleep", comment: ""),
                    color: .blue,
                    data: mockWeeklySleep(),
                    unit: NSLocalizedString("hours", comment: "")
                )
                
                // 任务完成率趋势
                ChartSection(
                    title: NSLocalizedString("exercise_tasks", comment: ""),
                    color: .purple,
                    data: mockWeeklyTasks(),
                    unit: "%"
                )
            }
            .padding()
            .background(Color(UIColor.secondarySystemBackground))
            .cornerRadius(12)
            .padding(.horizontal)
        }
    }
    
    private func mockWeeklySteps() -> [(String, Double)] {
        [
            (NSLocalizedString("monday", comment: ""), 6500),
            (NSLocalizedString("tuesday", comment: ""), 7200),
            (NSLocalizedString("wednesday", comment: ""), 8100),
            (NSLocalizedString("thursday", comment: ""), 7800),
            (NSLocalizedString("friday", comment: ""), 6900),
            (NSLocalizedString("saturday", comment: ""), 9200),
            (NSLocalizedString("sunday", comment: ""), 7500)
        ]
    }
    
    private func mockWeeklySleep() -> [(String, Double)] {
        [
            (NSLocalizedString("monday", comment: ""), 7.5),
            (NSLocalizedString("tuesday", comment: ""), 6.8),
            (NSLocalizedString("wednesday", comment: ""), 7.2),
            (NSLocalizedString("thursday", comment: ""), 8.0),
            (NSLocalizedString("friday", comment: ""), 6.5),
            (NSLocalizedString("saturday", comment: ""), 8.5),
            (NSLocalizedString("sunday", comment: ""), 7.8)
        ]
    }
    
    private func mockWeeklyTasks() -> [(String, Double)] {
        [
            (NSLocalizedString("monday", comment: ""), 80),
            (NSLocalizedString("tuesday", comment: ""), 90),
            (NSLocalizedString("wednesday", comment: ""), 85),
            (NSLocalizedString("thursday", comment: ""), 95),
            (NSLocalizedString("friday", comment: ""), 75),
            (NSLocalizedString("saturday", comment: ""), 70),
            (NSLocalizedString("sunday", comment: ""), 85)
        ]
    }
}

struct ChartSection: View {
    let title: String
    let color: Color
    let data: [(String, Double)]
    let unit: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            GeometryReader { geometry in
                Path { path in
                    let width = geometry.size.width
                    let height = geometry.size.height
                    let stepWidth = width / CGFloat(data.count - 1)
                    let maxValue = data.map { $0.1 }.max() ?? 1
                    
                    for (index, point) in data.enumerated() {
                        let x = CGFloat(index) * stepWidth
                        let y = height - (CGFloat(point.1) / CGFloat(maxValue) * height)
                        
                        if index == 0 {
                            path.move(to: CGPoint(x: x, y: y))
                        } else {
                            path.addLine(to: CGPoint(x: x, y: y))
                        }
                    }
                }
                .stroke(color, lineWidth: 2)
                
                // 添加数据点
                ForEach(0..<data.count, id: \.self) { index in
                    let point = data[index]
                    let x = CGFloat(index) * (geometry.size.width / CGFloat(data.count - 1))
                    let y = geometry.size.height - (CGFloat(point.1) / CGFloat(data.map { $0.1 }.max() ?? 1) * geometry.size.height)
                    
                    Circle()
                        .fill(color)
                        .frame(width: 6, height: 6)
                        .position(x: x, y: y)
                }
            }
            .frame(height: 100)
            
            // X轴标签
            HStack(spacing: 0) {
                ForEach(data, id: \.0) { point in
                    Text(point.0)
                        .font(.caption2)
                        .frame(maxWidth: .infinity)
                }
            }
        }
    }
}

// 添加一个扩展来支持十六进制颜色

#Preview {
    NavigationView {
        HealthAnalysisView()
    }
}
