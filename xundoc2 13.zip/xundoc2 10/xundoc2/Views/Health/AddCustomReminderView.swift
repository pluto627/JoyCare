import SwiftUI
import PhotosUI
import Foundation

struct AddCustomReminderView: View {
    @Environment(\.dismiss) var dismiss
    @ObservedObject var reminderManager: ReminderManager
    
    // 基本信息
    @State private var reminderTitle = ""
    @State private var selectedTime = Date()
    @State private var selectedDate = Date()
    @State private var reminderNotes = ""
    @State private var isDateSpecific = false // 是否为指定日期的提醒
    
    // 重复设置
    @State private var selectedFrequency = "不重复"
    @State private var customDays = 1
    @State private var selectedWeekdays: Set<Int> = []
    
    // 媒体
    @State private var showImagePicker = false
    @State private var selectedImages: [UIImage] = []
    
    // 通知设置
    @State private var enableSound = true
    @State private var soundName = "default"
    @State private var vibrationEnabled = true
    @State private var priority = "正常"
    
    let frequencyOptions = ["不重复", "每天", "工作日", "周末", "每周", "自定义天数"]
    let weekdays = ["周日", "周一", "周二", "周三", "周四", "周五", "周六"]
    let priorityLevels = ["低", "正常", "高", "紧急"]
    let soundOptions = ["默认", "铃声1", "铃声2", "铃声3", "无"]
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("基本信息")) {
                    TextField("提醒标题", text: $reminderTitle)
                    
                    Toggle("指定日期", isOn: $isDateSpecific)
                    
                    if isDateSpecific {
                        DatePicker("日期", selection: $selectedDate, displayedComponents: .date)
                    }
                    
                    DatePicker("时间", selection: $selectedTime, displayedComponents: .hourAndMinute)
                }
                
                Section(header: Text("重复")) {
                    Picker("频率", selection: $selectedFrequency) {
                        ForEach(frequencyOptions, id: \.self) { option in
                            Text(option).tag(option)
                        }
                    }
                    
                    if selectedFrequency == "自定义天数" {
                        Stepper("每\(customDays)天", value: $customDays, in: 1...30)
                    }
                    
                    if selectedFrequency == "每周" {
                        VStack(alignment: .leading) {
                            Text("选择重复的星期")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            
                            HStack {
                                ForEach(0..<7) { index in
                                    Button(action: {
                                        if selectedWeekdays.contains(index) {
                                            selectedWeekdays.remove(index)
                                        } else {
                                            selectedWeekdays.insert(index)
                                        }
                                    }) {
                                        Text(weekdays[index])
                                            .padding(.horizontal, 8)
                                            .padding(.vertical, 4)
                                            .background(
                                                RoundedRectangle(cornerRadius: 8)
                                                    .fill(selectedWeekdays.contains(index) ? Color.blue : Color.gray.opacity(0.2))
                                            )
                                            .foregroundColor(selectedWeekdays.contains(index) ? .white : .primary)
                                    }
                                }
                            }
                            .padding(.vertical, 4)
                        }
                    }
                }
                
                Section(header: Text("通知设置")) {
                    Picker("优先级", selection: $priority) {
                        ForEach(priorityLevels, id: \.self) { level in
                            Text(level).tag(level)
                        }
                    }
                    
                    Toggle("声音", isOn: $enableSound)
                    
                    if enableSound {
                        Picker("提示音", selection: $soundName) {
                            ForEach(soundOptions, id: \.self) { sound in
                                Text(sound).tag(sound)
                            }
                        }
                    }
                    
                    Toggle("振动", isOn: $vibrationEnabled)
                }
                
                Section(header: Text("备注")) {
                    TextEditor(text: $reminderNotes)
                        .frame(minHeight: 100)
                        .placeholder(when: reminderNotes.isEmpty) {
                            Text("添加提醒的详细内容...")
                                .foregroundColor(.gray)
                                .padding(.top, 8)
                                .padding(.leading, 5)
                        }
                    
                    Button(action: {
                        showImagePicker = true
                    }) {
                        HStack {
                            Image(systemName: "camera")
                            Text("添加相关图片")
                        }
                    }
                    
                    if !selectedImages.isEmpty {
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack {
                                ForEach(0..<selectedImages.count, id: \.self) { index in
                                    Image(uiImage: selectedImages[index])
                                        .resizable()
                                        .scaledToFill()
                                        .frame(width: 100, height: 100)
                                        .clipShape(RoundedRectangle(cornerRadius: 10))
                                        .overlay(
                                            Button(action: {
                                                selectedImages.remove(at: index)
                                            }) {
                                                Image(systemName: "xmark.circle.fill")
                                                    .foregroundColor(.white)
                                                    .background(Circle().fill(Color.black.opacity(0.7)))
                                            }
                                            .padding(5),
                                            alignment: .topTrailing
                                        )
                                }
                            }
                        }
                    }
                }
            }
            .navigationTitle("添加自定义提醒")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("取消") {
                        dismiss()
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("保存") {
                        saveReminder()
                    }
                    .disabled(reminderTitle.isEmpty)
                }
            }
            .sheet(isPresented: $showImagePicker) {
                ImagePicker(selectedImages: $selectedImages, sourceType: .photoLibrary)
            }
        }
    }
    
    private func saveReminder() {
        // 合并日期和时间
        let reminderDate: Date
        if isDateSpecific {
            reminderDate = combineDateTime(date: selectedDate, time: selectedTime)
        } else {
            // 如果不是特定日期，则只使用时间部分
            reminderDate = selectedTime
        }
        
        // 构建详细描述字符串
        var description = ""
        
        if !reminderNotes.isEmpty {
            description += reminderNotes
        }
        
        description += "\n\n优先级：\(priority)"
        
        if enableSound {
            description += "\n提示音：\(soundName)"
        } else {
            description += "\n无声音提醒"
        }
        
        if vibrationEnabled {
            description += "\n启用振动"
        } else {
            description += "\n不振动"
        }
        
        if selectedImages.count > 0 {
            description += "\n包含\(selectedImages.count)张图片"
        }
        
        // 确定重复模式
        let repeatPattern: String?
        switch selectedFrequency {
        case "每天":
            repeatPattern = "daily"
        case "工作日":
            repeatPattern = "weekdays"
        case "周末":
            repeatPattern = "weekends"
        case "每周":
            if selectedWeekdays.isEmpty {
                repeatPattern = nil
            } else {
                let weekdaysList = selectedWeekdays.sorted().map { String($0) }.joined(separator: ",")
                repeatPattern = "weekly_\(weekdaysList)"
            }
        case "自定义天数":
            repeatPattern = "custom_\(customDays)"
        default:
            repeatPattern = nil
        }
        
        // 创建提醒
        let reminder = Reminder(
            title: reminderTitle,
            date: reminderDate,
            description: description,
            type: NSLocalizedString("custom_reminder", comment: ""),
            repeatPattern: repeatPattern
        )
        
        reminderManager.addReminder(reminder)
        
        // 关闭视图
        dismiss()
    }
    
    private func combineDateTime(date: Date, time: Date) -> Date {
        let calendar = Calendar.current
        
        let dateComponents = calendar.dateComponents([.year, .month, .day], from: date)
        let timeComponents = calendar.dateComponents([.hour, .minute], from: time)
        
        var combinedComponents = DateComponents()
        combinedComponents.year = dateComponents.year
        combinedComponents.month = dateComponents.month
        combinedComponents.day = dateComponents.day
        combinedComponents.hour = timeComponents.hour
        combinedComponents.minute = timeComponents.minute
        
        return calendar.date(from: combinedComponents) ?? date
    }
}

