import SwiftUI
import PhotosUI
import Foundation


struct AddFollowUpReminderView: View {
    @Environment(\.dismiss) var dismiss
    @ObservedObject var reminderManager: ReminderManager
    
    // 基本信息
    @State private var reminderTitle = "复诊提醒"
    @State private var selectedDate = Calendar.current.date(byAdding: .day, value: 7, to: Date()) ?? Date() // 默认一周后
    @State private var selectedTime = Date()
    @State private var advanceNoticeDays = 1  // 提前几天提醒
    
    // 复诊详情
    @State private var hospital = ""
    @State private var department = ""
    @State private var doctorName = ""
    @State private var visitNotes = ""
    @State private var preparationItems = ""
    @State private var showImagePicker = false
    @State private var selectedImages: [UIImage] = []
    
    // 常用医院和科室
    let commonHospitals = ["请选择医院", "协和医院", "华西医院", "301医院", "北京大学第一医院", "其他"]
    let commonDepartments = ["请选择科室", "内科", "外科", "妇产科", "儿科", "眼科", "口腔科", "皮肤科", "骨科", "神经内科", "心内科", "其他"]
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("基本信息")) {
                    TextField("提醒标题", text: $reminderTitle)
                    DatePicker("复诊日期", selection: $selectedDate, displayedComponents: .date)
                    DatePicker("复诊时间", selection: $selectedTime, displayedComponents: .hourAndMinute)
                    Stepper("提前\(advanceNoticeDays)天提醒", value: $advanceNoticeDays, in: 1...7)
                }
                
                Section(header: Text("复诊详情")) {
                    Picker("医院", selection: $hospital) {
                        ForEach(commonHospitals, id: \.self) { hospital in
                            Text(hospital).tag(hospital)
                        }
                    }
                    .pickerStyle(.menu)
                    
                    if hospital == "其他" {
                        TextField("请输入医院名称", text: $hospital)
                    }
                    
                    Picker("科室", selection: $department) {
                        ForEach(commonDepartments, id: \.self) { department in
                            Text(department).tag(department)
                        }
                    }
                    .pickerStyle(.menu)
                    
                    if department == "其他" {
                        TextField("请输入科室名称", text: $department)
                    }
                    
                    TextField("医生姓名 (可选)", text: $doctorName)
                }
                
                Section(header: Text("准备事项")) {
                    TextEditor(text: $preparationItems)
                        .frame(minHeight: 80)
                        .placeholder(when: preparationItems.isEmpty) {
                            Text("输入需要准备的检查报告或材料...")
                                .foregroundColor(.gray)
                                .padding(.top, 8)
                                .padding(.leading, 5)
                        }
                }
                
                Section(header: Text("备注")) {
                    TextEditor(text: $visitNotes)
                        .frame(minHeight: 100)
                        .placeholder(when: visitNotes.isEmpty) {
                            Text("添加复诊备注...")
                                .foregroundColor(.gray)
                                .padding(.top, 8)
                                .padding(.leading, 5)
                        }
                    
                    Button(action: {
                        showImagePicker = true
                    }) {
                        HStack {
                            Image(systemName: "camera")
                            Text("添加相关照片")
                        }
                    }
                    
                    if !selectedImages.isEmpty {
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack {
                                ForEach(0..<selectedImages.count, id: \.self) { index in
                                    Image(uiImage: selectedImages[index])
                                        .resizable()
                                        .scaledToFill()
                                        .frame(width: 100, height: 100)
                                        .clipShape(RoundedRectangle(cornerRadius: 10))
                                        .overlay(
                                            Button(action: {
                                                selectedImages.remove(at: index)
                                            }) {
                                                Image(systemName: "xmark.circle.fill")
                                                    .foregroundColor(.white)
                                                    .background(Circle().fill(Color.black.opacity(0.7)))
                                            }
                                            .padding(5),
                                            alignment: .topTrailing
                                        )
                                }
                            }
                        }
                    }
                }
            }
            .navigationTitle("添加复诊提醒")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("取消") {
                        dismiss()
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("保存") {
                        saveReminder()
                    }
                    .disabled(reminderTitle.isEmpty || (hospital == "请选择医院" || hospital.isEmpty) || (department == "请选择科室" || department.isEmpty))
                }
            }
            .sheet(isPresented: $showImagePicker) {
                ImagePicker(selectedImages: $selectedImages, sourceType: .photoLibrary)
            }
        }
    }
    
    private func saveReminder() {
        // 合并日期和时间
        let combinedDateTime = combineDateTime(date: selectedDate, time: selectedTime)
        
        // 构建详细描述字符串
        var description = "医院：\(hospital)\n科室：\(department)"
        
        if !doctorName.isEmpty {
            description += "\n医生：\(doctorName)"
        }
        
        if !preparationItems.isEmpty {
            description += "\n准备事项：\(preparationItems)"
        }
        
        if !visitNotes.isEmpty {
            description += "\n备注：\(visitNotes)"
        }
        
        // 创建复诊当天提醒
        let appointmentReminder = Reminder(
            title: reminderTitle,
            date: combinedDateTime,
            description: description,
            type: NSLocalizedString("follow_up_reminder", comment: "")
        )
        
        reminderManager.addReminder(appointmentReminder)
        
        // 创建提前提醒
        if advanceNoticeDays > 0 {
            // 计算提前提醒的日期
            if let advanceDate = Calendar.current.date(byAdding: .day, value: -advanceNoticeDays, to: combinedDateTime) {
                let advanceReminder = Reminder(
                    title: "即将复诊提醒",
                    date: advanceDate,
                    description: "您将在\(advanceNoticeDays)天后(\(formatDate(combinedDateTime)))前往\(hospital)\(department)复诊，请提前准备。",
                    type: NSLocalizedString("follow_up_reminder", comment: "")
                )
                
                reminderManager.addReminder(advanceReminder)
            }
        }
        
        // 关闭视图
        dismiss()
    }
    
    private func combineDateTime(date: Date, time: Date) -> Date {
        let calendar = Calendar.current
        
        let dateComponents = calendar.dateComponents([.year, .month, .day], from: date)
        let timeComponents = calendar.dateComponents([.hour, .minute], from: time)
        
        var combinedComponents = DateComponents()
        combinedComponents.year = dateComponents.year
        combinedComponents.month = dateComponents.month
        combinedComponents.day = dateComponents.day
        combinedComponents.hour = timeComponents.hour
        combinedComponents.minute = timeComponents.minute
        
        return calendar.date(from: combinedComponents) ?? date
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "MM月dd日 HH:mm"
        return formatter.string(from: date)
    }
}

// 如果之前没有创建过ImagePicker，需要添加以下代码
