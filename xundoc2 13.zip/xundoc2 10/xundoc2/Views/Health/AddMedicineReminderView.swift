import SwiftUI
import PhotosUI
import Vision
import CoreML

struct AddMedicineReminderView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) private var colorScheme
    @EnvironmentObject private var languageManager: LanguageManager
    @ObservedObject var reminderManager: ReminderManager
    
    @State private var medicineName = ""
    @State private var dosage = ""
    @State private var frequency = 1
    @State private var selectedTimes: [Date] = [Date()]
    @State private var beforeOrAfterMeal = NSLocalizedString("before_meal", comment: "")
    @State private var isPhotoPickerPresented = false
    @State private var selectedImage: UIImage? = nil
    @State private var selectedImages: [UIImage] = []
    @State private var isProcessingImage = false
    @State private var showSavedAlert = false
    @State private var showProcessingAlert = false
    
    let timesOptions = ["1", "2", "3", "4"]
    let mealTimes = ["餐前", "随餐", "餐后"]
    
    // 定义自定义颜色
    private let customPurple = Color(hex: "8749f1")
    
    // 深色模式适配颜色
    private var backgroundColor: Color {
        colorScheme == .dark ? Color.black : Color(UIColor.systemGray6)
    }
    
    private var cardBackgroundColor: Color {
        colorScheme == .dark ? Color.black.opacity(0.3) : Color.white
    }
    
    private var textFieldBackgroundColor: Color {
        colorScheme == .dark ? Color.gray.opacity(0.2) : Color.white
    }
    
    private var textColor: Color {
        colorScheme == .dark ? Color.white : Color.primary
    }
    
    private var labelColor: Color {
        colorScheme == .dark ? Color.gray.opacity(0.8) : Color.gray
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                backgroundColor
                    .ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 20) {
                        // 药品名称输入
                        VStack(alignment: .leading, spacing: 8) {
                            Text(NSLocalizedString("medication_name", comment: ""))
                                .font(.headline)
                                .foregroundColor(labelColor)
                            
                            HStack {
                                TextField(NSLocalizedString("enter_medication_name", comment: ""), text: $medicineName)
                                    .padding()
                                    .background(textFieldBackgroundColor)
                                    .cornerRadius(8)
                                    .foregroundColor(textColor)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 8)
                                            .stroke(colorScheme == .dark ? Color.gray.opacity(0.3) : Color.gray.opacity(0.2), lineWidth: 0.5)
                                    )
                                
                                Button(action: {
                                    isPhotoPickerPresented = true
                                }) {
                                    Image(systemName: "camera")
                                        .font(.title2)
                                        .foregroundColor(.blue)
                                        .frame(width: 44, height: 44)
                                        .background(cardBackgroundColor)
                                        .cornerRadius(8)
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 8)
                                                .stroke(colorScheme == .dark ? Color.gray.opacity(0.3) : Color.gray.opacity(0.2), lineWidth: 0.5)
                                        )
                                }
                            }
                        }
                        .padding(.horizontal)
                        
                        // 剂量输入
                        VStack(alignment: .leading, spacing: 8) {
                            Text(NSLocalizedString("dosage", comment: ""))
                                .font(.headline)
                                .foregroundColor(labelColor)
                            
                            TextField(NSLocalizedString("enter_dosage", comment: ""), text: $dosage)
                                .padding()
                                .background(textFieldBackgroundColor)
                                .cornerRadius(8)
                                .foregroundColor(textColor)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(colorScheme == .dark ? Color.gray.opacity(0.3) : Color.gray.opacity(0.2), lineWidth: 0.5)
                                )
                        }
                        .padding(.horizontal)
                        
                        // 服用频率
                        VStack(alignment: .leading, spacing: 8) {
                            Text(NSLocalizedString("daily_frequency", comment: ""))
                                .font(.headline)
                                .foregroundColor(labelColor)
                            
                            HStack {
                                Spacer()
                                Button(action: { if frequency > 1 { frequency -= 1 } }) {
                                    Image(systemName: "minus.circle.fill")
                                        .font(.title2)
                                        .foregroundColor(.blue)
                                }
                                
                                Text("\(frequency)")
                                    .font(.title2)
                                    .fontWeight(.semibold)
                                    .frame(minWidth: 40)
                                    .foregroundColor(textColor)
                                
                                Button(action: { if frequency < 10 { frequency += 1 } }) {
                                    Image(systemName: "plus.circle.fill")
                                        .font(.title2)
                                        .foregroundColor(.blue)
                                }
                                Spacer()
                            }
                            .padding()
                            .background(cardBackgroundColor)
                            .cornerRadius(8)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(colorScheme == .dark ? Color.gray.opacity(0.3) : Color.gray.opacity(0.2), lineWidth: 0.5)
                            )
                        }
                        .padding(.horizontal)
                        .onChange(of: frequency) { newValue in
                            adjustSelectedTimes(to: newValue)
                        }
                        
                        // 时间选择
                        VStack(alignment: .leading, spacing: 8) {
                            Text(NSLocalizedString("medication_time", comment: ""))
                                .font(.headline)
                                .foregroundColor(labelColor)
                            
                            VStack(spacing: 12) {
                                ForEach(selectedTimes.indices, id: \.self) { index in
                                    DatePicker(
                                        NSLocalizedString("time", comment: "") + " \(index + 1)",
                                        selection: binding(for: index),
                                        displayedComponents: .hourAndMinute
                                    )
                                    .foregroundColor(textColor)
                                    .padding(.vertical, 4)
                                    .colorScheme(colorScheme) // 确保DatePicker适应当前颜色模式
                                }
                            }
                            .padding()
                            .background(cardBackgroundColor)
                            .cornerRadius(8)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(colorScheme == .dark ? Color.gray.opacity(0.3) : Color.gray.opacity(0.2), lineWidth: 0.5)
                            )
                        }
                        .padding(.horizontal)
                        
                        // 饭前饭后选择
                        VStack(alignment: .leading, spacing: 8) {
                            Text(NSLocalizedString("meal_timing", comment: ""))
                                .font(.headline)
                                .foregroundColor(labelColor)
                            
                            Picker("", selection: $beforeOrAfterMeal) {
                                Text(NSLocalizedString("before_meal", comment: ""))
                                    .tag(NSLocalizedString("before_meal", comment: ""))
                                Text(NSLocalizedString("after_meal", comment: ""))
                                    .tag(NSLocalizedString("after_meal", comment: ""))
                            }
                            .pickerStyle(SegmentedPickerStyle())
                            .padding()
                            .background(cardBackgroundColor)
                            .cornerRadius(8)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(colorScheme == .dark ? Color.gray.opacity(0.3) : Color.gray.opacity(0.2), lineWidth: 0.5)
                            )
                        }
                        .padding(.horizontal)
                        
                        if selectedImage != nil {
                            Image(uiImage: selectedImage!)
                                .resizable()
                                .scaledToFit()
                                .frame(maxHeight: 200)
                                .cornerRadius(8)
                                .padding(.horizontal)
                        }
                    }
                    .padding(.vertical)
                }
            }
            .navigationTitle(NSLocalizedString("add_medication", comment: ""))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(NSLocalizedString("cancel", comment: "")) {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(NSLocalizedString("save", comment: "")) {
                        saveReminder()
                    }
                    .disabled(medicineName.isEmpty)
                }
            }
            .sheet(isPresented: $isPhotoPickerPresented) {
                ImagePicker(
                    selectedImages: $selectedImages,
                    sourceType: .photoLibrary
                )
                .onChange(of: selectedImages) { newImages in
                    if let image = newImages.last {
                        selectedImage = image
                        isProcessingImage = true
                        showProcessingAlert = true
                        recognizeMedicineText(from: image)
                    }
                }
            }
            .alert(NSLocalizedString("processing_image", comment: ""), isPresented: $showProcessingAlert) {
                Button(NSLocalizedString("ok", comment: ""), role: .cancel) {}
            } message: {
                Text(NSLocalizedString("processing_image_message", comment: ""))
            }
            .alert(NSLocalizedString("saved", comment: ""), isPresented: $showSavedAlert) {
                Button(NSLocalizedString("ok", comment: ""), role: .cancel) {
                    dismiss()
                }
            } message: {
                Text(NSLocalizedString("reminder_saved_message", comment: ""))
            }
            .localized()
        }
        .id(languageManager.refreshToken)
    }
    
    private func binding(for index: Int) -> Binding<Date> {
        Binding(
            get: {
                if index < selectedTimes.count {
                    return selectedTimes[index]
                }
                return Date()
            },
            set: { newValue in
                while selectedTimes.count <= index {
                    selectedTimes.append(Date())
                }
                selectedTimes[index] = newValue
            }
        )
    }
    
    private func adjustSelectedTimes(to newFrequency: Int) {
        if newFrequency > selectedTimes.count {
            // 增加时间
            for _ in 0..<(newFrequency - selectedTimes.count) {
                selectedTimes.append(Date())
            }
        } else if newFrequency < selectedTimes.count {
            // 减少时间
            selectedTimes = Array(selectedTimes.prefix(newFrequency))
        }
    }
    
    private func saveReminder() {
        // 为每个时间点创建一个提醒
        for time in selectedTimes {
            let reminderDescription = """
            用药剂量: \(dosage)
            每日次数: \(frequency)次
            """
            
            let reminder = Reminder(
                title: medicineName,
                date: time,
                description: reminderDescription,
                type: "用药提醒",
                repeatPattern: "daily",
                dosage: dosage,
                unit: "",
                medicineMethod: "口服",
                beforeOrAfterMeal: beforeOrAfterMeal
            )
            
            reminderManager.addReminder(reminder)
        }
        
        HapticManager.shared.notification(type: .success)
        showSavedAlert = true
    }
    
    // 识别药品文字
    private func recognizeMedicineText(from image: UIImage) {
        guard let cgImage = image.cgImage else {
            DispatchQueue.main.async {
                self.isProcessingImage = false
            }
            return
        }
        
        let requestHandler = VNImageRequestHandler(cgImage: cgImage)
        let request = VNRecognizeTextRequest { request, error in
            guard let observations = request.results as? [VNRecognizedTextObservation],
                  !observations.isEmpty else {
                DispatchQueue.main.async {
                    self.isProcessingImage = false
                }
                return
            }
            
            let recognizedStrings = observations.compactMap { observation in
                observation.topCandidates(1).first?.string
            }
            
            print("识别到的文本: \(recognizedStrings)") // 添加调试输出
            
            DispatchQueue.main.async {
                let medicineText = self.processMedicineText(recognizedStrings)
                print("处理后的药品名称: \(medicineText)") // 添加调试输出
                self.medicineName = medicineText
                self.isProcessingImage = false
            }
        }
        
        request.recognitionLanguages = ["zh-Hans", "en"]
        request.recognitionLevel = .accurate // 设置为精确识别模式
        request.usesLanguageCorrection = true // 使用语言纠正
        
        do {
            try requestHandler.perform([request])
        } catch {
            print("文字识别失败: \(error)")
            DispatchQueue.main.async {
                self.isProcessingImage = false
            }
        }
    }
    
    // 处理识别到的药品文字
    private func processMedicineText(_ strings: [String]) -> String {
        // 常见药品后缀和关键词
        let medicineSuffixes = [
            "片", "胶囊", "颗粒", "丸", "贴", "液", "注射液", "滴眼液", "糖浆",
            "mg", "ml", "克", "毫克", "毫升", "针", "喷剂", "贴剂", "栓", "软膏"
        ]
        
        // 常见药品名称模式
        let patterns = [
            "[\u{4e00}-\u{9fff}]+(?:[0-9.]+)?(?:mg|ml|g|kg|片|粒|丸|贴|针|支|包|袋)?[片丸胶囊颗粒贴液针剂栓]",  // 中文名称+可能的数字+剂型
            "[A-Za-z\\s]+(?:[0-9.]+)?(?:mg|ml|g|tablet|capsule|patch|injection)[片丸胶囊颗粒贴液针剂栓]?",  // 英文名称+可能的数字+剂型
            "[\u{4e00}-\u{9fff}A-Za-z\\s]+[0-9.]+\\s*(?:mg|ml|g|克|毫克|毫升|片|粒|丸|贴|针|支|包|袋)" // 名称+规格
        ]
        
        for string in strings {
            // 打印每个识别到的字符串
            print("正在处理字符串: \(string)")
            
            // 1. 检查完整的药品名称模式
            for pattern in patterns {
                if let range = string.range(of: pattern, options: .regularExpression) {
                    let result = String(string[range])
                    print("匹配到模式: \(result)")
                    return result
                }
            }
            
            // 2. 检查是否包含药品后缀
            for suffix in medicineSuffixes {
                if string.contains(suffix) {
                    print("匹配到后缀: \(string)")
                    return string
                }
            }
        }
        
        // 如果没有找到匹配的模式，返回第一个识别到的文本
        let result = strings.first ?? ""
        print("未匹配到模式，返回: \(result)")
        return result
    }
}


// 添加颜色扩展
