import SwiftUI
import Foundation
struct AddSleepReminderView: View {
    @Environment(\.dismiss) var dismiss
    @ObservedObject var reminderManager: ReminderManager
    
    // 基本信息
    @State private var reminderTitle = "睡眠提醒"
    @State private var selectedTime = Calendar.current.date(bySettingHour: 22, minute: 0, second: 0, of: Date()) ?? Date() // 默认晚上10点
    @State private var wakeUpTime = Calendar.current.date(bySettingHour: 7, minute: 0, second: 0, of: Date()) ?? Date() // 默认早上7点
    @State private var selectedFrequency = "每天"
    @State private var customDays = 1
    
    // 睡眠详情
    @State private var sleepDuration: Double = 0  // 改为普通状态属性
    @State private var sleepQualityGoal = "良好"
    @State private var prepTime = 30 // 默认30分钟准备时间
    @State private var sleepNotes = ""
    
    let frequencyOptions = ["每天", "工作日", "周末", "自定义"]
    let sleepQualityOptions = ["一般", "良好", "优质"]
    let prepTimeOptions = [15, 30, 45, 60]
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("基本信息")) {
                    TextField("提醒标题", text: $reminderTitle)
                    DatePicker("就寝时间", selection: $selectedTime, displayedComponents: .hourAndMinute)
                        .onChange(of: selectedTime) { _ in
                            updateSleepDuration()
                        }
                    DatePicker("起床时间", selection: $wakeUpTime, displayedComponents: .hourAndMinute)
                        .onChange(of: wakeUpTime) { _ in
                            updateSleepDuration()
                        }
                    
                    HStack {
                        Text("睡眠时长")
                        Spacer()
                        Text("\(formatSleepDuration())")
                            .foregroundColor(.secondary)
                    }
                }
                
                Section(header: Text("睡眠准备")) {
                    Picker("准备时间", selection: $prepTime) {
                        ForEach(prepTimeOptions, id: \.self) { time in
                            Text("\(time)分钟").tag(time)
                        }
                    }
                    
                    let prepReminderTime = Calendar.current.date(byAdding: .minute, value: -prepTime, to: selectedTime) ?? selectedTime
                    HStack {
                        Text("准备提醒时间")
                        Spacer()
                        Text(formatTime(prepReminderTime))
                            .foregroundColor(.secondary)
                    }
                    
                    Picker("睡眠质量目标", selection: $sleepQualityGoal) {
                        ForEach(sleepQualityOptions, id: \.self) { quality in
                            Text(quality).tag(quality)
                        }
                    }
                }
                
                Section(header: Text("提醒频率")) {
                    Picker("重复", selection: $selectedFrequency) {
                        ForEach(frequencyOptions, id: \.self) { option in
                            Text(option).tag(option)
                        }
                    }
                    
                    if selectedFrequency == "自定义" {
                        Stepper("每\(customDays)天", value: $customDays, in: 1...30)
                    }
                }
                
                Section(header: Text("睡眠建议"), footer: Text("建议在睡前30分钟关闭电子设备，保持安静的睡眠环境")) {
                    TextEditor(text: $sleepNotes)
                        .frame(minHeight: 100)
                        .placeholder(when: sleepNotes.isEmpty) {
                            Text("添加个人睡眠注意事项...")
                                .foregroundColor(.gray)
                                .padding(.top, 8)
                                .padding(.leading, 5)
                        }
                }
            }
            .navigationTitle("添加睡眠提醒")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("取消") {
                        dismiss()
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("保存") {
                        saveReminder()
                    }
                    .disabled(reminderTitle.isEmpty)
                }
            }
            .onAppear {
                updateSleepDuration() // 初始化计算睡眠时长
            }
        }
    }
    
    // 更新睡眠时长的方法
    private func updateSleepDuration() {
        sleepDuration = calculateSleepDuration()
    }
    
    private func calculateSleepDuration() -> Double {
        let calendar = Calendar.current
        let sleepTimeComponents = calendar.dateComponents([.hour, .minute], from: selectedTime)
        let wakeTimeComponents = calendar.dateComponents([.hour, .minute], from: wakeUpTime)
        
        guard let sleepHour = sleepTimeComponents.hour,
              let sleepMinute = sleepTimeComponents.minute,
              let wakeHour = wakeTimeComponents.hour,
              let wakeMinute = wakeTimeComponents.minute else {
            return 0
        }
        
        let sleepTimeInMinutes = sleepHour * 60 + sleepMinute
        let wakeTimeInMinutes = wakeHour * 60 + wakeMinute
        
        var durationInMinutes = wakeTimeInMinutes - sleepTimeInMinutes
        if durationInMinutes < 0 {
            durationInMinutes += 24 * 60 // 加上一天的分钟数
        }
        
        return Double(durationInMinutes) / 60.0
    }
    
    private func formatSleepDuration() -> String {
        let hours = Int(sleepDuration)
        let minutes = Int((sleepDuration - Double(hours)) * 60)
        return "\(hours)小时\(minutes)分钟"
    }
    
    private func formatTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        return formatter.string(from: date)
    }
    
    private func saveReminder() {
        // 构建详细描述字符串
        let formattedSleepTime = formatTime(selectedTime)
        let formattedWakeTime = formatTime(wakeUpTime)
        let prepReminderTime = Calendar.current.date(byAdding: .minute, value: -prepTime, to: selectedTime) ?? selectedTime
        let formattedPrepTime = formatTime(prepReminderTime)
        
        var description = "就寝时间：\(formattedSleepTime)\n起床时间：\(formattedWakeTime)\n睡眠时长：\(formatSleepDuration())\n准备时间：提前\(prepTime)分钟(\(formattedPrepTime))\n睡眠质量目标：\(sleepQualityGoal)"
        
        if !sleepNotes.isEmpty {
            description += "\n备注：\(sleepNotes)"
        }
        
        // 确定重复模式
        let repeatPattern: String?
        switch selectedFrequency {
        case "每天":
            repeatPattern = "daily"
        case "工作日":
            repeatPattern = "weekdays"
        case "周末":
            repeatPattern = "weekends"
        case "自定义":
            repeatPattern = "custom_\(customDays)"
        default:
            repeatPattern = nil
        }
        
        // 创建主提醒（就寝提醒）
        let sleepReminder = Reminder(
            title: reminderTitle,
            date: selectedTime,
            description: description,
            type: NSLocalizedString("sleep_reminder", comment: ""),
            repeatPattern: repeatPattern
        )
        
        reminderManager.addReminder(sleepReminder)
        
        // 创建准备提醒
        let prepReminder = Reminder(
            title: "睡前准备提醒",
            date: prepReminderTime,
            description: "距离就寝时间还有\(prepTime)分钟，请开始准备",
            type: NSLocalizedString("sleep_reminder", comment: ""),
            repeatPattern: repeatPattern
        )
        
        reminderManager.addReminder(prepReminder)
        
        // 关闭视图
        dismiss()
    }
}

