import SwiftUI

struct AddWaterReminderView: View {
    @Environment(\.dismiss) var dismiss
    @ObservedObject var reminderManager: ReminderManager
    
    // 基本信息
    @State private var selectedTime = Date()
    @State private var selectedFrequency = "每小时"
    @State private var customHours = 1
    @State private var startTime = Calendar.current.date(bySettingHour: 8, minute: 0, second: 0, of: Date()) ?? Date()
    @State private var endTime = Calendar.current.date(bySettingHour: 22, minute: 0, second: 0, of: Date()) ?? Date()
    
    // 饮水详情
    @State private var waterAmount = 250 // 默认250毫升
    @State private var dailyGoal = 2000 // 默认2000毫升
    @State private var waterType = "纯净水"
    @State private var waterNotes = ""
    
    let frequencyOptions = ["每小时", "每2小时", "每3小时", "每4小时", "自定义"]
    let waterTypes = ["纯净水", "矿泉水", "茶水", "果汁", "功能性饮料", "其他"]
    let amountOptions = Array(stride(from: 100, through: 500, by: 50)) // 从100ml到500ml，步长为50ml
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("基本信息")) {
                    DatePicker("开始提醒时间", selection: $startTime, displayedComponents: .hourAndMinute)
                    DatePicker("结束提醒时间", selection: $endTime, displayedComponents: .hourAndMinute)
                }
                
                Section(header: Text("饮水详情")) {
                    Picker("每次饮水量", selection: $waterAmount) {
                        ForEach(amountOptions, id: \.self) { amount in
                            Text("\(amount)毫升").tag(amount)
                        }
                    }
                    
                    Stepper("每日目标: \(dailyGoal)毫升", value: $dailyGoal, in: 500...5000, step: 100)
                    
                    Picker("饮用水类型", selection: $waterType) {
                        ForEach(waterTypes, id: \.self) { type in
                            Text(type).tag(type)
                        }
                    }
                }
                
                Section(header: Text("提醒频率")) {
                    Picker("重复", selection: $selectedFrequency) {
                        ForEach(frequencyOptions, id: \.self) { option in
                            Text(option).tag(option)
                        }
                    }
                    
                    if selectedFrequency == "自定义" {
                        Stepper("每\(customHours)小时", value: $customHours, in: 1...12)
                    }
                }
                
                Section(header: Text("备注")) {
                    TextEditor(text: $waterNotes)
                        .frame(minHeight: 100)
                }
            }
            .navigationTitle("添加饮水提醒")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("取消") {
                        dismiss()
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("保存") {
                        saveReminder()
                    }
                }
            }
        }
    }
    
    private func saveReminder() {
        // 构建详细描述字符串
        var description = "类型：\(waterType)\n每次：\(waterAmount)毫升\n每日目标：\(dailyGoal)毫升"
        
        if !waterNotes.isEmpty {
            description += "\n备注：\(waterNotes)"
        }
        
        // 获取提醒间隔小时数
        let intervalHours: Int
        switch selectedFrequency {
        case "每小时":
            intervalHours = 1
        case "每2小时":
            intervalHours = 2
        case "每3小时":
            intervalHours = 3
        case "每4小时":
            intervalHours = 4
        case "自定义":
            intervalHours = customHours
        default:
            intervalHours = 1
        }
        
        // 创建多个提醒，从开始时间到结束时间，按照间隔创建
        let calendar = Calendar.current
        let startComponents = calendar.dateComponents([.hour, .minute], from: startTime)
        let endComponents = calendar.dateComponents([.hour, .minute], from: endTime)
        
        guard let startHour = startComponents.hour,
              let startMinute = startComponents.minute,
              let endHour = endComponents.hour,
              let endMinute = endComponents.minute else {
            return
        }
        
        let startTimeInMinutes = startHour * 60 + startMinute
        let endTimeInMinutes = endHour * 60 + endMinute
        
        // 如果结束时间早于或等于开始时间，则不创建提醒
        if endTimeInMinutes <= startTimeInMinutes {
            return
        }
        
        // 在指定的时间范围内创建提醒
        var currentTimeInMinutes = startTimeInMinutes
        while currentTimeInMinutes < endTimeInMinutes {
            let hour = currentTimeInMinutes / 60
            let minute = currentTimeInMinutes % 60
            
            if let reminderDate = calendar.date(bySettingHour: hour, minute: minute, second: 0, of: Date()) {
                let reminder = Reminder(
                    title: "饮水提醒",
                    date: reminderDate,
                    description: description,
                    type: NSLocalizedString("water_reminder", comment: "")
                )
                
                reminderManager.addReminder(reminder)
            }
            
            // 增加时间间隔
            currentTimeInMinutes += intervalHours * 60
        }
        
        // 关闭视图
        dismiss()
    }
} 