import Foundation

class DoctorOrderStorage {
    static let shared = DoctorOrderStorage()
    private let defaults = UserDefaults.standard
    private let key = "savedDoctorOrders"
    
    func saveOrders(_ orders: [DoctorOrder]) {
        // 去重处理
        let uniqueIds = Set(orders.map { $0.id })
        var uniqueOrders: [DoctorOrder] = []
        
        // 确保每个ID只保留一个医嘱
        for id in uniqueIds {
            if let order = orders.first(where: { $0.id == id }) {
                uniqueOrders.append(order)
            }
        }
        
        // 保存去重后的数据
        if let encoded = try? JSONEncoder().encode(uniqueOrders) {
            defaults.set(encoded, forKey: key)
        }
    }
    
    func loadOrders() -> [DoctorOrder] {
        if let data = defaults.data(forKey: key),
           let decoded = try? JSONDecoder().decode([DoctorOrder].self, from: data) {
            return decoded
        }
        return []
    }
    
    func loadOrders(for recordId: UUID) -> [DoctorOrder] {
        let allOrders = loadOrders()
        
        // 过滤并去重
        let filteredOrders = allOrders.filter { $0.recordId == recordId }
        let uniqueIds = Set(filteredOrders.map { $0.id })
        
        // 确保每个ID只保留一个医嘱
        var uniqueOrders: [DoctorOrder] = []
        for id in uniqueIds {
            if let order = filteredOrders.first(where: { $0.id == id }) {
                uniqueOrders.append(order)
            }
        }
        
        return uniqueOrders
    }
} 