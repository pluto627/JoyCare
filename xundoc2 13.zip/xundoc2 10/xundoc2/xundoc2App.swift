import SwiftUI
import CoreData
import UserNotifications

// 修改主App结构
@main
struct xundoc2App: App {
    @Environment(\.scenePhase) var scenePhase
    @StateObject private var languageManager = LanguageManager()
    
    init() {
        // 请求通知权限
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { granted, error in
            if granted {
                print("通知权限已被用户授权")
            } else if let error = error {
                print("通知权限请求失败: \(error.localizedDescription)")
            }
        }
        
        // 设置通知中心代理
        UNUserNotificationCenter.current().delegate = NotificationDelegate.shared
        
        // 在应用启动时设置语言
        setupLanguage()
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(languageManager)
                .id(languageManager.refreshToken) // 这会在refreshToken变化时完全重建视图
                .onAppear {
                    // 打印当前语言设置，用于调试
                    print("App launched with language: \(languageManager.currentLanguage.rawValue)")
                    print("AppleLanguages: \(UserDefaults.standard.array(forKey: "AppleLanguages") ?? [])")
                    print("AppleLocale: \(UserDefaults.standard.string(forKey: "AppleLocale") ?? "nil")")
                }
        }
        .onChange(of: scenePhase) { newPhase in
            switch newPhase {
            case .active:
                print("App is active")
            case .inactive:
                print("App is inactive")
            case .background:
                print("App is in background")
            @unknown default:
                print("Unknown scene phase")
            }
        }
    }
    
    private func setupLanguage() {
        // 从UserDefaults读取保存的语言设置
        let savedLanguage = UserDefaults.standard.string(forKey: "appLanguage") ?? "zh"
        let language = LanguageManager.Language(rawValue: savedLanguage) ?? .chinese
        
        print("Setting up app with language: \(language.rawValue)")
        
        // 设置应用程序的语言
        UserDefaults.standard.set([language.rawValue], forKey: "AppleLanguages")
        UserDefaults.standard.set(language.rawValue, forKey: "AppleLocale")
        UserDefaults.standard.synchronize()
        
        // 强制刷新Bundle以重新加载本地化资源
        Bundle.main.localizedString(forKey: "", value: nil, table: nil)
        
        // 测试本地化是否生效
        let testKey = "medical_record"
        let localizedValue = NSLocalizedString(testKey, comment: "")
        print("Test localization at app launch: \(testKey) = \(localizedValue)")
    }
}

// 通知代理类
class NotificationDelegate: NSObject, UNUserNotificationCenterDelegate {
    static let shared = NotificationDelegate()
    
    // 应用在前台时也显示通知
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.banner, .sound, .badge])
    }
    
    // 处理用户点击通知的事件
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        // 可以在这里处理用户点击通知的逻辑
        completionHandler()
    }
}
