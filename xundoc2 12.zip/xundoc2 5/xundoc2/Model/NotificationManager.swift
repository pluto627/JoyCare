import Foundation
import UserNotifications

class NotificationManager {
    static let shared = NotificationManager()
    
    func requestAuthorization() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
            if granted {
                print("通知权限获取成功")
            }
        }
    }
    
    func scheduleReminderNotification(for reminder: Reminder) {
        let content = UNMutableNotificationContent()
        content.title = "温馨提醒"
        content.subtitle = reminder.title
        
        // 根据提醒类型设置不同的提示语
        if reminder.title.contains("用药") {
            content.body = "亲爱的，该吃药啦，按时服药才能更快康复哦 💊"
        } else if reminder.title.contains("检测") {
            content.body = "亲爱的，该做健康检测啦，关注健康从现在开始 ❤️"
        } else if reminder.title.contains("就医") {
            content.body = "亲爱的，该去看医生啦，及时就医是对健康负责 🏥"
        } else {
            content.body = "亲爱的，记得完成今天的健康任务哦 ✨"
        }
        
        content.sound = .default
        
        let dateComponents = Calendar.current.dateComponents([.hour, .minute], from: reminder.date)
        let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: false)
        
        let request = UNNotificationRequest(
            identifier: reminder.id.uuidString,
            content: content,
            trigger: trigger
        )
        
        UNUserNotificationCenter.current().add(request)
    }
    
    func cancelNotification(for reminderId: UUID) {
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [reminderId.uuidString])
    }
} 