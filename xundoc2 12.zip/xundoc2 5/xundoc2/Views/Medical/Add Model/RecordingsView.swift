import SwiftUI
import Speech
import CoreML
import AVFoundation

struct RecordingsView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var audioRecorder = AudioRecorder()
    @State private var showAlert = false
    @State private var recordingName = ""
    let recordId: UUID  // 添加病历ID参数
    var onSave: ((Recording) -> Void)?
    
    var body: some View {
        VStack(spacing: 20) {
            RecordingStatusView(isRecording: audioRecorder.isRecording)
            TranscriptionView(transcribedText: audioRecorder.transcribedText)
            ControlButtons(
                isRecording: audioRecorder.isRecording,
                recordingName: $recordingName,
                onRecord: startRecording,
                onStop: stopRecording
            )
        }
        .padding()
        .navigationTitle("添加就诊录音")
        .alert("录音已保存", isPresented: $showAlert) {
            Button("确定") { dismiss() }
        }
        .onAppear { requestPermissions() }
    }
    
    private func startRecording() {
        audioRecorder.startRecording()
    }
    
    private func stopRecording() {
        guard let audioURL = audioRecorder.stopRecording() else { return }
        saveRecording(from: audioURL)
    }
    
    private func saveRecording(from audioURL: URL) {
        let fileName = "\(UUID().uuidString).m4a"
        let permanentURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent(fileName)
        
        do {
            // 确保目标URL不存在
            if FileManager.default.fileExists(atPath: permanentURL.path) {
                try FileManager.default.removeItem(at: permanentURL)
            }
            
            // 读取源文件数据
            let audioData = try Data(contentsOf: audioURL)
            // 写入新文件
            try audioData.write(to: permanentURL)
            
            let recording = Recording(
                id: UUID(),
                recordId: recordId,  // 添加病历ID
                name: recordingName.isEmpty ? "就诊录音" : recordingName,
                date: Date(),
                audioURL: permanentURL,
                conversation: audioRecorder.transcribedText
            )
            
            var savedRecordings = RecordingStorage.shared.loadRecordings()
            // 确保不添加重复的录音
            if !savedRecordings.contains(where: { $0.id == recording.id }) {
                savedRecordings.append(recording)
                RecordingStorage.shared.saveRecordings(savedRecordings)
            }
            
            onSave?(recording)
            showAlert = true
        } catch {
            print("保存录音失败: \(error.localizedDescription)")
        }
    }
    
    private func requestPermissions() {
        SFSpeechRecognizer.requestAuthorization { _ in }
        try? AVAudioSession.sharedInstance().requestRecordPermission { _ in }
    }
}

// 拆分子视图
struct RecordingStatusView: View {
    let isRecording: Bool
    
    var body: some View {
        if isRecording {
            Text("正在录音...")
                .font(.title)
                .foregroundColor(.red)
        }
    }
}

struct TranscriptionView: View {
    let transcribedText: [ConversationSegment]
    
    var body: some View {
        if !transcribedText.isEmpty {
            ScrollViewReader { proxy in
                ScrollView {
                    VStack(alignment: .leading, spacing: 12) {
                        ForEach(transcribedText.indices, id: \.self) { index in
                            TranscriptionRow(segment: transcribedText[index])
                                .id(index)
                        }
                    }
                    .padding()
                }
                .onChange(of: transcribedText.count) { _ in
                    withAnimation {
                        proxy.scrollTo(transcribedText.count - 1, anchor: .bottom)
                    }
                }
            }
        }
    }
}

struct TranscriptionRow: View {
    let segment: ConversationSegment
    
    var body: some View {
        HStack(alignment: .top) {
            Text(segment.speaker)
                .font(.headline)
                .foregroundColor(segment.speaker == "医生" ? .blue : .green)
                .frame(width: 60)
            
            Text(segment.content)
                .fixedSize(horizontal: false, vertical: true)
        }
    }
}

struct ControlButtons: View {
    let isRecording: Bool
    @Binding var recordingName: String
    let onRecord: () -> Void
    let onStop: () -> Void
    
    var body: some View {
        VStack {
            if !isRecording {
                TextField("录音名称", text: $recordingName)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.horizontal)
            }
            
            Button(action: {
                if isRecording {
                    onStop()
                } else {
                    onRecord()
                }
            }) {
                Image(systemName: isRecording ? "stop.circle.fill" : "record.circle.fill")
                    .font(.system(size: 64))
                    .foregroundColor(isRecording ? .red : .blue)
            }
        }
    }
}

// 音频录制管理器
class AudioRecorder: ObservableObject {
    @Published var isRecording = false
    @Published var transcribedText: [ConversationSegment] = []
    private var audioEngine = AVAudioEngine()
    private var audioFile: AVAudioFile?
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private var speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "zh-CN"))
    private var lastSpeechTime = Date()
    private var lastTranscription = ""
    private var currentSpeaker = "患者"
    private var recordingURL: URL?
    private var silenceTimer: Timer?
    private let silenceThreshold: TimeInterval = 1.5 // 调整为1.5秒的停顿检测
    
    private var currentSegment: String = ""
    private var processingTimer: Timer?
    
    private func getDocumentsDirectory() -> URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }
    
    func startRecording() {
        guard let recognizer = speechRecognizer, recognizer.isAvailable else {
            print("Speech recognition not available")
            return
        }
        
        // 创建新的录音文件URL
        let fileName = "\(Date().timeIntervalSince1970).m4a"
        recordingURL = getDocumentsDirectory().appendingPathComponent(fileName)
        
        do {
            let audioSession = AVAudioSession.sharedInstance()
            try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
            
            let settings: [String: Any] = [
                AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
                AVSampleRateKey: 44100.0,
                AVNumberOfChannelsKey: 1,
                AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue,
                AVEncoderBitRateKey: 128000
            ]
            
            guard let recordingURL = recordingURL else { return }
            audioFile = try AVAudioFile(forWriting: recordingURL, settings: settings)
            
            recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
            guard let recognitionRequest = recognitionRequest else { return }
            
            let inputNode = audioEngine.inputNode
            recognitionRequest.shouldReportPartialResults = true
            
            recognitionTask = recognizer.recognitionTask(with: recognitionRequest) { [weak self] result, error in
                guard let self = self else { return }
                if let result = result {
                    let transcription = result.bestTranscription.formattedString
                    
                    // 重置处理计时器
                    self.processingTimer?.invalidate()
                    self.processingTimer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: false) { [weak self] _ in
                        guard let self = self else { return }
                        
                        // 检测到新的完整句子
                        if let newSentence = self.extractNewSentence(from: transcription) {
                            self.currentSegment = ""  // 清空当前段落
                            
                            DispatchQueue.main.async {
                                let segment = ConversationSegment(
                                    speaker: self.currentSpeaker,
                                    content: newSentence,
                                    timestamp: Date()
                                )
                                self.transcribedText.append(segment)
                                
                                // 检查是否需要切换说话者
                                self.silenceTimer?.invalidate()
                                self.silenceTimer = Timer.scheduledTimer(withTimeInterval: self.silenceThreshold, repeats: false) { [weak self] _ in
                                    guard let self = self else { return }
                                    self.currentSpeaker = self.currentSpeaker == "患者" ? "医生" : "患者"
                                }
                            }
                        }
                    }
                }
            }
            
            let recordingFormat = inputNode.outputFormat(forBus: 0)
            inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { [weak self] buffer, _ in
                guard let self = self else { return }
                recognitionRequest.append(buffer)
                try? self.audioFile?.write(from: buffer)
            }
            
            audioEngine.prepare()
            try audioEngine.start()
            isRecording = true
            
        } catch {
            print("Recording failed: \(error.localizedDescription)")
        }
    }
    
    private func extractNewSentence(from transcription: String) -> String? {
        // 按句号、逗号等分割文本
        let separators = CharacterSet(charactersIn: "。，,.!?！？")
        let sentences = transcription.components(separatedBy: separators)
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
        
        // 如果有新的完整句子
        if let lastSentence = sentences.last,
           !lastSentence.isEmpty,
           lastSentence != currentSegment {
            currentSegment = lastSentence
            return lastSentence
        }
        
        return nil
    }
    
    func stopRecording() -> URL? {
        processingTimer?.invalidate()
        processingTimer = nil
        silenceTimer?.invalidate()
        silenceTimer = nil
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)
        recognitionRequest?.endAudio()
        recognitionTask?.cancel()
        isRecording = false
        return recordingURL
    }
}

#Preview {
    NavigationView {
        RecordingsView(recordId: UUID()) // 添加测试用的 UUID
    }
}
