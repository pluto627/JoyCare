import SwiftUI

struct MedicationDetailView: View {
    @Environment(\.dismiss) var dismiss
    @ObservedObject var reminderManager: ReminderManager
    let records: [Reminder]
    var doctorOrder: DoctorOrder?
    @State private var isShowingDiagnosis = false
    
    var body: some View {
        VStack(spacing: 0) {
            // 顶部标题栏
            HStack {
                Text("用药详情")
                    .font(.title2)
                    .bold()
                Spacer()
                Button(action: { dismiss() }) {
                    Image(systemName: "xmark")
                        .foregroundColor(.gray)
                }
            }
            .padding()
            
            ScrollView {
                VStack(spacing: 20) {
                    // 药品信息卡片
                    VStack(alignment: .leading, spacing: 16) {
                        HStack {
                            Image(systemName: "pills.circle.fill")
                                .foregroundColor(.purple)
                                .font(.title2)
                            Text(records.first?.title ?? "")
                                .font(.title3)
                                .bold()
                        }
                        
                        // 用药信息
                        VStack(alignment: .leading, spacing: 12) {
                            infoRow(title: "用药剂量", value: "\(records.first?.dosage ?? "")  \(records.first?.unit ?? "")")
                            infoRow(title: "服用时间", value: records.first?.beforeOrAfterMeal ?? "")
                            infoRow(title: "每日次数", value: "\(records.count)次")
                        }
                        
                        // 服药时间表
                        VStack(alignment: .leading, spacing: 8) {
                            Text("服药时间表")
                                .foregroundColor(.gray)
                            
                            HStack(spacing: 12) {
                                ForEach(records.sorted(by: { $0.date < $1.date }), id: \.id) { record in
                                    Text(formatTime(record.date))
                                        .font(.system(size: 14))
                                        .padding(.horizontal, 12)
                                        .padding(.vertical, 6)
                                        .background(Color.purple.opacity(0.1))
                                        .foregroundColor(.purple)
                                        .cornerRadius(20)
                                }
                            }
                        }
                    }
                    .padding()
                    .background(Color(hex: "FAFAFA"))
                    .cornerRadius(20)
                    .shadow(color: Color.black.opacity(0.05), radius: 5, x: 0, y: 2)
                    
                    // 修改诊断信息卡片
                    if let order = doctorOrder {
                        VStack(alignment: .leading, spacing: 16) {
                            // 诊断信息标题栏（可点击展开/收起）
                            Button(action: {
                                withAnimation {
                                    isShowingDiagnosis.toggle()
                                }
                            }) {
                                HStack {
                                    Image(systemName: "stethoscope")
                                        .foregroundColor(.blue)
                                        .font(.title2)
                                    Text("诊断信息")
                                        .font(.title3)
                                        .bold()
                                    Spacer()
                                    Image(systemName: isShowingDiagnosis ? "chevron.up" : "chevron.down")
                                        .foregroundColor(.gray)
                                }
                            }
                            .foregroundColor(.primary)
                            
                            // 诊断详细信息（可折叠）
                            if isShowingDiagnosis {
                                VStack(alignment: .leading, spacing: 12) {
                                    if let diagnosis = order.diagnosis {
                                        HStack(alignment: .top, spacing: 12) {
                                            // 添加医嘱照片显示
                                            if let imageData = order.imageData,
                                               let uiImage = UIImage(data: imageData) {
                                                Image(uiImage: uiImage)
                                                    .resizable()
                                                    .scaledToFill()
                                                    .frame(width: 60, height: 60)
                                                    .clipShape(RoundedRectangle(cornerRadius: 8))
                                                    .overlay(
                                                        RoundedRectangle(cornerRadius: 8)
                                                            .stroke(Color.gray.opacity(0.2), lineWidth: 1)
                                                    )
                                            }
                                            
                                            // 诊断信息
                                            diagnosisRow(title: "初步诊断", value: diagnosis)
                                        }
                                    }
                                    
                                    if let symptoms = order.symptoms {
                                        diagnosisRow(title: "症状描述", value: symptoms)
                                    }
                                    
                                    if let recommendations = order.recommendations {
                                        diagnosisRow(title: "医生建议", value: recommendations)
                                    }
                                }
                                .transition(.opacity.combined(with: .move(edge: .top)))
                            }
                        }
                        .padding()
                        .background(Color(hex: "F5F8FF"))
                        .cornerRadius(20)
                        .shadow(color: Color.black.opacity(0.05), radius: 5, x: 0, y: 2)
                    }
                }
                .padding()
            }
        }
    }
    
    private func infoRow(title: String, value: String) -> some View {
        HStack {
            Text(title)
                .foregroundColor(.gray)
            Spacer()
            Text(value)
                .foregroundColor(.black)
        }
    }
    
    private func formatTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        return formatter.string(from: date)
    }
    
    private func diagnosisRow(title: String, value: String) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .foregroundColor(.gray)
                .font(.subheadline)
            Text(value)
                .foregroundColor(.black)
                .font(.body)
        }
        .padding(.vertical, 4)
    }
} 

