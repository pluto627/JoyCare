import SwiftUI
import UIKit

// ShareSheet 包装器
struct ShareSheet: UIViewControllerRepresentable {
    let activityItems: [Any]
    
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
    }
    
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

// 数据模型

// 修改后的主视图
struct MedicalMainView: View {
    @State private var showingMedicalRecord = false
    @State private var medicalRecords: [MedicalRecord] = []
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 16) {
                    Text("就诊记录")
                        .font(.system(size: 34))
                        .fontWeight(.bold)
                        .padding(.top, 20)
                        .padding(.horizontal)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    
                    // 就诊记录列表
                    ForEach(medicalRecords.sorted(by: { $0.date > $1.date })) { record in
                        MedicalRecordCard(record: record, medicalRecords: $medicalRecords)
                            .padding(.horizontal)
                    }
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        showingMedicalRecord = true
                    }) {
                        HStack(spacing: 6) {
                            Image(systemName: "plus")
                            Text("新增")
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 10)
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(16)
                    }
                }
            }
            .sheet(isPresented: $showingMedicalRecord) {
                AddMedicalRecordView(medicalRecords: $medicalRecords)
                    .presentationDetents([.medium])
                    .presentationDragIndicator(.visible)
            }
        }
        .onAppear {
            // 加载保存的记录
            medicalRecords = MedicalRecordStorage.shared.loadRecords()
        }
    }
}


// 记录卡片视图
struct MedicalRecordCard: View {
    let record: MedicalRecord
    @Binding var medicalRecords: [MedicalRecord]
    @State private var showingDeleteAlert = false
    @State private var showingSharePDF = false
    @State private var navigateToDetail = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text(formatDate(record.date))
                    .foregroundColor(.secondary)
                    .padding(.leading, 4)
                Text(record.department)
                    .font(.subheadline)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(Color.blue.opacity(0.1))
                    .foregroundColor(.blue)
                    .cornerRadius(4)
                
                Spacer()
                
                Menu {
                    Button(action: {
                        navigateToDetail = true
                    }) {
                        Label("查看详情", systemImage: "doc.text.magnifyingglass")
                    }
                    
                    Button(action: {
                        showingSharePDF = true
                    }) {
                        Label("分享PDF", systemImage: "square.and.arrow.up")
                    }
                    
                    Button(role: .destructive, action: {
                        showingDeleteAlert = true
                    }) {
                        Label("删除", systemImage: "trash")
                    }
                } label: {
                    ZStack {
                        Image(systemName: "circle")
                            .foregroundColor(Color(UIColor.systemGray4).opacity(0.6))
                            .font(.system(size: 22))
                        
                        Image(systemName: "ellipsis")
                            .foregroundColor(Color.primary.opacity(0.4))
                            .font(.system(size: 12))
                    }
                    .padding(2)
                    .background(Color(hex: "FAFAFA"))
                    .clipShape(Circle())
                    .padding(.trailing, -2)
                }
                .menuStyle(BorderlessButtonMenuStyle())
                .menuIndicator(.hidden)
            }
            
            Text(record.hospital)
                .font(.title3)
            
            HStack {
                Text("主要症状：")
                    .foregroundColor(.secondary)
                Text(record.symptoms)
            }
        }
        .padding()
        .background(Color(hex: "FAFAFA"))
        .cornerRadius(8)
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(Color(UIColor.systemGray4), lineWidth: 0.5)
        )
        .padding(.bottom, 10)
        .background(
            NavigationLink(
                destination: MedicalRecordDetailView(record: record),
                isActive: $navigateToDetail,
                label: { EmptyView() }
            )
        )
        .onTapGesture {
            navigateToDetail = true
        }
        .alert("确认删除", isPresented: $showingDeleteAlert) {
            Button("取消", role: .cancel) { }
            Button("删除", role: .destructive) {
                deleteRecord()
            }
        } message: {
            Text("确定要删除这条就诊记录吗？")
        }
        .sheet(isPresented: $showingSharePDF) {
            ShareSheet(activityItems: [generatePDF()])
        }
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "M/d/yyyy"
        return formatter.string(from: date)
    }
    
    private func deleteRecord() {
        if let index = medicalRecords.firstIndex(where: { $0.id == record.id }) {
            medicalRecords.remove(at: index)
            // 保存更改
            MedicalRecordStorage.shared.saveRecords(medicalRecords)
        }
    }
    
    private func generatePDF() -> Data {
        let pdfMetaData = [
            kCGPDFContextCreator: "就诊记录",
            kCGPDFContextAuthor: "XunDoc"
        ]
        let format = UIGraphicsPDFRendererFormat()
        format.documentInfo = pdfMetaData as [String: Any]
        
        let pageWidth = 8.27 * 72.0 // A4 宽度
        let pageHeight = 11.69 * 72.0 // A4 高度
        let pageRect = CGRect(x: 0, y: 0, width: pageWidth, height: pageHeight)
        
        let renderer = UIGraphicsPDFRenderer(bounds: pageRect, format: format)
        
        return renderer.pdfData { (context) in
            context.beginPage()
            
            let titleFont = UIFont.boldSystemFont(ofSize: 24)
            let normalFont = UIFont.systemFont(ofSize: 14)
            
            let titleText = "就诊记录"
            let titleAttributes: [NSAttributedString.Key: Any] = [
                .font: titleFont,
                .foregroundColor: UIColor.black
            ]
            titleText.draw(at: CGPoint(x: 30, y: 30), withAttributes: titleAttributes)
            
            let contentAttributes: [NSAttributedString.Key: Any] = [
                .font: normalFont,
                .foregroundColor: UIColor.black
            ]
            
            let content = """
            
            医院：\(record.hospital)
            科室：\(record.department)
            就诊时间：\(formatDate(record.date))
            医院地址：\(record.hospitalAddress)
            
            主要症状：
            \(record.symptoms)
            
            用药时间：
            \(record.medicationTimes.joined(separator: ", "))
            每日服用次数：\(record.dailyDoses)次
            """
            
            content.draw(at: CGPoint(x: 30, y: 70), withAttributes: contentAttributes)
        }
    }
}

// 如果您的项目中还没有 Color hex 扩展，需要添加以下扩展：

// Preview Provider
struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        MedicalMainView()
    }
}




public struct MedicalRecord: Identifiable, Codable {
    public let id: UUID
    public let date: Date
    public let hospital: String
    public let department: String
    public let symptoms: String
    public let hospitalAddress: String
    public let medicationTimes: [String] // 新增用药时间数组
    public let dailyDoses: Int // 新增每日服用次数
    
    public init(id: UUID = UUID(), 
               date: Date, 
               hospital: String, 
               department: String, 
               symptoms: String, 
               hospitalAddress: String,
               medicationTimes: [String] = ["08:00", "12:00", "20:00", "22:00"],
               dailyDoses: Int = 4) {
        self.id = id
        self.date = date
        self.hospital = hospital
        self.department = department
        self.symptoms = symptoms
        self.hospitalAddress = hospitalAddress
        self.medicationTimes = medicationTimes
        self.dailyDoses = dailyDoses
    }
} 
