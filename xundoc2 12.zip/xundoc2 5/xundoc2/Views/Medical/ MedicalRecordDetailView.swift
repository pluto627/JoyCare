import SwiftUI
import AVFoundation

struct MedicalRecordDetailView: View {
    let record: MedicalRecord
    @State private var showingEditSheet = false
    @State private var showFloatingMenu = false
    @State private var reports: [MedicalReport] = []
    @State private var recordings: [Recording] = []
    @State private var orders: [DoctorOrder] = []
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                // 顶部医院信息卡片
                HospitalInfoCard(record: record)
                
                // 症状详情
                DetailCard(
                    title: "症状详情",
                    icon: "lungs.fill",
                    iconColor: .blue
                ) {
                    VStack(alignment: .leading, spacing: 8) {
                        Text(record.symptoms)
                            .lineSpacing(6)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
                
                // 主要信息部分
                VStack(spacing: 16) {
                    // 就诊录音
                    if !recordings.isEmpty {
                        DetailCard(
                            title: "就诊录音",
                            icon: "waveform",
                            iconColor: .orange
                        ) {
                            ForEach(recordings) { recording in
                                RecordingRow(recording: recording) {
                                    deleteRecording(recording)
                                }
                            }
                        }
                    }
                    
                    // 检查报告
                    if !reports.isEmpty {
                        DetailCard(
                            title: "检查报告",
                            icon: "doc.text.fill",
                            iconColor: .green
                        ) {
                            ForEach(reports) { report in
                                ReportRow(report: report) {
                                    deleteReport(report)
                                }
                            }
                        }
                    }
                    
                    // 添加医嘱卡片
                    if !orders.isEmpty {
                        DetailCard(
                            title: "医生医嘱",
                            icon: "list.clipboard.fill",
                            iconColor: .blue
                        ) {
                            ForEach(orders) { order in
                                OrderRow(order: order) {
                                    deleteOrder(order)
                                }
                            }
                        }
                    }
                }
            }
            .padding()
        }
        .navigationTitle("就诊记录")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                EditButton(showingEditSheet: $showingEditSheet, record: record)
            }
        }
        .sheet(isPresented: $showingEditSheet) {
            EditMedicalRecordView(record: record)
        }
        .overlay(
            FloatingButton(
                recordId: record.id,
                showMenu: $showFloatingMenu,
                reports: $reports,
                recordings: $recordings,
                orders: $orders
            )
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomTrailing)
        )
        .onAppear {
            // 加载数据
            orders = DoctorOrderStorage.shared.loadOrders(for: record.id)
            reports = ReportStorage.shared.loadReports(for: record.id)
            recordings = RecordingStorage.shared.loadRecordings(for: record.id)
        }
    }
    
    // 添加删除方法
    private func deleteReport(_ report: MedicalReport) {
        if let index = reports.firstIndex(where: { $0.id == report.id }) {
            reports.remove(at: index)
            ReportStorage.shared.saveReports(reports)
        }
    }
    
    private func deleteRecording(_ recording: Recording) {
        if let index = recordings.firstIndex(where: { $0.id == recording.id }) {
            recordings.remove(at: index)
            RecordingStorage.shared.deleteRecording(recording)
        }
    }
    
    private func deleteOrder(_ order: DoctorOrder) {
        if let index = orders.firstIndex(where: { $0.id == order.id }) {
            orders.remove(at: index)
            var savedOrders = DoctorOrderStorage.shared.loadOrders()
            savedOrders.removeAll { $0.id == order.id }
            DoctorOrderStorage.shared.saveOrders(savedOrders)
        }
    }
}

// MARK: - 子视图组件

struct HospitalInfoCard: View {
    let record: MedicalRecord
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text(record.hospital)
                    .font(.title3)
            }
            
            HStack(spacing: 16) {
                TagView(text: record.department, icon: "cross.case.fill")
                
                Divider()
                    .frame(height: 20)
                
                HStack {
                    Image(systemName: "calendar")
                        .foregroundColor(.gray)
                    Text(formatDate(record.date))
                        .foregroundColor(.gray)
                }
            }
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(hex: "FAFAFA"))
        .cornerRadius(16)
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(Color(UIColor.systemGray4), lineWidth: 0.5)
        )
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy年MM月dd日 HH:mm:ss"
        return formatter.string(from: date)
    }
}

struct DetailCard<Content: View>: View {
    let title: String
    let icon: String
    let iconColor: Color
    let content: Content
    
    init(
        title: String,
        icon: String,
        iconColor: Color,
        @ViewBuilder content: () -> Content
    ) {
        self.title = title
        self.icon = icon
        self.iconColor = iconColor
        self.content = content()
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Image(systemName: icon)
                    .foregroundColor(iconColor)
                Text(title)
                    .font(.headline)
            }
            
            content
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(hex: "FAFAFA"))
        .cornerRadius(16)
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(Color(UIColor.systemGray4), lineWidth: 0.5)
        )
    }
}

struct TagView: View {
    let text: String
    let icon: String
    
    var body: some View {
        HStack(spacing: 4) {
            Image(systemName: icon)
                .foregroundColor(.blue)
            Text(text)
                .foregroundColor(.blue)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 6)
        .background(Color.blue.opacity(0.1))
        .cornerRadius(8)
    }
}

struct DiagnosisRow: View {
    let title: String
    let content: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.subheadline)
                .foregroundColor(.gray)
            Text(content)
                .fixedSize(horizontal: false, vertical: true)
        }
    }
}

struct PrescriptionRow: View {
    let prescription: Prescription
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(prescription.name)
                .font(.system(.body, design: .rounded))
                .fontWeight(.medium)
            
            HStack {
                Text("用法：\(prescription.usage)")
                Spacer()
                Text("数量：\(prescription.quantity)")
            }
            .font(.subheadline)
            .foregroundColor(.gray)
            
            Divider()
        }
    }
}

struct EditButton: View {
    @Binding var showingEditSheet: Bool
    let record: MedicalRecord
    
    var body: some View {
        Button(action: {
            showingEditSheet = true
        }) {
            Text("修改")
                .foregroundColor(.blue)
        }
    }
}

// MARK: - 浮动按钮菜单
struct FloatingButton: View {
    let recordId: UUID
    @Binding var showMenu: Bool
    @Binding var reports: [MedicalReport]
    @Binding var recordings: [Recording]
    @Binding var orders: [DoctorOrder]
    
    @State private var navigateToOrders = false
    @State private var navigateToRecordings = false
    @State private var navigateToReports = false
    
    var body: some View {
        ZStack(alignment: .bottomTrailing) {
            // 菜单背景
            if showMenu {
                Color.black.opacity(0.2)
                    .ignoresSafeArea()
                    .onTapGesture {
                        withAnimation(.easeOut(duration: 0.2)) {
                            showMenu = false
                        }
                    }
            }
            
            VStack(alignment: .trailing, spacing: 10) {
                // 菜单选项
                if showMenu {
                    
                    MenuButton(
                        title: "添加就诊录音",
                        icon: "microphone",
                        color: .orange,
                        action: { navigateToRecordings = true }
                    )
                    
                    MenuButton(
                        title: "添加检查报告",
                        icon: "doc.text.fill",
                        color: .purple,
                        action: { navigateToReports = true }
                    )
                    
                    MenuButton(
                        title: "添加医生处方",
                        icon: "doc.text.below.ecg",
                        color: .blue,
                        action: { navigateToOrders = true }
                    )
                    
                }
                
                    

                
                // 主按钮 - 保持固定
                Button(action: {
                    withAnimation(.easeInOut(duration: 0.2)) {
                        showMenu.toggle()
                    }
                }) {
                    Image(systemName: "plus")
                        .font(.system(size: 24, weight: .semibold))
                        .foregroundColor(.white)
                        .frame(width: 56, height: 56)
                        .background(Color.blue)
                        .clipShape(Circle())
                        .shadow(color: .black.opacity(0.2), radius: 4)
                }
            }
            .padding()
        }
        NavigationLink(isActive: $navigateToOrders) {
            DoctorOrdersView(recordId: recordId) { newOrder in
                orders.append(newOrder)
                var savedOrders = DoctorOrderStorage.shared.loadOrders()
                savedOrders.append(newOrder)
                DoctorOrderStorage.shared.saveOrders(savedOrders)
            }
        } label: { EmptyView() }

        NavigationLink(isActive: $navigateToRecordings) {
            RecordingsView(recordId: recordId) { newRecording in
                // 创建带有病历ID的新录音
                let recordingWithId = Recording(
                    id: newRecording.id,
                    recordId: recordId,  // 添加病历ID
                    name: newRecording.name,
                    date: newRecording.date,
                    audioURL: newRecording.audioURL,
                    conversation: newRecording.conversation
                )
                recordings.append(recordingWithId)
                var savedRecordings = RecordingStorage.shared.loadRecordings()
                savedRecordings.append(recordingWithId)
                RecordingStorage.shared.saveRecordings(savedRecordings)
            }
        } label: { EmptyView() }

        NavigationLink(isActive: $navigateToReports) {
            MedicalReportsView(recordId: recordId) { newReport in
                reports.append(newReport)
                var savedReports = ReportStorage.shared.loadReports()
                savedReports.append(newReport)
                ReportStorage.shared.saveReports(savedReports)
            }
        } label: { EmptyView() }
    }
}

struct MenuButton: View {
    let title: String
    let icon: String
    let color: Color
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Text(title)
                    .font(.system(size: 16, weight: .medium))
                Image(systemName: icon)
                    .font(.system(size: 16, weight: .medium))
            }
            .foregroundColor(.white)
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .background(color)
            .cornerRadius(25)
            .shadow(color: color.opacity(0.3), radius: 4)
        }
        .transition(.opacity.combined(with: .move(edge: .trailing)))
    }
}

// MARK: - 功能页面

// MARK: - 数据模型扩展

struct Prescription {
    let name: String
    let usage: String
    let quantity: String
}

struct MedicalReport: Codable, Identifiable {
    let id: UUID
    let recordId: UUID  // 添加关联的病历ID
    let type: String
    let date: Date
    let imageData: [Data]
    
    var images: [UIImage] {
        imageData.compactMap { UIImage(data: $0) }
    }
    
    init(id: UUID = UUID(), recordId: UUID, type: String, date: Date, images: [UIImage]) {
        self.id = id
        self.recordId = recordId
        self.type = type
        self.date = date
        self.imageData = images.compactMap { $0.jpegData(compressionQuality: 0.7) }
    }
}

class ReportStorage {
    static let shared = ReportStorage()
    private let defaults = UserDefaults.standard
    private let key = "savedMedicalReports"
    
    func saveReports(_ reports: [MedicalReport]) {
        if let encoded = try? JSONEncoder().encode(reports) {
            defaults.set(encoded, forKey: key)
        }
    }
    
    func loadReports() -> [MedicalReport] {
        if let data = defaults.data(forKey: key),
           let decoded = try? JSONDecoder().decode([MedicalReport].self, from: data) {
            return decoded
        }
        return []
    }
    
    func loadReports(for recordId: UUID) -> [MedicalReport] {
        let allReports = loadReports()
        return allReports.filter { $0.recordId == recordId }
    }
}

extension MedicalRecord {
    var diagnosis: String? { nil }  // 示例数据，实际应从模型中获取
    var suggestion: String? { nil }
    var prescriptions: [Prescription]? { nil }
    var notes: String? { nil }
    var reports: [MedicalReport]? { nil }
    
    var shareText: String {
        """
        医院：\(hospital)
        科室：\(department)
        就诊时间：\(formatDate(date))
        症状：\(symptoms)
        """
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy年MM月dd日 HH:mm:ss"
        return formatter.string(from: date)
    }
}

// MARK: - 预览


// 添加 ReportRow 视图组件
struct ReportRow: View {
    let report: MedicalReport
    let onDelete: () -> Void
    @State private var showingDeleteAlert = false
    @State private var selectedImage: UIImage?
    @State private var showingFullScreenImage = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            ForEach(report.images.indices, id: \.self) { index in
                HStack(spacing: 12) {
                    // 缩略图
                    Image(uiImage: report.images[index])
                        .resizable()
                        .scaledToFill()
                        .frame(width: 90, height: 90)  // 缩小到90x90
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                        .onTapGesture {
                            selectedImage = report.images[index]
                            showingFullScreenImage = true
                        }
                    
                    // 报告信息
                    VStack(alignment: .leading, spacing: 8) {
                        Text(report.type)
                            .font(.headline)
                        Text(formatDate(report.date))
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }
                    
                    Spacer()
                }
            }
            
            Divider()
        }
        .padding(.vertical, 8)
        .contentShape(Rectangle())
        .onLongPressGesture {
            showingDeleteAlert = true
        }
        .alert("删除报告", isPresented: $showingDeleteAlert) {
            Button("删除", role: .destructive) {
                onDelete()
            }
            Button("取消", role: .cancel) { }
        } message: {
            Text("确定要删除这份检查报告吗？此操作不可撤销。")
        }
        .fullScreenCover(isPresented: $showingFullScreenImage, content: {
            ZStack {
                Color.black.ignoresSafeArea()
                
                if let image = selectedImage {
                    Image(uiImage: image)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                }
                
                VStack {
                    HStack {
                        Spacer()
                        Button(action: {
                            showingFullScreenImage = false
                        }) {
                            Image(systemName: "xmark")
                                .font(.title2)
                                .foregroundColor(.white)
                                .padding()
                        }
                    }
                    Spacer()
                }
            }
        })
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy年MM月dd日 HH:mm:ss"
        return formatter.string(from: date)
    }
}

struct RecordingRow: View {
    let recording: Recording
    let onDelete: () -> Void
    @State private var showingDeleteAlert = false
    @State private var isExpanded = false
    @State private var audioPlayer: AVAudioPlayer?
    @State private var isPlaying = false
    
    var sortedConversation: [ConversationSegment] {
        recording.conversation.sorted { $0.timestamp < $1.timestamp }
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(recording.name)
                    .font(.headline)
                Spacer()
                
                // 添加播放按钮
                Button(action: togglePlayback) {
                    Image(systemName: isPlaying ? "pause.circle.fill" : "play.circle.fill")
                        .font(.title2)
                        .foregroundColor(.blue)
                }
                
                Text(formatDate(recording.date))
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
            
            if isExpanded {
                VStack(alignment: .leading, spacing: 12) {
                    ForEach(sortedConversation, id: \.timestamp) { segment in
                        HStack(alignment: .top) {
                            Text(segment.speaker)
                                .font(.subheadline)
                                .foregroundColor(segment.speaker == "医生" ? .blue : .green)
                                .frame(width: 60)
                            
                            Text(segment.content)
                                .font(.subheadline)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    }
                }
                .padding(.vertical, 8)
            }
            
            Divider()
        }
        .padding(.vertical, 8)
        .contentShape(Rectangle())
        .onTapGesture {
            withAnimation {
                isExpanded.toggle()
            }
        }
        .onLongPressGesture {
            showingDeleteAlert = true
        }
        .alert("删除录音", isPresented: $showingDeleteAlert) {
            Button("删除", role: .destructive) {
                stopPlayback()
                onDelete()
            }
            Button("取消", role: .cancel) { }
        } message: {
            Text("确定要删除这条录音记录吗？此操作不可撤销。")
        }
        .onDisappear {
            stopPlayback()
        }
    }
    
    private func togglePlayback() {
        if isPlaying {
            stopPlayback()
        } else {
            startPlayback()
        }
    }
    
    private func startPlayback() {
        do {
            // 修改音频会话设置
            let audioSession = AVAudioSession.sharedInstance()
            try audioSession.setCategory(.playAndRecord, options: [.defaultToSpeaker, .allowBluetooth])
            try audioSession.setActive(true)
            
            // 检查文件是否存在
            guard FileManager.default.fileExists(atPath: recording.audioURL.path) else {
                print("音频文件不存在: \(recording.audioURL.path)")
                return
            }
            
            // 创建新的播放器实例
            let data = try Data(contentsOf: recording.audioURL)
            audioPlayer = try AVAudioPlayer(data: data)
            audioPlayer?.prepareToPlay()
            
            // 设置音量为最大
            audioPlayer?.volume = 1.0
            
            // 设置代理
            audioPlayer?.delegate = AudioPlayerDelegate(onFinish: {
                DispatchQueue.main.async {
                    self.isPlaying = false
                }
            })
            
            // 开始播放
            if audioPlayer?.play() == true {
                isPlaying = true
            } else {
                print("播放器启动失败")
            }
        } catch {
            print("播放失败: \(error.localizedDescription)")
        }
    }
    
    private func stopPlayback() {
        audioPlayer?.stop()
        audioPlayer = nil
        isPlaying = false
        
        // 停止音频会话
        do {
            try AVAudioSession.sharedInstance().setActive(false, options: [.notifyOthersOnDeactivation])
        } catch {
            print("停止音频会话失败: \(error.localizedDescription)")
        }
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy年MM月dd日 HH:mm:ss"
        return formatter.string(from: date)
    }
}

class AudioPlayerDelegate: NSObject, AVAudioPlayerDelegate {
    let onFinish: () -> Void
    
    init(onFinish: @escaping () -> Void) {
        self.onFinish = onFinish
        super.init()
    }
    
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        DispatchQueue.main.async {
            self.onFinish()
        }
    }
    
    func audioPlayerDecodeErrorDidOccur(_ player: AVAudioPlayer, error: Error?) {
        if let error = error {
            print("音频解码错误: \(error.localizedDescription)")
        }
    }
}

struct ConversationSegment: Codable {
    let speaker: String // "医生" 或 "患者"
    let content: String
    let timestamp: Date
}

struct Recording: Codable, Identifiable, Hashable {
    let id: UUID
    let recordId: UUID  // 添加关联的病历ID
    let name: String
    let date: Date
    let audioURL: URL
    let conversation: [ConversationSegment]
    
    // 添加 Hashable 协议实现
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    static func == (lhs: Recording, rhs: Recording) -> Bool {
        lhs.id == rhs.id
    }
}

class RecordingStorage {
    static let shared = RecordingStorage()
    private let defaults = UserDefaults.standard
    private let key = "savedRecordings"
    
    func saveRecordings(_ recordings: [Recording]) {
        // 确保录音ID唯一
        let uniqueRecordings = Array(Set(recordings))
        
        let recordingsToSave = uniqueRecordings.map { recording -> [String: Any] in
            [
                "id": recording.id.uuidString,
                "recordId": recording.recordId.uuidString,
                "name": recording.name,
                "date": recording.date,
                "audioURL": recording.audioURL.lastPathComponent,
                "conversation": recording.conversation.map { segment in
                    [
                        "speaker": segment.speaker,
                        "content": segment.content,
                        "timestamp": segment.timestamp
                    ]
                }
            ]
        }
        
        defaults.set(recordingsToSave, forKey: key)
    }
    
    func loadRecordings() -> [Recording] {
        guard let savedData = defaults.object(forKey: key) as? [[String: Any]] else {
            return []
        }
        
        return savedData.compactMap { data -> Recording? in
            guard
                let idString = data["id"] as? String,
                let id = UUID(uuidString: idString),
                let recordIdString = data["recordId"] as? String,
                let recordId = UUID(uuidString: recordIdString),
                let name = data["name"] as? String,
                let date = data["date"] as? Date,
                let audioFileName = data["audioURL"] as? String,
                let conversationData = data["conversation"] as? [[String: Any]]
            else {
                return nil
            }
            
            let audioURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
                .appendingPathComponent(audioFileName)
            
            let conversation = conversationData.compactMap { segmentData -> ConversationSegment? in
                guard
                    let speaker = segmentData["speaker"] as? String,
                    let content = segmentData["content"] as? String,
                    let timestamp = segmentData["timestamp"] as? Date
                else {
                    return nil
                }
                
                return ConversationSegment(
                    speaker: speaker,
                    content: content,
                    timestamp: timestamp
                )
            }
            
            return Recording(
                id: id,
                recordId: recordId,
                name: name,
                date: date,
                audioURL: audioURL,
                conversation: conversation
            )
        }
    }
    
    func deleteRecording(_ recording: Recording) {
        // 删除音频文件
        try? FileManager.default.removeItem(at: recording.audioURL)
        
        // 删除元数据
        var recordings = loadRecordings()
        recordings.removeAll { $0.id == recording.id }
        saveRecordings(recordings)
    }
    
    // 添加按病历ID加载录音的方法
    func loadRecordings(for recordId: UUID) -> [Recording] {
        let allRecordings = loadRecordings()
        return allRecordings.filter { $0.recordId == recordId }
    }
}

// 添加 OrderRow 视图组件
struct OrderRow: View {
    let order: DoctorOrder
    let onDelete: () -> Void
    @State private var showingDeleteAlert = false
    @State private var showingFullScreenImage = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .top, spacing: 12) {
                // 如果有图片，显示缩略图
                if let imageData = order.imageData,
                   let uiImage = UIImage(data: imageData) {
                    Image(uiImage: uiImage)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 60, height: 60)
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .stroke(Color.gray.opacity(0.2), lineWidth: 1)
                        )
                        .onTapGesture {
                            showingFullScreenImage = true
                        }
                }
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(order.content)
                        .fixedSize(horizontal: false, vertical: true)
                    
                    Text(formatDate(order.date))
                        .font(.subheadline)
                        .foregroundColor(.gray)
                }
            }
            
            Divider()
        }
        .padding(.vertical, 8)
        .contentShape(Rectangle())
        .onLongPressGesture {
            showingDeleteAlert = true
        }
        .alert("删除医嘱", isPresented: $showingDeleteAlert) {
            Button("删除", role: .destructive) {
                onDelete()
            }
            Button("取消", role: .cancel) { }
        } message: {
            Text("确定要删除这条医嘱吗？此操作不可撤销。")
        }
        .fullScreenCover(isPresented: $showingFullScreenImage) {
            if let imageData = order.imageData,
               let uiImage = UIImage(data: imageData) {
                ZStack {
                    Color.black.ignoresSafeArea()
                    
                    Image(uiImage: uiImage)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                    
                    VStack {
                        HStack {
                            Spacer()
                            Button(action: {
                                showingFullScreenImage = false
                            }) {
                                Image(systemName: "xmark.circle.fill")
                                    .font(.title)
                                    .foregroundColor(.white)
                                    .padding()
                            }
                        }
                        Spacer()
                    }
                }
                .statusBar(hidden: true)
            }
        }
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy年MM月dd日 HH:mm:ss"
        return formatter.string(from: date)
    }
}

// 修改编辑视图
struct EditMedicalRecordView: View {
    let record: MedicalRecord
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("基本信息")) {
                    Text("医院：\(record.hospital)")
                    Text("科室：\(record.department)")
                    Text("就诊时间：\(formatDate(record.date))")
                }
                
                Section(header: Text("症状描述")) {
                    Text(record.symptoms)
                }
                
                // 这里可以添加更多编辑字段
            }
            .navigationTitle("编辑病例")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("取消") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("保存") {
                        // 这里添加保存逻辑
                        dismiss()
                    }
                }
            }
        }
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy年MM月dd日 HH:mm:ss"
        return formatter.string(from: date)
    }
}

// 添加 TextEditor 的占位符扩展
extension View {
    func placeholder<Content: View>(
        when shouldShow: Bool,
        alignment: Alignment = .leading,
        @ViewBuilder placeholder: () -> Content) -> some View {
        
        ZStack(alignment: alignment) {
            placeholder().opacity(shouldShow ? 1 : 0)
            self
        }
    }
}

