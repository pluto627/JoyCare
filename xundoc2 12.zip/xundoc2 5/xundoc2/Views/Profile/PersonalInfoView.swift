import SwiftUI
import PhotosUI


struct PersonalInfoView: View {
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var userDataManager: UserDataManager
    @State private var isEditing = false
    @State private var showingImagePicker = false
    @State private var selectedImages: [UIImage] = []
    @State private var tempUserData: UserData? // 临时存储编辑的数据
    
    var body: some View {
        Form {
            // 头像部分
            Section {
                HStack {
                    Spacer()
                    VStack {
                        if let avatarData = userDataManager.userData.avatarData,
                           let uiImage = UIImage(data: avatarData) {
                            Image(uiImage: uiImage)
                                .resizable()
                                .scaledToFill()
                                .frame(width: 100, height: 100)
                                .clipShape(Circle())
                        } else {
                            Image(systemName: "person.circle.fill")
                                .resizable()
                                .frame(width: 100, height: 100)
                                .foregroundColor(.gray)
                        }
                        
                        if isEditing {
                            Button("更换头像") {
                                showingImagePicker = true
                            }
                            .foregroundColor(.blue)
                            .padding(.top, 8)
                        }
                    }
                    Spacer()
                }
            }
            
            Section(header: Text("基本信息")) {
                if isEditing {
                    TextField("姓名", text: Binding(
                        get: { tempUserData?.name ?? userDataManager.userData.name },
                        set: { tempUserData?.name = $0 }
                    ))
                    TextField("ID", text: Binding(
                        get: { tempUserData?.id ?? userDataManager.userData.id },
                        set: { tempUserData?.id = $0 }
                    ))
                    Picker("性别", selection: Binding(
                        get: { tempUserData?.gender ?? userDataManager.userData.gender },
                        set: { tempUserData?.gender = $0 }
                    )) {
                        Text("男").tag("男")
                        Text("女").tag("女")
                    }
                    DatePicker("出生日期", selection: Binding(
                        get: { tempUserData?.birthDate ?? userDataManager.userData.birthDate },
                        set: { tempUserData?.birthDate = $0 }
                    ), displayedComponents: .date)
                } else {
                    InfoRow(title: "姓名", value: userDataManager.userData.name)
                    
                    InfoRow(title: "性别", value: userDataManager.userData.gender)
                    InfoRow(title: "出生日期", value: userDataManager.userData.birthDate.formatted(date: .abbreviated, time: .omitted))
                }
            }
            
            Section(header: Text("联系方式")) {
                if isEditing {
                    TextField("手机号码", text: Binding(
                        get: { tempUserData?.phone ?? userDataManager.userData.phone },
                        set: { tempUserData?.phone = $0 }
                    ))
                    TextField("电子邮箱", text: Binding(
                        get: { tempUserData?.email ?? userDataManager.userData.email },
                        set: { tempUserData?.email = $0 }
                    ))
                } else {
                    InfoRow(title: "手机号码", value: userDataManager.userData.phone)
                    InfoRow(title: "电子邮箱", value: userDataManager.userData.email)
                }
            }
            
            Section(header: Text("地址信息")) {
                if isEditing {
                    TextField("居住地址", text: Binding(
                        get: { tempUserData?.address ?? userDataManager.userData.address },
                        set: { tempUserData?.address = $0 }
                    ))
                } else {
                    InfoRow(title: "居住地址", value: userDataManager.userData.address)
                }
            }
        }
        .navigationTitle("个人信息")
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarItems(trailing: Button(isEditing ? "保存" : "编辑") {
            if isEditing {
                // 保存更改
                if let tempData = tempUserData {
                    userDataManager.userData = tempData
                }
                isEditing.toggle()
                tempUserData = nil
            } else {
                // 开始编辑
                tempUserData = userDataManager.userData
                isEditing.toggle()
            }
        })
        .sheet(isPresented: $showingImagePicker) {
            ImagePicker(selectedImages: $selectedImages, sourceType: .photoLibrary)
        }
        .onChange(of: selectedImages) { newImages in
            if let image = newImages.last,
               let imageData = image.jpegData(compressionQuality: 0.8) {
                tempUserData?.avatarData = imageData
            }
        }
        .onAppear {
            // 重置临时数据
            tempUserData = nil
            isEditing = false
            selectedImages = []
        }
    }
}

struct InfoRow: View {
    let title: String
    let value: String
    
    var body: some View {
        HStack {
            Text(title)
            Spacer()
            Text(value)
                .foregroundColor(.gray)
        }
    }
}
#Preview {
    PersonalInfoView()
        .environmentObject(UserDataManager())
}
