import SwiftUI

struct SelectReminderTypeView: View {
    @Environment(\.dismiss) var dismiss
    @ObservedObject var reminderManager: ReminderManager
    @State private var selectedType: String?
    @State private var showAddReminderView = false
    
    let reminderTypes = [
        ("用药", "pill", "用药提醒"),
        ("运动", "figure.run", "运动提醒"),
        ("喝水", "drop", "喝水提醒"),
        ("睡眠", "moon", "睡眠提醒"),
        ("久坐", "chair", "久坐提醒"),
        ("视力保护", "eye", "视力保护"),
        ("口腔卫生", "mouth", "口腔卫生"),
        ("皮肤护理", "leaf", "皮肤护理"),
        ("复诊提醒", "cross.case", "复诊提醒"),
        ("自定义", "plus", "自定义提醒")
    ]
    
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    // 添加一个计算属性来处理视图选择
    @ViewBuilder
    private var destinationView: some View {
        if let type = selectedType {
            if type == "用药提醒" {
                AddMedicineReminderView(reminderManager: reminderManager)
            } else {
                AddReminderView(reminderManager: reminderManager, initialType: type)
            }
        } else {
            EmptyView()
        }
    }
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text("选择提醒类型")
                    .font(.title2)
                    .fontWeight(.bold)
                
                LazyVGrid(columns: columns, spacing: 20) {
                    ForEach(reminderTypes, id: \.0) { type in
                        ReminderTypeButton(
                            title: type.0,
                            icon: type.1,
                            isSelected: selectedType == type.2
                        ) {
                            selectedType = type.2
                            showAddReminderView = true
                        }
                    }
                }
                .padding()
                
                Spacer()
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("取消") {
                        dismiss()
                    }
                }
            }
            .fullScreenCover(isPresented: $showAddReminderView) {
                destinationView
            }
        }
    }
}

struct ReminderTypeButton: View {
    let title: String
    let icon: String
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack {
                Image(systemName: icon)
                    .font(.system(size: 24))
                    .foregroundColor(.blue)
                    .frame(width: 50, height: 50)
                    .background(Color.blue.opacity(0.1))
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                
                Text(title)
                    .font(.system(size: 12))
                    .foregroundColor(.primary)
            }
        }
        .padding(8)
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(isSelected ? Color.blue.opacity(0.1) : Color.clear)
        )
    }
}
