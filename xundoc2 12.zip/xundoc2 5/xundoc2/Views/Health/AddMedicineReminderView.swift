import SwiftUI
import PhotosUI
import Vision
import CoreML

struct AddMedicineReminderView: View {
    @Environment(\.dismiss) var dismiss
    @ObservedObject var reminderManager: ReminderManager
    
    @State private var medicineName = ""
    @State private var timesPerDay = "1"  // 每日次数
    @State private var selectedMealTime = "餐后" // 服用时间
    @State private var dosageAmount = "1"  // 剂量数量
    @State private var dosageUnit = "片"  // 剂量单位
    @State private var selectedTimes: [Date] = [Date()] // 用药时间数组
    
    @State private var showImagePicker = false
    @State private var showActionSheet = false
    @State private var sourceType: UIImagePickerController.SourceType = .photoLibrary
    @State private var selectedImages: [UIImage] = []
    @State private var isProcessing = false
    
    let timesOptions = ["1", "2", "3", "4"]
    let mealTimes = ["餐前", "随餐", "餐后"]
    
    // 定义自定义颜色
    private let customPurple = Color(hex: "8749f1")
    
    // 生成默认时间数组
    private func generateDefaultTimes(count: Int) -> [Date] {
        let calendar = Calendar.current
        var times: [Date] = []
        let now = Date()
        
        switch count {
        case 1:
            // 一天一次默认早上8点
            if let time = calendar.date(bySettingHour: 8, minute: 0, second: 0, of: now) {
                times.append(time)
            }
        case 2:
            // 一天两次默认早8晚8
            if let morning = calendar.date(bySettingHour: 8, minute: 0, second: 0, of: now),
               let evening = calendar.date(bySettingHour: 20, minute: 0, second: 0, of: now) {
                times.append(contentsOf: [morning, evening])
            }
        case 3:
            // 一天三次默认早8午12晚8
            if let morning = calendar.date(bySettingHour: 8, minute: 0, second: 0, of: now),
               let noon = calendar.date(bySettingHour: 12, minute: 0, second: 0, of: now),
               let evening = calendar.date(bySettingHour: 20, minute: 0, second: 0, of: now) {
                times.append(contentsOf: [morning, noon, evening])
            }
        case 4:
            // 一天四次默认早8午12晚8睡前10
            if let morning = calendar.date(bySettingHour: 8, minute: 0, second: 0, of: now),
               let noon = calendar.date(bySettingHour: 12, minute: 0, second: 0, of: now),
               let evening = calendar.date(bySettingHour: 20, minute: 0, second: 0, of: now),
               let night = calendar.date(bySettingHour: 22, minute: 0, second: 0, of: now) {
                times.append(contentsOf: [morning, noon, evening, night])
            }
        default:
            times.append(now)
        }
        return times
    }
    
    var body: some View {
        VStack(spacing: 16) {
            // 标题
            HStack {
                Text("添加用药提醒")
                    .font(.title2)
                    .bold()
                Spacer()
                Button(action: { dismiss() }) {
                    Image(systemName: "xmark")
                        .foregroundColor(.gray)
                }
            }
            .padding(.horizontal)
            .padding(.vertical, 8)
            
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    // 药品名称
                    VStack(alignment: .leading, spacing: 8) {
                        Text("药品名称")
                            .foregroundColor(.gray)
                        HStack {
                            TextField("请输入药品名称", text: $medicineName)
                            
                            Button(action: {
                                showActionSheet = true
                            }) {
                                Image(systemName: "camera")
                                    .foregroundColor(.gray)
                            }
                            .padding(.horizontal, 8)
                            .actionSheet(isPresented: $showActionSheet) {
                                ActionSheet(
                                    title: Text("选择图片来源"),
                                    buttons: [
                                        .default(Text("拍照")) {
                                            sourceType = .camera
                                            showImagePicker = true
                                        },
                                        .default(Text("从相册选择")) {
                                            sourceType = .photoLibrary
                                            showImagePicker = true
                                        },
                                        .cancel(Text("取消"))
                                    ]
                                )
                            }
                            .sheet(isPresented: $showImagePicker) {
                                ImagePicker(selectedImages: $selectedImages, sourceType: sourceType)
                            }
                            .onChange(of: selectedImages) { newImages in
                                guard let lastImage = newImages.last else { return }
                                isProcessing = true
                                recognizeMedicineText(in: lastImage)
                            }
                        }
                        .padding(.horizontal, 12)
                        .frame(height: 36)
                        .background(Color(.systemGray6))
                        .cornerRadius(8)
                    }
                    
                    // 每日次数
                    VStack(alignment: .leading, spacing: 8) {
                        Text("每日次数")
                            .foregroundColor(.gray)
                        HStack(spacing: 10) {
                            ForEach(timesOptions, id: \.self) { time in
                                Button(action: { 
                                    timesPerDay = time
                                    selectedTimes = generateDefaultTimes(count: Int(time) ?? 1)
                                }) {
                                    Text("\(time)次")
                                        .foregroundColor(timesPerDay == time ? .white : customPurple)
                                        .frame(maxWidth: .infinity)
                                        .frame(height: 36)
                                        .background(
                                            RoundedRectangle(cornerRadius: 8)
                                                .fill(timesPerDay == time ? customPurple : Color.clear)
                                                .overlay(
                                                    RoundedRectangle(cornerRadius: 8)
                                                        .stroke(customPurple, lineWidth: 1)
                                                )
                                        )
                                }
                            }
                        }
                    }
                    
                    // 用药时间选择
                    VStack(alignment: .leading, spacing: 8) {
                        Text("用药时间")
                            .foregroundColor(.gray)
                        
                        ForEach(0..<(Int(timesPerDay) ?? 1), id: \.self) { index in
                            HStack {
                                Text("第\(index + 1)次")
                                    .foregroundColor(.gray)
                                Spacer()
                                DatePicker("", selection: $selectedTimes[index], displayedComponents: .hourAndMinute)
                                    .labelsHidden()
                            }
                            .padding(.horizontal, 12)
                            .padding(.vertical, 8)
                            .background(Color(.systemGray6))
                            .cornerRadius(8)
                        }
                    }
                    
                    // 服用时间
                    VStack(alignment: .leading, spacing: 8) {
                        Text("服用时间")
                            .foregroundColor(.gray)
                        HStack(spacing: 10) {
                            ForEach(mealTimes, id: \.self) { time in
                                Button(action: { selectedMealTime = time }) {
                                    Text(time)
                                        .foregroundColor(selectedMealTime == time ? .white : customPurple)
                                        .frame(maxWidth: .infinity)
                                        .frame(height: 36)
                                        .background(
                                            RoundedRectangle(cornerRadius: 8)
                                                .fill(selectedMealTime == time ? customPurple : Color.clear)
                                                .overlay(
                                                    RoundedRectangle(cornerRadius: 8)
                                                        .stroke(customPurple, lineWidth: 1)
                                                )
                                        )
                                }
                            }
                        }
                    }
                    
                    // 每次剂量
                    VStack(alignment: .leading, spacing: 8) {
                        Text("每次剂量")
                            .foregroundColor(.gray)
                        HStack {
                            Button(action: { 
                                if let amount = Int(dosageAmount), amount > 1 {
                                    dosageAmount = "\(amount - 1)"
                                }
                            }) {
                                Image(systemName: "minus")
                                    .foregroundColor(.gray)
                                    .frame(width: 36, height: 36)
                                    .background(Color(.systemGray6))
                                    .cornerRadius(8)
                            }
                            
                            Text(dosageAmount)
                                .frame(maxWidth: .infinity)
                                .frame(height: 36)
                                .background(Color(.systemGray6))
                            
                            Button(action: {
                                if let amount = Int(dosageAmount) {
                                    dosageAmount = "\(amount + 1)"
                                }
                            }) {
                                Image(systemName: "plus")
                                    .foregroundColor(.gray)
                                    .frame(width: 36, height: 36)
                                    .background(Color(.systemGray6))
                                    .cornerRadius(8)
                            }
                            
                            Menu {
                                ForEach(["片", "粒", "毫升", "克"], id: \.self) { unit in
                                    Button(unit) {
                                        dosageUnit = unit
                                    }
                                }
                            } label: {
                                Text(dosageUnit)
                                    .frame(width: 50, height: 36)
                                    .background(Color(.systemGray6))
                                    .cornerRadius(8)
                            }
                        }
                    }
                }
                .padding(.horizontal)
                .padding(.bottom, 16)
            }
            
            // 保存按钮
            Button(action: saveReminder) {
                Text("保存")
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 44)
                    .background(customPurple)
                    .cornerRadius(22)
                    .padding(.horizontal)
            }
            .padding(.bottom, 8)
        }
        .background(Color(hex: "FAFAFA"))
    }
    
    private func saveReminder() {
        // 为每个时间点创建一个提醒
        for time in selectedTimes {
            let reminderDescription = """
            用药剂量: \(dosageAmount)\(dosageUnit)
            每日次数: \(timesPerDay)次
            """
            
            let reminder = Reminder(
                title: medicineName,
                date: time,
                description: reminderDescription,
                type: "用药提醒",
                repeatPattern: "daily",
                dosage: dosageAmount,
                unit: dosageUnit,
                medicineMethod: "口服",
                beforeOrAfterMeal: selectedMealTime
            )
            
            reminderManager.addReminder(reminder)
        }
        
        HapticManager.shared.notification(type: .success)
        dismiss()
    }
    
    // 修改文字识别功能
    private func recognizeMedicineText(in image: UIImage) {
        guard let cgImage = image.cgImage else {
            DispatchQueue.main.async {
                self.isProcessing = false
            }
            return
        }
        
        let requestHandler = VNImageRequestHandler(cgImage: cgImage)
        let request = VNRecognizeTextRequest { request, error in
            guard let observations = request.results as? [VNRecognizedTextObservation],
                  !observations.isEmpty else {
                DispatchQueue.main.async {
                    self.isProcessing = false
                }
                return
            }
            
            let recognizedStrings = observations.compactMap { observation in
                observation.topCandidates(1).first?.string
            }
            
            print("识别到的文本: \(recognizedStrings)") // 添加调试输出
            
            DispatchQueue.main.async {
                let medicineText = self.processMedicineText(recognizedStrings)
                print("处理后的药品名称: \(medicineText)") // 添加调试输出
                self.medicineName = medicineText
                self.isProcessing = false
            }
        }
        
        request.recognitionLanguages = ["zh-Hans", "en"]
        request.recognitionLevel = .accurate // 设置为精确识别模式
        request.usesLanguageCorrection = true // 使用语言纠正
        
        do {
            try requestHandler.perform([request])
        } catch {
            print("文字识别失败: \(error)")
            DispatchQueue.main.async {
                self.isProcessing = false
            }
        }
    }
    
    private func processMedicineText(_ strings: [String]) -> String {
        // 常见药品后缀和关键词
        let medicineSuffixes = [
            "片", "胶囊", "颗粒", "丸", "贴", "液", "注射液", "滴眼液", "糖浆",
            "mg", "ml", "克", "毫克", "毫升", "针", "喷剂", "贴剂", "栓", "软膏"
        ]
        
        // 常见药品名称模式
        let patterns = [
            "[\u{4e00}-\u{9fff}]+(?:[0-9.]+)?(?:mg|ml|g|kg|片|粒|丸|贴|针|支|包|袋)?[片丸胶囊颗粒贴液针剂栓]",  // 中文名称+可能的数字+剂型
            "[A-Za-z\\s]+(?:[0-9.]+)?(?:mg|ml|g|tablet|capsule|patch|injection)[片丸胶囊颗粒贴液针剂栓]?",  // 英文名称+可能的数字+剂型
            "[\u{4e00}-\u{9fff}A-Za-z\\s]+[0-9.]+\\s*(?:mg|ml|g|克|毫克|毫升|片|粒|丸|贴|针|支|包|袋)" // 名称+规格
        ]
        
        for string in strings {
            // 打印每个识别到的字符串
            print("正在处理字符串: \(string)")
            
            // 1. 检查完整的药品名称模式
            for pattern in patterns {
                if let range = string.range(of: pattern, options: .regularExpression) {
                    let result = String(string[range])
                    print("匹配到模式: \(result)")
                    return result
                }
            }
            
            // 2. 检查是否包含药品后缀
            for suffix in medicineSuffixes {
                if string.contains(suffix) {
                    print("匹配到后缀: \(string)")
                    return string
                }
            }
        }
        
        // 如果没有找到匹配的模式，返回第一个识别到的文本
        let result = strings.first ?? ""
        print("未匹配到模式，返回: \(result)")
        return result
    }
}


// 添加颜色扩展
