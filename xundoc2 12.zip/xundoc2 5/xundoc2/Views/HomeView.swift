import SwiftUI

struct DateHeaderView: View {
    @State private var currentDate = Date()
    
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(weekdayString)
                .fontWeight(.bold)
                .font(.system(size: 40, weight: .medium))
            Text(dateString)
                .fontWeight(.bold)
                .font(.system(size: 25))
        }
    }
    
    private var weekdayString: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "EEEE"
        return formatter.string(from: currentDate)
    }
    
    private var dateString: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy.MM.dd"
        return formatter.string(from: currentDate)
    }
}

struct HomeView: View {
    @ObservedObject var reminderManager: ReminderManager
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    // 顶部布局
                    HStack {
                        DateHeaderView()
                        Spacer()
                    }
                    .padding(.horizontal)
                    
                    // 健康数据卡片
                    HealthDataCard()
                        .padding(.horizontal)
                    
                    // 今日提醒部分
                    Group {
                        if !uncompletedTodayReminders.isEmpty {
                            ReminderSection(reminderManager: reminderManager)
                                .padding(.horizontal)
                        } else {
                            EmptyStateView()
                                .padding(.horizontal)
                        }
                    }
                    
                    // 常用功能部分
                    // 这里可以添加其他功能模块
                }
                .padding(.top)
            }
            .navigationBarHidden(true)
        }
    }
    
    // 新增计算属性：获取今天未完成的提醒
    private var uncompletedTodayReminders: [Reminder] {
        let calendar = Calendar.current
        let today = calendar.startOfDay(for: Date())
        let tomorrow = calendar.date(byAdding: .day, value: 1, to: today)!
        
        return reminderManager.reminders.filter { reminder in
            if let reminderDate = calendar.date(from: calendar.dateComponents([.year, .month, .day], from: reminder.date)) {
                return reminderDate >= today && 
                       reminderDate < tomorrow && 
                       !reminder.isCompleted  // 只显示未完成的提醒
            }
            return false
        }
    }
}

// 空状态视图
struct EmptyStateView: View {
    @State private var isNightTime: Bool = {
        let hour = Calendar.current.component(.hour, from: Date())
        return hour < 6 || hour >= 18
    }()
    
    var body: some View {
        VStack(spacing: 16) {
            // 日/夜图标
            Image(systemName: isNightTime ? "moon.stars.fill" : "sun.max.fill")
                .font(.system(size: 40))
                .foregroundColor(.primary)
            
            // 提示文本
            Text("今日暂无提醒事项")
                .font(.system(size: 14))
                .foregroundColor(.gray)
        }
        .padding(.vertical, 30)
    }
}

// 提醒部分组件

#Preview {
    HomeView(reminderManager: ReminderManager())
}
