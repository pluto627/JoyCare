import SwiftUI

struct ReminderView: View {
    @StateObject var reminderManager: ReminderManager
    @State private var showingAddView = false
    @Environment(\.colorScheme) private var colorScheme
    
    // 添加一个计算属性来对提醒进行分组
    private var groupedReminders: [String: [Reminder]] {
        Dictionary(grouping: reminderManager.reminders) { reminder in
            if reminder.type == "用药提醒" {
                // 用药提醒按药品名称分组
                return reminder.title
            } else {
                // 其他类型的提醒保持独立
                return reminder.id.uuidString
            }
        }
    }
    
    var body: some View {
        NavigationView {
            ZStack(alignment: .top) {
                Color(UIColor.systemGray6)
                    .ignoresSafeArea()
                
                VStack(spacing: -60) {
                    // 标题栏背景延伸到顶部
                    Color(red: 0.4, green: 0.3, blue: 0.9)
                        .frame(height: 135)
                        .ignoresSafeArea(edges: .top)
                    
                    ScrollView {
                        VStack(spacing: 20) {
                            // 如果没有提醒，显示添加提醒的引导
                            if reminderManager.reminders.isEmpty {
                                VStack(spacing: 20) {
                                    VStack(spacing: 10) {
                                        Text("")
                                            .foregroundColor(.gray)
                                        Text("")
                                            .foregroundColor(.gray)
                                        Text("")
                                            .foregroundColor(.gray)
                                        Text("")
                                            .foregroundColor(.gray)
                                        Text("")
                                            .foregroundColor(.gray)
                                        Text("")
                                            .foregroundColor(.gray)
                                        Text("")
                                            .foregroundColor(.gray)
                                        Text("")
                                            .foregroundColor(.gray)
                                        Text("")
                                            .foregroundColor(.gray)
                                        Text("添加一个事件")
                                            .foregroundColor(.gray)
                                        Text("再制定一个提醒时间")
                                            .foregroundColor(.gray)
                                    }
                                    
                                    Button(action: {
                                        showingAddView = true
                                    }) {
                                        HStack {
                                            Image(systemName: "plus")
                                            Text("增加事件")
                                        }
                                        .font(.system(size: 17))
                                        .foregroundColor(.white)
                                        .frame(maxWidth: .infinity)
                                        .frame(height: 56)
                                        .background(Color(white: 0.2))
                                        .cornerRadius(16)
                                        .padding(.horizontal, 20)
                                    }
                                }
                                .padding(.top, 30)
                            } else {
                                // 修改提醒列表的显示逻辑
                                VStack(spacing: 16) {
                                    ForEach(Array(groupedReminders.keys).sorted(), id: \.self) { key in
                                        if let reminders = groupedReminders[key] {
                                            if reminders[0].type == "用药提醒" {
                                                // 用药提醒显示合并后的视图
                                                ReminderViewItem(
                                                    reminder: reminders[0],
                                                    allReminders: reminders.sorted(by: { $0.date < $1.date }),
                                                    reminderManager: reminderManager
                                                )
                                            } else {
                                                // 其他类型的提醒正常显示
                                                ReminderViewItem(
                                                    reminder: reminders[0],
                                                    allReminders: [reminders[0]],
                                                    reminderManager: reminderManager
                                                )
                                            }
                                        }
                                    }
                                }
                                .padding(.horizontal, 16)
                                .padding(.top, 20)
                                .animation(.default, value: reminderManager.reminders)
                            }
                        }
                    }
                }
                
                // 顶部导航栏 - 使用VStack分离加号按钮和健康提醒文本
                VStack(alignment: .leading, spacing: 0) {
                    // 加号按钮，放在顶部
                    HStack {
                        Spacer()
                        Button(action: {
                            showingAddView = true
                        }) {
                            Image(systemName: "plus")
                                .font(.system(size: 25))
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                        }
                    }
                    .padding(.top, 12)
                    .padding(.trailing)
                    
                    // 健康提醒文本，放在加号下方，靠左对齐
                    Text("健康提醒")
                        .font(.title)
                        .bold()
                        .foregroundColor(.white)
                        .padding(.leading)
                        .padding(.top, -1)
                }
            }
            .navigationBarHidden(true)
            .sheet(isPresented: $showingAddView) {
                SelectReminderTypeView(reminderManager: reminderManager)
                    .presentationDetents([.medium])
                    .presentationDragIndicator(.visible)
            }
        }
    }
}

#Preview {
    ReminderView(reminderManager: ReminderManager())
}
