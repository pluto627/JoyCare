import SwiftUI

struct MedicationReminderView: View {
    let record: MedicalRecord
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: "pills.circle.fill")
                    .foregroundColor(.purple)
                    .font(.title2)
                
                Text("用药提醒")
                    .font(.headline)
                
                Spacer()
                
                Text("\(record.dailyDoses)次/天")
                    .font(.subheadline)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(Color.purple.opacity(0.1))
                    .foregroundColor(.purple)
                    .cornerRadius(4)
            }
            
            Text(record.medicationTimes.joined(separator: "、"))
                .font(.subheadline)
                .foregroundColor(.secondary)
        }
        .padding()
        .background(Color(hex: "FAFAFA"))
        .cornerRadius(8)
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(Color(UIColor.systemGray4), lineWidth: 0.5)
        )
    }
} 