import SwiftUI

struct AboutView: View {
    // 版本号和构建号
    private let appVersion = "1.0"
    private let buildNumber = "25"
    
    var body: some View {
        VStack(spacing: 0) {
            // 顶部导航栏
            HStack {
                Text("关于")
                    .font(.title2)
                    .padding()
                Spacer()
            }
            .background(Color(uiColor: .systemBackground))
            
            ScrollView {
                VStack(spacing: 15) {
                    // App Logo
                    VStack(spacing: 12) {
                        Image("Icon") // 替换为你的App图标资源名称
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 80, height: 80)
                            .padding(.top, 20)
                        
                        Text("JoyCare")
                            .font(.title)
                            .bold()
                        
                        Text("版本 \(appVersion)")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                            .padding(.bottom, 20)
                    }
                    .frame(maxWidth: .infinity)
                    .background(Color(uiColor: .systemBackground))
                    .cornerRadius(10)
                    .padding(.horizontal)
                    
                    // 介绍文本
                    VStack(spacing: 5) {
                        Text("这是我为爷爷奶奶、外公外婆编写的一个健康提醒和就医记录📝管理软件。\n\n希望能帮到每一个热爱健康的人，让这款APP成为你的健康助手，我感到很开心。\n\n如果你有任何想法也可以写信告诉我。")
                            .font(.system(size: 16))
                            .foregroundColor(.primary)
                            .multilineTextAlignment(.leading)
                            .padding(.vertical, 24)
                            .padding(.horizontal,24)
                        
                        Divider()
                            .padding(.horizontal)
                        
                        Text("plutoguoyq@gmail.com")
                            .font(.system(size: 16))
                            .foregroundColor(Color(hex: "9253f3"))
                            .padding(.vertical, 16)
                    }
                    .frame(maxWidth: .infinity)
                    .background(Color(uiColor: .systemBackground))
                    .cornerRadius(10)
                    .padding(.horizontal)
                    
                    // 版权信息
                    VStack(spacing: 4) {
                        Text("© 2025 Pluto")
                            .font(.caption)
                            .foregroundColor(.gray)
                        
                        Text("Made with ❤️ in Shanghai")
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                    .padding(.vertical, 30)
                }
                .padding(.top, 12)
            }
            .background(Color(.systemGray6))
        }
    }
}

#Preview {
    AboutView()
}
