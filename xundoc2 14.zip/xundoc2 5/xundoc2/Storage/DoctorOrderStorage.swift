import Foundation

class DoctorOrderStorage {
    static let shared = DoctorOrderStorage()
    private let defaults = UserDefaults.standard
    private let key = "savedDoctorOrders"
    
    func saveOrders(_ orders: [DoctorOrder]) {
        if let encoded = try? JSONEncoder().encode(orders) {
            defaults.set(encoded, forKey: key)
        }
    }
    
    func loadOrders() -> [DoctorOrder] {
        if let data = defaults.data(forKey: key),
           let decoded = try? JSONDecoder().decode([DoctorOrder].self, from: data) {
            return decoded
        }
        return []
    }
    
    func loadOrders(for recordId: UUID) -> [DoctorOrder] {
        let allOrders = loadOrders()
        return allOrders.filter { $0.recordId == recordId }
    }
} 